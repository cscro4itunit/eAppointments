<?php
class AppointmentMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
	}

	// CRUD
	public function add_appointment ($db_table, $url_key, $unique_id_number, $date_received, $sector, $agency_name, $appointee, $position_title, $salary_grade, $position_level, $employment_status, $appointment_nature, $inclusive_date_casual_from, $inclusive_date_casual_to, $appointing_authority, $issuance_date, $birthday, $sex, $pwd, $disability, $member_ip_group, $ethnicity, $eligibility_type, $eligibility_effective_date, $time_used_of_eligibility, $num_none_wd, $target_processing_days, $due_date, $encoded_by, $appointment_status) {
		$sql = 'INSERT INTO '.$db_table.'(url_key, unique_id_number, date_received, sector, agency_name, appointee, position_title, salary_grade, position_level, employment_status, appointment_nature, inclusive_date_casual_from, inclusive_date_casual_to, appointing_authority, issuance_date, birthday, sex, pwd, disability, member_ip_group, ethnicity, eligibility_type, eligibility_effective_date, time_used_of_eligibility, num_none_wd, target_processing_days, due_date, encoded_by, appointment_status)
			VALUES("'.$url_key.'", "'.$unique_id_number.'", "'.$date_received.'", "'.$sector.'", "'.$agency_name.'", "'.$appointee.'", "'.$position_title.'", "'.$salary_grade.'", "'.$position_level.'", "'.$employment_status.'", "'.$appointment_nature.'", "'.$inclusive_date_casual_from.'", "'.$inclusive_date_casual_to.'", "'.$appointing_authority.'", "'.$issuance_date.'", "'.$birthday.'", "'.$sex.'", "'.$pwd.'", "'.$disability.'", "'.$member_ip_group.'", "'.$ethnicity.'", "'.$eligibility_type.'", "'.$eligibility_effective_date.'", "'.$time_used_of_eligibility.'", "'.$num_none_wd.'", "'.$target_processing_days.'", "'.$due_date.'", "'.$encoded_by.'", "'.$appointment_status.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_appointment($db_table, $url_key, $date_received, $sector, $agency_name, $appointee, $position_title, $salary_grade, $position_level, $employment_status, $appointment_nature, $inclusive_date_casual_from, $inclusive_date_casual_to, $appointing_authority, $issuance_date, $birthday, $sex, $pwd, $disability, $member_ip_group, $ethnicity, $eligibility_type, $eligibility_effective_date, $time_used_of_eligibility) {
		$sql = 'UPDATE '.$db_table.' SET 
				date_received = "'.$date_received.'",
				sector = "'.$sector.'",
				agency_name = "'.$agency_name.'",
				appointee = "'.$appointee.'",
				position_title = "'.$position_title.'",
				salary_grade = "'.$salary_grade.'",
				position_level = "'.$position_level.'",
				employment_status = "'.$employment_status.'",
				appointment_nature = "'.$appointment_nature.'",
				inclusive_date_casual_from = "'.$inclusive_date_casual_from.'",
				inclusive_date_casual_to = "'.$inclusive_date_casual_to.'",
				appointing_authority = "'.$appointing_authority.'",
				issuance_date = "'.$issuance_date.'",
				birthday = "'.$birthday.'",
				sex = "'.$sex.'",
				pwd = "'.$pwd.'",
				disability = "'.$disability.'",
				member_ip_group = "'.$member_ip_group.'",
				ethnicity = "'.$ethnicity.'",
				eligibility_type = "'.$eligibility_type.'",
				eligibility_effective_date = "'.$eligibility_effective_date.'",
				time_used_of_eligibility = "'.$time_used_of_eligibility.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_appointment_processor($db_table, $url_key, $action_taken, $date_acted, $processor, $remarks, $appointment_status) {
		$sql = 'UPDATE '.$db_table.' SET action_taken = "'.$action_taken.'", date_acted = "'.$date_acted.'", processor = "'.$processor.'", remarks = "'.$remarks.'", appointment_status = "'.$appointment_status.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_appointment_official($db_table, $url_key, $action_taken_by_official, $date_signed, $signing_official, $date_acted_within, $remarks, $appointment_status) {
		$sql = 'UPDATE '.$db_table.' SET action_taken_by_official = "'.$action_taken_by_official.'", date_signed = "'.$date_signed.'", signing_official = "'.$signing_official.'", date_acted_within = "'.$date_acted_within.'", remarks = "'.$remarks.'", appointment_status = "'.$appointment_status.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_released($db_table, $url_key, $remarks, $date_released) {
		$sql = 'UPDATE '.$db_table.' SET remarks = "'.$remarks.'", date_released = "'.$date_released.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// FETCHING DETAILS
	public function fetch_appointment($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' ORDER BY unique_id_number DESC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_appointment_by_current_year($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.date("Y").' ORDER BY unique_id_number DESC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_pending_appointment($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Received" ORDER BY unique_id_number DESC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_acted_appointment($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Acted" ORDER BY unique_id_number DESC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_signed_appointment($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Signed" ORDER BY unique_id_number DESC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function auth_unique_key($db_table, $field, $generated_id) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE unique_id_number = "'.$generated_id.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function url_auth($db_table, $field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function fetch_appt_between_date_range($db_table, $starting_date, $ending_date) {
		$sql = 'SELECT * FROM '.$db_table.' WHERE date_received BETWEEN "'.$starting_date.'" AND "'.$ending_date.'" ';
		$query = $this->db->query($sql);
       	return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_appt_between_date_range_signed($db_table, $starting_date, $ending_date, $field_officer) {
		$sql = 'SELECT * FROM '.$db_table.' WHERE date_received BETWEEN "'.$starting_date.'" AND "'.$ending_date.'" AND signing_official = "'.$field_officer.'" ';
		$query = $this->db->query($sql);
       	return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_appt_between_date_range_acted($db_table, $starting_date, $ending_date, $field_officer) {
		$sql = 'SELECT * FROM '.$db_table.' WHERE date_received BETWEEN "'.$starting_date.'" AND "'.$ending_date.'" AND processor = "'.$field_officer.'" ';
		$query = $this->db->query($sql);
       	return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_appt_between_date_range_fo($db_table, $starting_date, $ending_date, $field_officer) {
		$sql = 'SELECT * FROM '.$db_table.' WHERE date_received BETWEEN "'.$starting_date.'" AND "'.$ending_date.'" AND processor = "'.$field_officer.'" AND signing_official = "'.$field_officer.'" ';
		$query = $this->db->query($sql);
       	return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_appt_between_date_range_status($db_table, $starting_date, $ending_date, $search_appointment_status) {
		$sql = 'SELECT * FROM '.$db_table.' WHERE date_received BETWEEN "'.$starting_date.'" AND "'.$ending_date.'" AND appointment_status = "'.$search_appointment_status.'" ';
		$query = $this->db->query($sql);
       	return $query->num_rows() > 0 ?  $query->result() : '';
	}

	// COUNTING DATA
	public function count_received_total($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_received_current_year($db_table, $field, $current_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$current_year.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_pending($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Received" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_acted($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Acted" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_signed($db_table, $field) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Signed" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_received_per_day($db_table, $field, $date_received) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE date_received = "'.$date_received.'" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_total_processed_by_fo($db_table, $field, $processor) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE processor = "'.$processor.'" ORDER BY processor ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_total_signed_by_fo($db_table, $field, $signing_official) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE signing_official = "'.$signing_official.'" ORDER BY signing_official ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	// count pending from previous year
	public function count_received_last_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) != '.$active_year.' AND appointment_status != "Signed" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_signed_last_year_per_month($db_table, $field, $last_year, $month_signed) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$last_year.' AND MONTH(date_signed) = '.$month_signed.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	// COUNTING DATA FOR ACTIVE YEAR
	public function count_received_total_active_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_pending_active_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Received" AND YEAR(date_received) = '.$active_year.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_acted_active_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Acted" AND YEAR(date_received) = '.$active_year.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_signed_active_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Signed" AND YEAR(date_received) = '.$active_year.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_month_received_active_year($db_table, $field, $active_year, $month_received) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' AND MONTH(date_received) = '.$month_received.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_month_signed_active_year($db_table, $field, $active_year, $month_signed) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status = "Signed" AND YEAR(date_received) = '.$active_year.' AND MONTH(date_signed) = '.$month_signed.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_month_not_signed_active_year($db_table, $field, $active_year, $month_signed) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status != "Signed" AND YEAR(date_received) = '.$active_year.' AND MONTH(date_received) <= '.$month_signed.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_processed_by_fo_active_year($db_table, $field, $active_year, $month_acted, $processor) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' AND MONTH(date_acted) = '.$month_acted.' AND processor = "'.$processor.'" ORDER BY processor ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_signed_by_fo_active_year($db_table, $field, $active_year, $month_signed, $signing_official) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' AND MONTH(date_signed) = '.$month_signed.' AND signing_official = "'.$signing_official.'" ORDER BY signing_official ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_total_processed_by_fo_active_year($db_table, $field, $active_year, $processor) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' AND processor = "'.$processor.'" ORDER BY processor ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_total_signed_by_fo_active_year($db_table, $field, $active_year, $signing_official) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) = '.$active_year.' AND signing_official = "'.$signing_official.'" ORDER BY signing_official ASC ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_within_acted($db_table, $field, $active_year, $month_signed, $target_processing_days) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_signed) = '.$active_year.' AND MONTH(date_signed) = '.$month_signed.' AND due_date >= date_signed AND target_processing_days = "'.$target_processing_days.'" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_duedate_acted($db_table, $field, $active_year, $month_signed, $target_processing_days) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_signed) = '.$active_year.' AND MONTH(date_signed) = '.$month_signed.' AND due_date < date_signed AND target_processing_days = "'.$target_processing_days.'" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_acted_active_year_per_month($db_table, $field, $active_year, $month_acted) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE date_acted != "" AND YEAR(date_received) = '.$active_year.' AND MONTH(date_acted) = '.$month_acted.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	// admin dashboard
	public function admin_count_received_last_year($db_table, $field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE YEAR(date_received) != '.$active_year.' AND appointment_status != "Signed" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function admin_count_month_not_signed_active_year($db_table, $field, $active_year, $month) {
		$sql = 'SELECT '.$field.' FROM '.$db_table.' WHERE appointment_status != "Signed" AND date_received < '.$month.' ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}
}
?>