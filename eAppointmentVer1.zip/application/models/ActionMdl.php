<?php
class ActionMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'action_tbl';
	}

	// crud
	public function add_action($url_key, $action_taken, $signing_status) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, action_taken, signing_status)
			VALUES("'.$url_key.'", "'.$action_taken.'", "'.$signing_status.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_action($url_key, $action_taken, $signing_status) {
		$sql = 'UPDATE '.$this->table.' SET action_taken = "'.$action_taken.'", signing_status = "'.$signing_status.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_action($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function get_action($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY action_taken ASC ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function get_action_signed($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE signing_status = "1" ORDER BY action_taken ASC ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_action($field, $action_taken) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE action_taken = "'.$action_taken.'" ORDER BY action_taken ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>