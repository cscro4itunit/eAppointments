<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Holidays</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar text-primary"></i> <span>Holidays</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li class="active">Holiday</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-plus-circle2"></i> Add Date</b><br>
							<small>Holiday, Occassion, etc.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<form method="post">
							<div class="form-group has-feedback has-feedback-left">
								<label for="particular_date">Particular Date</label>
								<input id="particular_date" name="particular_date" type="date" class="form-control input-xs" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-calendar"></i> 
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="particular">Particular</label>
								<select id="particular" name="particular" class="form-control input-xs" onchange="holiday_particular_fo()">
									<option value="">- Select Particular -</option>
									<option value="National">National Holiday</option>
									<option value="Non Working Day">Non Working Day</option>
									<option value="Special Holiday">Special Holiday - Field Office</option>
								</select>

								<div class="form-control-feedback">
									<i class="icon icon-list-unordered"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="field_office">Field Office</label>
								<select id="field_office" name="field_office" class="form-control input-xs" onchange="holiday_fo_change()">
									<option value="">- Select Field Office -</option>
									<option value="National">National</option>
									<?php
										if (is_array($field_office)) {
											foreach ($field_office as $list) {
												echo '
													<option value="'.$list->fo_tag.'">'.$list->field_office.'</option>
												';
											}
										}

										else {
											echo '
												No Data
											';
										}
									?>
								</select>

								<div class="form-control-feedback">
									<i class="icon icon-city"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="date_description">Date Description</label>
								<input id="date_description" name="date_description" type="text" class="form-control input-xs" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i> 
								</div>
							</div>

							<small>
								<b>NOTE</b>: Check holiday first if existed before adding.
							</small>

							<br><br>
							
							<button onclick="add_holiday()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-plus-circle2 position-left"></i> Add date
							</button>

							
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> List of Holidays</b><br>
							<small>National and Field Office/s</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
							<thead>
								<tr>
									<th>Date</th>
									<th>Particular</th>
									<th>Field Office</th>
									<th>Description</th>
									<th>Created on</th>
								</tr>
							</thead>

							<tbody>
								<?php
									if (is_array($fetch_holiday)) {
										foreach ($fetch_holiday as $list) {
											echo '
												<tr>
													<td>
														<a href="'.base_url('manage-holidays-details').'?holiday='.$list->url_key.'">
															'.$list->particular_date.'
														</a>
													</td>
													<td>'.$list->particular.'</td>
													<td>'.$list->field_office.'</td>
													<td>'.$list->date_description.'</td>
													<td>'.$list->created_on.'</td>
												</tr>
											';
										}
									}

									else {
										echo '
											<tr>
												<td colspan="5">No data</td>
											</tr>
										';
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->