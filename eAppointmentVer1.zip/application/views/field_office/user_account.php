<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - My Account</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-user text-primary"></i> <span>Account</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li>My Account</li>
				<li class="active">Update</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<form method="post" id="imgFile" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-3">
					<div class="content-group">
						<div class="panel-body bg-indigo-400 border-radius-top text-center" style="background-size: contain;">
							<div class="content-group-sm">
								<h6 class="text-semibold no-margin-bottom">
									<?=$user_details['fn']?>&nbsp;<?=$user_details['mi']?>&nbsp;<?=$user_details['ln']?>
								</h6>

								<span class="display-block"><?=$user_details['position']?></span>
							</div>

							<a href="#" class="display-inline-block content-group-sm">
								<img src="<?=base_url().'assets/images/user/'?><?=$user_details['image']?>" class="img-circle img-responsive" alt="" style="width: 110px; height: 110px;border:1px solid #000;">
							</a>

							<div class="form-group">
								<label class="display-block">Upload profile image</label>
	                            <input type="file" class="file-styled" name="image" id="image">
	                            <span class="help-block" style="color: #000;">Accepted formats: png, jpg. Max file size 2Mb</span>
	                        </div>

                        	<button onclick="update_image()" type="button" class="btn btn-success btn-xs">
								<i class="icon-reset"></i> Change
							</button>
						</div>
					</div>

					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-user"></i> Account Setting</b><br>
								<small>Username and Password.</small>
							</h6>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<p><b>Username: </b><?=$user_details['username']?></p>

							<div class="form-group has-feedback has-feedback-left">
								<input id="new_username" name="new_username" type="text" class="form-control input-xs" placeholder="Enter New Username" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<button onclick="update_username()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-reset"></i> Change Username
							</button>

							<br><br><br>

							<p><b>Change Password</b></p>

							<div class="form-group has-feedback has-feedback-left">
								<input id="new_password" name="new_password" type="password" class="form-control input-xs" placeholder="Enter New Password" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-lock"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="retype_username" name="retype_username" type="password" class="form-control input-xs" placeholder="Retype New Password" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-lock"></i>
								</div>
							</div>

							<button onclick="update_password()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-reset"></i> RESET Password
							</button>
						</div>
					</div>
				</div>

				<div class="col-md-9">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-vcard"></i> Personal Information</b><br>
								<small>Update personal data.</small>
							</h6>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<div class="row">
								<div class="col-md-4">
									<div class="form-group has-feedback has-feedback-left">
										<label for="fn">Firstname</label>
										<input id="fn" name="fn" type="text" class="form-control input-xs" placeholder="Firstname" autocomplete="off" value="<?=$user_details['fn']?>">
										<div class="form-control-feedback">
											<i class="icon icon-user"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="gender">Gender</label>
										<select id="gender" name="gender" class="form-control input-xs">
											<?php
												echo '
													<option value="'.$user_details['gender'].'">'.$user_details['gender'].'</option>
												';
											?>
											<option disabled>--------------------------</option>
											<option value="Male">Male</option>
											<option value="Female">Female</option>
										</select>
										<div class="form-control-feedback">
											<i class="icon icon-man-woman"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="position">Position</label>
										<select class="form-control input-xs" id="position" name="position">
											<option value="<?=$user_details['position']?>"><?=$user_details['position']?></option>
											<option disabled>--------------------------</option>
											<?php
												if (is_array($position)) {
													foreach ($position as $list) {
														echo '
															<option value="'.$list->position.'">'.$list->position.'</option>
														';
													}
												}

												else {
													echo 'No data found!';
												}
											?>
										</select>
										<div class="form-control-feedback">
											<i class="icon icon-user-tie"></i>
										</div>
									</div>
								</div>

								<div class="col-md-4">
									<div class="form-group has-feedback has-feedback-left">
										<label for="mi">Middle Initial</label>
										<input id="mi" name="mi" type="text" class="form-control input-xs" placeholder="Middle Intial (Optional)" autocomplete="off" value="<?=$user_details['mi']?>">
										<div class="form-control-feedback">
											<i class="icon icon-user"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="contact">Contact</label>
										<input id="contact" name="contact" type="text" class="form-control input-xs" placeholder="Contact" autocomplete="off" value="<?=$user_details['contact']?>">
										<div class="form-control-feedback">
											<i class="icon icon-phone2"></i>
										</div>
									</div>

									
								</div>

								<div class="col-md-4">
									<div class="form-group has-feedback has-feedback-left">
										<label for="ln">Last Name</label>
										<input id="ln" name="ln" type="text" class="form-control input-xs" placeholder="Last Name" autocomplete="off" value="<?=$user_details['ln']?>">
										<div class="form-control-feedback">
											<i class="icon icon-user"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="email_add">Email</label>
										<input id="email_add" name="email_add" type="text" class="form-control input-xs" placeholder="Email Add" autocomplete="off" value="<?=$user_details['email_add']?>">
										<div class="form-control-feedback">
											<i class="icon icon-envelop"></i>
										</div>
									</div>
								</div>
							</div>

							<button onclick="update_personal_info()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-reset"></i> Update Information
							</button>
						</div>
					</div>

					<div class="row">
						<div class="col-md-6">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h6 class="panel-title">
										<b><i class="icon-lock"></i> Security</b><br>
										<small>For account retrival.</small>
									</h6>
									<div class="heading-elements">
										<ul class="icons-list">
					                		<li><a data-action="collapse"></a></li>
					                	</ul>
				                	</div>
								</div>
								
								<div class="panel-body">
									<div class="form-group has-feedback has-feedback-left">
										<label for="security_question">Security Question</label>
										<select class="form-control input-xs" id="security_question" name="security_question">
											<?php
												if ($user_details['security_question'] == "") {
													echo '
														<option value="">Security question not set.</option>
													';
												}

												else {
													echo '
														<option value="'.$user_details['security_question'].'">
															'.$user_details['security_question'].'
														</option>
													';
												}
											?>
											<option disabled>--------------------------</option>
											<?php
												if (is_array($security_questions)) {
													foreach ($security_questions as $list) {
														echo '
															<option value="'.$list->security_question.'">'.$list->security_question.'</option>
														';
													}
												}

												else {
													echo 'No data found!';
												}
											?>
										</select>
										<div class="form-control-feedback">
											<i class="icon icon-question4"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="security_answer">Security Answer</label>
										<input id="security_answer" name="security_answer" type="password" class="form-control input-xs" placeholder="Security Answer" autocomplete="off" value="<?=$user_details['security_answer']?>">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i>
										</div>
									</div>

									<button onclick="update_security()" type="button" class="btn btn-primary btn-xs pull-right">
										<i class="icon-reset"></i> Update Security
									</button>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</form>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->