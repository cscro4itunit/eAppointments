<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$showinfo['title']?></title>
	<link rel="icon" href="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>">

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">

	<link href="<?=base_url().'assets/css/icons/icomoon/styles.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/core.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/components.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/colors.css'?>" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- SWEETALERT -->
    <link rel="stylesheet" href="<?=base_url().'assets/sweetalert/sweetalert.css'?>">
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert-dev.js'?>"></script>
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert.min.js'?>"></script>
</head>

<body class="login-container">
	<!-- includes -->
	<input type="hidden" id="base_url" value="<?=base_url()?>">

	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?=base_url('cscro4/user/login')?>"><b><?=$showinfo['agency']?></b></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav navbar-right">
				<a class="navbar-brand" href="<?=base_url('cscro4/user/login')?>"><b><?=$showinfo['header']?></b></a>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Content area -->
				<div class="content">
					<!-- Simple login form -->
					<form method="post">
						<div class="panel panel-body login-form">
							<div class="text-center">
								<div class="icon-object border-slate-300 text-slate-300" style="width: 50%;">
									<img src="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>" style="width: 100%;">
								</div>

								<h5 class="content-group">
									Login to your Account<br>
									<small class="display-block">Field Officer</small>
								</h5>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="username" name="username" type="text" class="form-control" placeholder="Username" required>
								<div class="form-control-feedback">
									<i class="icon-user text-muted"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="password" name="password" type="password" class="form-control" placeholder="Password" required>
								<div class="form-control-feedback">
									<i class="icon-lock2 text-muted"></i>
								</div>
							</div>

							<div class="form-group">
								<button onclick="user_login()" id="mySubmitLogin" type="button" class="btn bg-primary btn-block btn-xs">
									Sign in <i class="icon-circle-right2 position-right"></i>
								</button>
							</div>

							<!-- <div class="text-center">
								<a href="login_password_recover.html">Forgot password?</a>
							</div> -->
						</div>
					</form>
					<!-- /simple login form -->

					<!-- Footer -->
					<div class="footer text-muted text-center">
						<?=$showinfo['footer']?>
					</div>
					<!-- /footer -->
				</div>
				<!-- /content area -->
			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->
	</div>
	<!-- /page container -->
</body>
</html>

<!-- Core JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/pace.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/jquery.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/bootstrap.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/blockui.min.js'?>"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/core/app.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/ui/ripple.min.js'?>"></script>
<!-- /theme JS files -->

<script type="text/javascript">
	var input = document.getElementById("username");
	var input = document.getElementById("password");
	input.addEventListener("keyup", function(event) {
	  	if (event.keyCode === 13) {
	  	 	event.preventDefault();
	   		document.getElementById("mySubmitLogin").click();
	  	}
	});

	function user_login() {
		// declaring global baseurl
		var baseUrl = $('#base_url').val();
		var username = $('#username').val();
		var password = $('#password').val();

		var action = 'submit';

		var data     = {
			username: username,
			password: password,
			action: action
		};

		if (username == "" || password == "") {
			$('#username').focus();
			alert('Empty Fields!');
			return false;
		}

		else {
			$.post(baseUrl + 'UserAuth', data, function(responce) {
				var data = JSON.parse(responce);
				var url = data.url;

				if (data.status == 'success') {
					swal ({
						title: data.title,
		                text: data.message,
		                type: data.status,
		                timer: 1000,
		                showConfirmButton: false
		            }, function() {
		               	window.location.href = url;
					});
				}

				else {
					swal({
		                title: data.title,
		                text: data.message,
		                type: data.status,
		                timer: 1000,
		                showConfirmButton: false
		            });
				}
			});
		}
	}
</script>