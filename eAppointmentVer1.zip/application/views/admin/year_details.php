<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Manage Settings</span> - Active Year Details</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar2 text-primary"></i> <span>Annual Year</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-wrench position-left"></i> Settings</li>
				<li>Annual Year</li>
				<li class="active">Details</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-calendar2"></i> Annual Year</b><br>
							<small>Manage details.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<p>
							<b>Position</b>: <?=$year_details['active_year']?><br>
							<b>Created On</b>: <?=$year_details['created_on']?>
						</p>

						<?php
							if ($year_details['status'] == 0) {
								echo '
									<button onclick="activate_year()" type="button" class="btn btn-success btn-xs pull-left">
										<i class="icon-checkmark-circle2 position-left"></i> Set Active Year
									</button>
								';
							}

							else {
								echo '
									<button onclick="deactivate_year()" type="button" class="btn btn-warning btn-xs pull-left">
										<i class="icon-close2 position-left"></i> Deactivate Year
									</button>
								';
							}
						?>

						<button onclick="delete_year()" type="button" class="btn btn-danger btn-xs pull-right" >
							<i class="icon-trash position-left"></i> Delete Year
						</button>
					</div>
				</div>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->