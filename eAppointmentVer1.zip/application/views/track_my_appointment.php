<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$showinfo['title']?></title>
	<link rel="icon" href="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>">

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">

	<link href="<?=base_url().'assets/css/icons/icomoon/styles.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/core.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/components.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/colors.css'?>" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- SWEETALERT -->
    <link rel="stylesheet" href="<?=base_url().'assets/sweetalert/sweetalert.css'?>">
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert-dev.js'?>"></script>
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert.min.js'?>"></script>

   
</head>

<body class="login-container">
	<!-- includes -->
	<input type="hidden" id="base_url" value="<?=base_url()?>">

	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?=base_url('')?>"><b><?=$showinfo['agency']?></b></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav navbar-right">
				<a class="navbar-brand" href="<?=base_url('')?>"><b><?=$showinfo['header']?></b></a>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Content area -->
				<div class="content">
					<div class="row">
						<div class="col-md-3">&nbsp;</div>

						<div class="col-md-6">
							<center>
								<img src="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>" class="img img-responsive" style="width: 120px;">

								<h4><b>APPOINTMENT TRACKING SYSTEM</b></h4>
							</center>
							
							<br>

							<div class="panel panel-default">
								<div class="panel-heading">
									<h6 class="panel-title">
										<b><i class="icon-user"></i> <?=$appointment_data['appointee']?></b><br>
										<small>
											Appointment Information and Details<br>
										</small>
									</h6>

									<div class="heading-elements">
										<a href="<?=base_url('')?>" class="btn btn-primary btn-xs">
											<i class="icon icon-search4"></i> Search Again
										</a>
					            	</div>
								</div>
								
								<div class="panel-body">
									<center><b><?=$appointment_data['unique_id_number']?></b><br>
									<small>
										<?=$appointment_data['agency_name']?> | <?=$appointment_data['employment_status']?><br>
										<?=$appointment_data['position_title']?> | Salary Grade <?=$appointment_data['salary_grade']?>
									</small></center>

									<br>

									<?php
										$date_received = new DateTime($appointment_data['date_received']);
										$received_date = date_format($date_received, "F d, Y");

										$date_acted = new DateTime($appointment_data['date_acted']);
										$acted_on = date_format($date_acted, "F d, Y");

										$date_signed = new DateTime($appointment_data['date_signed']);
										$signed_on = date_format($date_acted, "F d, Y");

										if ($appointment_data['appointment_status'] == "Received") {
											echo '
												<center>
													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>RECEIVED</b> on '.$received_date.'.

													<br><br><br><br>
												</center>
											';
										}

										elseif ($appointment_data['appointment_status'] == "Acted") {
											echo '
												<div style="margin-left:25%;">
													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>RECEIVED</b> on '.$received_date.'.

													<br>

													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>PROCESSED</b> on '.$acted_on.'

													<br><br><br><br>
												</div>
											';
										}

										elseif ($appointment_data['appointment_status'] == "Signed") {
											echo '
												<div style="margin-left:25%;">
													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>RECEIVED</b> on '.$received_date.'.

													<br>

													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>PROCESSED</b> on '.$acted_on.'

													<br>

													<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
														<i class="icon-checkmark4"></i> 
													</a>&emsp;<b>SIGNED</b> on '.$acted_on.'

													<br>
												</div>
											';

											if ($appointment_data['date_released'] != "") {
												echo '
													<div style="margin-left:25%;">
														<a href="#" class="btn border-primary text-primary btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
															<i class="icon-checkmark4"></i> 
														</a>&emsp;<b>RELEASED</b> on '.$appointment_data['date_released'].'
													</div>
												';
											}

											else {
												echo '
													<div style="margin-left:25%;">
														<a href="#" class="btn border-danger text-danger btn-flat btn-icon btn-rounded btn-xs" style="margin-bottom:7px;">
															<i class="icon-cross"></i> 
														</a>&emsp;For Release
													</div>
												';
											}
										}
									?>
								</div>
							</div>
						</div>

						<div class="col-md-3">&nbsp;</div>
					</div>

					<br><br><br>

					<!-- Footer -->
					<div class="footer text-muted text-center">
						<b><?=$showinfo['header']?></b><br>
						<?php
							foreach ($fetch_by_fo_tag as $list) {
								echo '
									'.$list->field_office.'
								';
							}
						?>
						<br>
						<?=$showinfo['footer']?>
					</div>
					<!-- /footer -->
				</div>
				<!-- /content area -->
			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->
	</div>
	<!-- /page container -->
</body>

</html>

<!-- Core JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/pace.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/jquery.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/bootstrap.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/blockui.min.js'?>"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/core/app.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/ui/ripple.min.js'?>"></script>
<!-- /theme JS files -->

<!-- custom JS -->
<script src='<?=base_url()."assets/js/custom/$jscript.js"?>'></script>