<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$showinfo['title']?></title>
	<link rel="icon" href="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>">

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">

	<link href="<?=base_url().'assets/css/icons/icomoon/styles.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/core.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/components.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/colors.css'?>" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- SWEETALERT -->
    <link rel="stylesheet" href="<?=base_url().'assets/sweetalert/sweetalert.css'?>">
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert-dev.js'?>"></script>
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert.min.js'?>"></script>
</head>

<body class="login-container">
	<!-- includes -->
	<input type="hidden" id="base_url" value="<?=base_url()?>">

	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?=base_url('')?>"><b><?=$showinfo['agency']?></b></a>

			<ul class="nav navbar-nav pull-right visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav navbar-right">
				<a class="navbar-brand" href="<?=base_url('')?>"><b><?=$showinfo['header']?></b></a>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main content -->
			<div class="content-wrapper">
				<!-- Content area -->
				<div class="content">
					<!-- Simple login form -->
					<div class="panel panel-body login-form">
						<div class="text-center">
							<div class="icon-object border-slate-300 text-slate-300" style="width: 50%;">
								<img src="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>" style="width: 100%;">
							</div>
							
							<h5 class="content-group">
								Track My Appointment<br>
								<small class="display-block">Enter Valid Information</small>
							</h5>
						</div>

						<div class="form-group has-feedback has-feedback-left">
							<select id="field_office" name="field_office" class="form-control">
								<option value="">- Select Field Office</option>
								<?php
									if (is_array($field_office)) {
										foreach ($field_office as $list) {
											if ($list->fo_tag == "psed") {
												$add_tag = "&nbsp;- SG 26 and up";
											} else {
												$add_tag = "";
											}
											
											echo '
												<option value="'.$list->fo_tag.'">'.$list->field_office.''.$add_tag.'</option>
											';
										}
									}

									else {
										echo '<option>No Data Found!</option>';
									}
								?>
							</select>

							<div class="form-control-feedback">
								<i class="icon-office text-muted"></i>
							</div>
						</div>

						<div class="form-group has-feedback has-feedback-left">
							<input id="unique_id_number" name="unique_id_number" type="text" class="form-control" placeholder="Appointment Code" required autocomplete="off">
							<div class="form-control-feedback">
								<i class="icon-price-tag2 text-muted"></i>
							</div>
						</div>

						<div class="form-group">
							<button onclick="search_appointment()" id="mySubmitSearch" type="button" class="btn bg-primary btn-block btn-xs">
								<i class="icon-search4"></i> Search
							</button>
						</div>
					</div>
					<!-- /simple login form -->

					<!-- Footer -->
					<div class="footer text-muted text-center">
						<?=$showinfo['footer']?>
					</div>
					<!-- /footer -->
				</div>
				<!-- /content area -->
			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->
	</div>
	<!-- /page container -->
</body>
</html>

<!-- Core JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/pace.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/jquery.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/core/libraries/bootstrap.min.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/loaders/blockui.min.js'?>"></script>
<!-- /core JS files -->

<!-- Theme JS files -->
<script type="text/javascript" src="<?=base_url().'assets/js/core/app.js'?>"></script>
<script type="text/javascript" src="<?=base_url().'assets/js/plugins/ui/ripple.min.js'?>"></script>
<!-- /theme JS files -->

<script type="text/javascript">
	var input = document.getElementById("field_office");
	var input = document.getElementById("unique_id_number");
	input.addEventListener("keyup", function(event) {
	  	if (event.keyCode === 13) {
	  	 	event.preventDefault();
	   		document.getElementById("mySubmitSearch").click();
	  	}
	});
</script>

<!-- custom JS -->
<script src='<?=base_url()."assets/js/custom/$jscript.js"?>'></script>