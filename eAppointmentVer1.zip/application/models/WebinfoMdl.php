<?php
class WebinfoMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'webinfo_tbl';
	}

	// crud

	// modify
	public function show_webinfo() {
		$sql = 'SELECT * FROM '.$this->table;
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ? $query->row_array() : NULL;
	}

	public function update_icon($id, $realname) {
		$sql = 'UPDATE '.$this->table.' SET icon = "'.$realname.'" WHERE id = "'.$id.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_web_info($id, $title, $header, $footer, $agency, $tel_num, $email_add, $address, $office_hr) {
		$sql = 'UPDATE '.$this->table.' SET title = "'.$title.'", header = "'.$header.'", footer = "'.$footer.'", agency = "'.$agency.'", tel_num = "'.$tel_num.'", email_add = "'.$email_add.'", address = "'.$address.'", office_hr = "'.$office_hr.'" WHERE id = "'.$id.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_basic_info($id, $title, $header, $footer, $agency, $tel_num, $email_add, $address, $office_hr) {
		$sql = 'UPDATE '.$this->table.' SET title = "'.$title.'", header = "'.$header.'", footer = "'.$footer.'", agency = "'.$agency.'", tel_num = "'.$tel_num.'", email_add = "'.$email_add.'", address = "'.$address.'", office_hr = "'.$office_hr.'" WHERE id = "'.$id.'" ';
        $query = $this->db->query($sql);
        return $query;
	}
}
?>