<?php
class EmpStatusMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'employment_status_tbl';
	}

	// crud
	public function add_employment_status($url_key, $employment_status) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, employment_status)
			VALUES("'.$url_key.'", "'.$employment_status.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_employment_status($url_key, $employment_status) {
		$sql = 'UPDATE '.$this->table.' SET employment_status = "'.$employment_status.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_employment_status($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// modify
	public function fetch_employment_status($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY employment_status ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_status_employment($field, $employment_status) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE employment_status = "'.$employment_status.'" ORDER BY employment_status ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>