<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class LoginCtrl extends CI_Controller {
	private $data;

	public function __construct() {
		parent:: __construct();
		// set internet timezone
		date_default_timezone_set('Asia/Manila');
		
		include 'includes/models.php';
		// callout session that was set after login
		$this->accnt_id = $this->session->userdata('session_id');

		// select * details of user
		$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

		if ($this->accnt_id != "") {
			switch ($this->data['user_id_details']['role']) {
				case 0:
					redirect(base_url('administrator'));
					break;

				case 1:
					redirect(base_url('dashboard'));
					break;
				
				default:
					base_url('cscro4/admin/login');
					break;
			}
		}
	}

	// NAVIGATION
	public function admin_login() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
		);

		$this->load->view('admin/admin_login', $this->data);
	}

	public function user_login() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
		);

		$this->load->view('field_office/user_login', $this->data);
	}

	// FUNCTION
	public function AdminAuth() {
		if (isset($_POST['action']) == 'submit') {
			$username =$this->input->post('username');
			$password =$this->input->post('password');

			// validate user account existence
			$validate = $this->AccntMdl->username_auth('*', $username);
			
			if ($validate > 0) {
				if (password_verify($password, $validate['password'])) {
					if ($validate['role'] == '0' AND $validate['active_status'] == '1') {
						$this->session->set_userdata(array('session_id' => $validate['id']));

						$title = 'Logged!';
						$status = 'success';
						$message = 'Redirecting to dashboard page.';
						$url = base_url('administrator');
					}

					elseif ($validate['role'] == '0'AND $validate['active_status'] == '0') {
						$title = 'Account Status!';
						$status = 'error';
						$message = 'Please contact your system administrator.';
						$url = '';
					}

					else {
						$title = 'Invalid!';
						$status = 'error';
						$message = 'Invalid account.';
						$url = '';
					}
				}

				else {
					$title = 'Password!';
					$status = 'warning';
					$message = 'Invalid password.';
					$url = '';
				}
			}

			else {
				$title = 'Login';
				$status = 'error';
				$message = 'Username dont exist.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UserAuth() {
		if (isset($_POST['action']) == 'submit') {
			$username =$this->input->post('username');
			$password =$this->input->post('password');

			// validate user account existence
			$validate = $this->AccntMdl->username_auth('*', $username);
			
			if ($validate > 0) {
				if (password_verify($password, $validate['password'])) {
					if ($validate['role'] == '1' AND $validate['active_status'] == '1') {
						$this->session->set_userdata(array('session_id' => $validate['id']));

						$title = 'Logged!';
						$status = 'success';
						$message = 'Redirecting to dashboard page.';
						$url = base_url('dashboard');
					}

					elseif ($validate['role'] == '1' AND $validate['active_status'] == '0') {
						$title = 'Account Status!';
						$status = 'error';
						$message = 'Please contact your system administrator.';
						$url = '';
					}

					else {
						$title = 'Invalid!';
						$status = 'error';
						$message = 'Invalid account.';
						$url = '';
					}
				}

				else {
					$title = 'Password!';
					$status = 'warning';
					$message = 'Invalid password.';
					$url = '';
				}
			}

			else {
				$title = 'Login';
				$status = 'error';
				$message = 'Username dont exist.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}
}
?>