<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class ApptProcessCtrl extends CI_Controller {
	private $data;

	public function __construct() {
		parent:: __construct();
		// including all models
		include 'includes/models.php';

		// callout session that was set after login
		$this->accnt_id = $this->session->userdata('session_id');

		// select * details of user
		$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);
		
		if ($this->data['user_id_details'] > 0) {
			// include all the necessary functions with regards in appontment processing 
			include 'includes/appt_extension.php';
			
			// print_r($load_fo_data);

			if (!isset($this->accnt_id)) {
				redirect(base_url(''));
			}

			else {
				$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

				switch ($this->data['user_id_details']['role']) {
					case '0':
						redirect(base_url('error-404'));
						break;
					
					case '1':
						base_url('dashboard');
						break;

					default:
						redirect(base_url('cscro4/user/login'));
						break;
				}
			}
		}

		else {
			redirect(base_url(''));
		}
	}

	// NAVIGATION
	public function appointment() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt',
			'jscript' => 'appointment',
			'fetch_appointment_by_current_year' => $this->AppointmentMdl->fetch_appointment_by_current_year($this->data['db_table'], 'unique_id_number, date_received, agency_name, appointee, position_title, due_date, appointment_status'),
			'fetch_fo_users' => $this->AccntMdl->fetch_fo_users('id, fn, ln, user_type', $this->data['user_id_details']['field_office']),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appointment', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function appointment_process() {
		if ($this->data['user_id_details']['field_office'] == "psed") {
			$fetch_agency = $this->AgencyMdl->fetch_agency('*');
		}

		else {
			$fetch_agency = $this->AgencyMdl->fetch_agency_by_fo('*', $this->data['user_id_details']['field_office']);
		}

		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt_process',
			'jscript' => 'appointment',
			'fetch_sector' => $this->SectorMdl->fetch_sector('*'),
			'fetch_agency' => $fetch_agency,
			'fetch_employment_status' => $this->EmpStatusMdl->fetch_employment_status('*'),
			'fetch_appt_nature' => $this->ApptNatureMdl->fetch_appt_nature('*'),
			'fetch_eligibility' => $this->EligibilityMdl->fetch_eligibility('*'),
			'fetch_disability' => $this->DisabilityMdl->fetch_disability('*'),
			'fetch_ethnicity' => $this->EthnicityMdl->fetch_ethnicity('*'),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appointment_process', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function appontments_processing_pending() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt_process_pending',
			'jscript' => 'appointment',
			'fetch_pending' => $this->AppointmentMdl->fetch_pending_appointment($this->data['db_table'], '*'),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$date_now = date('Y-m-d');
		$field_office = $this->data['user_details']['field_office'];

		$build_array = array();
		if (is_array($this->data['fetch_pending'])) {
			foreach ($this->data['fetch_pending'] as $dates) {
				$pending_dates[] = array(
					'appointment_data' => $dates,
					'count_between_holiday' => $this->HolidayMdl->count_between_holiday($field_office, $dates->date_received, $date_now),
					'count_between_assigned_holiday' => $this->HolidayMdl->count_between_assigned_holiday($field_office, $dates->date_received, $date_now),
				);
			}

			$this->data['build_array'] = $pending_dates;
		}

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appt_pending', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function appontments_processing_pending_update() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
			);
			
			$this->load->view('field_office/error_405', $this->data);
		}

		else {
			$url_key = $_GET['id'];
			$auth_url = $this->AppointmentMdl->url_auth($this->data['db_table'], '*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'user_details' => $this->data['user_id_details'],
					'nav' => 'appt_process_pending',
					'jscript' => 'appointment',
					'fetch_appt_details' => $auth_url,
					'get_action' => $this->ActionMdl->get_action('*'),
					'encoded_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['encoded_by']),
					// count
					'count_received_total' => $this->data['count_received_total'],
					'count_pending' => $this->data['count_pending'],
					'count_acted' => $this->data['count_acted'],
					'count_signed' => $this->data['count_signed'],
				);

				$this->load->view('field_office/includes/header', $this->data);
				$this->load->view('field_office/appt_pending_update', $this->data);
				$this->load->view('field_office/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
				);

				$this->load->view('field_office/error_403', $this->data);
			}
		}
	}

	public function appontments_processing_acted() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt_process_acted',
			'jscript' => 'appointment',
			'fetch_acted' => $this->AppointmentMdl->fetch_acted_appointment($this->data['db_table'], '*'),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$build_array = array();
		if (is_array($this->data['fetch_acted'])) {
			foreach ($this->data['fetch_acted'] as $row) {
				$processor[] = array(
					'count_processor' => $row,
					'get_processor' => $this->AccntMdl->fetch_by_id('id, fn, ln', $row->processor),
				);
			}

			$this->data['build_array'] = $processor;
		}

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appt_acted', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function appontments_processing_acted_update() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
			);
			
			$this->load->view('field_office/error_405', $this->data);
		}

		else {
			$url_key = $_GET['id'];
			$auth_url = $this->AppointmentMdl->url_auth($this->data['db_table'], '*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'user_details' => $this->data['user_id_details'],
					'nav' => 'appt_process_acted',
					'jscript' => 'appointment',
					'fetch_appt_details' => $auth_url,
					'get_action' => $this->ActionMdl->get_action_signed('*'),
					'encoded_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['encoded_by']),
					'processed_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['processor']),
					// count
					'count_received_total' => $this->data['count_received_total'],
					'count_pending' => $this->data['count_pending'],
					'count_acted' => $this->data['count_acted'],
					'count_signed' => $this->data['count_signed'],
				);

				$this->load->view('field_office/includes/header', $this->data);
				$this->load->view('field_office/appt_acted_update', $this->data);
				$this->load->view('field_office/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
				);

				$this->load->view('field_office/error_403', $this->data);
			}
		}
	}

	public function appontments_processing_signed() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt_process_signed',
			'jscript' => 'appointment',
			'fetch_signed' => $this->AppointmentMdl->fetch_signed_appointment($this->data['db_table'], '*'),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$build_array = array();
		if (is_array($this->data['fetch_signed'])) {
			foreach ($this->data['fetch_signed'] as $row) {
				$signed[] = array(
					'count_signed' => $row,
					'get_signed' => $this->AccntMdl->fetch_by_id('id, fn, ln', $row->signing_official),
				);
			}

			$this->data['build_array'] = $signed;
		}

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appt_signed', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function appontments_processing_signed_details() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
			);
			
			$this->load->view('field_office/error_405', $this->data);
		}

		else {
			$url_key = $_GET['id'];
			$auth_url = $this->AppointmentMdl->url_auth($this->data['db_table'], '*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'user_details' => $this->data['user_id_details'],
					'nav' => 'appt_process_signed',
					'jscript' => 'appointment',
					'fetch_appt_details' => $auth_url,
					'encoded_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['encoded_by']),
					'processed_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['processor']),
					'signed_by' => $this->AccntMdl->user_id_details('id, fn, ln', $auth_url['signing_official']),
					// count
					'count_received_total' => $this->data['count_received_total'],
					'count_pending' => $this->data['count_pending'],
					'count_acted' => $this->data['count_acted'],
					'count_signed' => $this->data['count_signed'],
				);

				$this->load->view('field_office/includes/header', $this->data);
				$this->load->view('field_office/appt_signed_details', $this->data);
				$this->load->view('field_office/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
				);

				$this->load->view('field_office/error_403', $this->data);
			}
		}
	}

	public function appontments_data() {
		$starting_date = $this->session->userdata('starting_date');
		$ending_date = $this->session->userdata('ending_date');
		$field_officer = $this->session->userdata('field_officer');
		$search_appointment_status = $this->session->userdata('search_appointment_status');

		if ($field_officer == "" AND $search_appointment_status == "") {
			$fetch_appt_between_date_range = $this->AppointmentMdl->fetch_appt_between_date_range($this->data['db_table'], $starting_date, $ending_date);
		}

		else if ($field_officer != "" AND $search_appointment_status == "") {
			$fetch_appt_between_date_range = $this->AppointmentMdl->fetch_appt_between_date_range_fo($this->data['db_table'], $starting_date, $ending_date, $field_officer);
		}

		else {
			if ($search_appointment_status == "Acted") {
				$fetch_appt_between_date_range = $this->AppointmentMdl->fetch_appt_between_date_range_acted($this->data['db_table'], $starting_date, $ending_date, $field_officer);
			}

			else if ($search_appointment_status == "Signed") {
				$fetch_appt_between_date_range = $this->AppointmentMdl->fetch_appt_between_date_range_signed($this->data['db_table'], $starting_date, $ending_date, $field_officer);
			}

			else {
				$fetch_appt_between_date_range = $this->AppointmentMdl->fetch_appt_between_date_range_status($this->data['db_table'], $starting_date, $ending_date, $search_appointment_status);
			}
		}

		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'appt_process_signed',
			'jscript' => 'appointment',
			'fetch_appt_between_date_range' => $fetch_appt_between_date_range,
			'get_date_from' => $starting_date,
			'get_date_to' => $ending_date,
			'fetch_fo_users' => $this->AccntMdl->fetch_fo_users('id, fn, ln, user_type', $this->data['user_id_details']['field_office']),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
		);

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/appontment_data_per_date_range', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	// FUNCTION
	public function AddAppointment() {
		if ($_POST['action'] == 'submit') {
			// from ajax
			$date_received = $this->input->post('date_received');
			$sector = $this->input->post('sector');
			$agency_name = $this->input->post('agency_name');
			$appointee = $this->input->post('appointee');
			$position_title = $this->input->post('position_title');
			$salary_grade = $this->input->post('salary_grade');
			$position_level = $this->input->post('position_level');
			$employment_status = $this->input->post('employment_status');
			$appointment_nature = $this->input->post('appointment_nature');
			$inclusive_date_casual_from = $this->input->post('inclusive_date_casual_from');
			$inclusive_date_casual_to = $this->input->post('inclusive_date_casual_to');
			$appointing_authority = $this->input->post('appointing_authority');
			$issuance_date = $this->input->post('issuance_date');
			$birthday = $this->input->post('birthday');
			$sex = $this->input->post('sex');
			$pwd = $this->input->post('pwd');
			$disability = $this->input->post('disability');
			$member_ip_group = $this->input->post('member_ip_group');
			$ethnicity = $this->input->post('ethnicity');
			$eligibility_type = $this->input->post('eligibility_type');
			$eligibility_effective_date = $this->input->post('eligibility_effective_date');
			$time_used_of_eligibility = $this->input->post('time_used_of_eligibility');

			$url_key = md5(uniqid(rand(), true));
			$encoded_by = $this->session->userdata('session_id');
			$appointment_status = 'Received';

			// call the specific table on where to save the appointment
			$db_table = $this->data['db_table'];

			// target processing days - 20 working days for 150 appointments below and 40 working days for above 150 appointments
			// count received appointment within the day
			$count_received_per_day = $this->AppointmentMdl->count_received_per_day($this->data['db_table'], 'date_received', $date_received);
			if ($count_received_per_day > 150) {
				$target_processing_days = '40';
			}

			else {
				$target_processing_days = '20';
			}

			// computing due date
			// creating date from receive
			$received_date = date_create($date_received);
			// assigning working day(s) interval for due date(s)
			$temp_processing_days = $target_processing_days.' days';
			date_add($received_date, date_interval_create_from_date_string($temp_processing_days));
			$temp_date = date_format($received_date, 'Y-m-d');
			// counting sat and sun
			$start = new DateTime($date_received);
			$end = new DateTime($temp_date);
			$days = $start->diff($end, true)->days;
			$sundays = intval($days / 7) + ($start->format('N') + $days % 7 >= 7);
			$saturday = intval($days / 7) + ($start->format('N') + $days % 6 >= 6);
			$count_weekends = $sundays + $saturday;
			$processing_day_with_weekends = $target_processing_days + $count_weekends + 1;
			$temp_processing_day_with_weekends = $processing_day_with_weekends.' days';
			// date excluded weekends
			$excluded_weekend_date = date_create($date_received);
			date_add($excluded_weekend_date, date_interval_create_from_date_string($temp_processing_day_with_weekends));
			$temp_due_date = date_format($excluded_weekend_date, 'Y-m-d');
			// count holiday(s) between this date
			$count_assigned_holiday = $this->HolidayMdl->count_between_assigned_holiday($this->data['user_id_details']['field_office'], $date_received, $temp_due_date);
			$count_holiday = $this->HolidayMdl->count_between_holiday('National', $date_received, $temp_due_date);
			// final count
			$final_count = $count_assigned_holiday + $processing_day_with_weekends + $count_holiday;
			$processing_days = $final_count.' days';
			$date = date_create($date_received);
			date_add($date, date_interval_create_from_date_string($processing_days));
			$due_date = date_format($date, 'Y-m-d');
			// count non working days including holidays
			$num_none_wd = $count_weekends + $count_assigned_holiday + $count_holiday;

			// generate key
			$appt_received_by_current_year = $this->data['count_received_current_year'];
			$add_appontment = $appt_received_by_current_year + 1;
			$generated_id = $this->data['unique_key_starter'].'-'.date('Y').'-'.$add_appontment;
			// validate id for duplication
			$validate_unique_key = $this->AppointmentMdl->auth_unique_key($db_table, 'unique_id_number', $generated_id);

			if ($validate_unique_key != false) {
				// recount table received
				$recount_table_received = $this->AppointmentMdl->count_received_current_year($this->data['db_table'], '*', $this->data['current_year']);
				$new_count = $recount_table_received + 1;
				$unique_id_number = $this->data['unique_key_starter'].'-'.date('Y').'-'.$new_count;
			}

			else {
				$unique_id_number = $generated_id;
			}

			$save_appointment = $this->AppointmentMdl->add_appointment($db_table, $url_key, $unique_id_number, $date_received, $sector, $agency_name, $appointee, $position_title, $salary_grade, $position_level, $employment_status, $appointment_nature, $inclusive_date_casual_from, $inclusive_date_casual_to, $appointing_authority, $issuance_date, $birthday, $sex, $pwd, $disability, $member_ip_group, $ethnicity, $eligibility_type, $eligibility_effective_date, $time_used_of_eligibility, $num_none_wd, $target_processing_days, $due_date, $encoded_by, $appointment_status);

			if ($save_appointment) {
				$title = 'Saved!';
				$status = 'success';
				$message = 'Successfully added appointment.';
				$url = base_url('appontments-processing');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function ActionTaken() {
		if ($_POST['action'] == 'submit') {
			// from ajax
			$url_key = $this->input->post('get_url');
			$action_taken = $this->input->post('action_taken');
			$remarks = $this->input->post('remarks');

			// user details
			$processor = $this->data['user_id_details']['id'];
			$date_acted = date('Y-m-d H:i:s');

			// call the specific table on where to save the appointment
			$db_table = $this->data['db_table'];
			$appointment_status	= 'Acted';

			// update appointment row
			$update_appointment_processor = $this->AppointmentMdl->update_appointment_processor($db_table, $url_key, $action_taken, $date_acted, $processor, $remarks, $appointment_status);

			if ($update_appointment_processor) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Successfully acted appointment.';
				$url = base_url('appontments-processing-pending');
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Try again. If error occurs again, please contact your system administrator.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function ActionTakenOfficial() {
		if ($_POST['action'] == 'submit') {
			// from ajax
			$url_key = $this->input->post('get_url');
			$action_taken_by_official = $this->input->post('action_taken_by_official');
			$remarks = $this->input->post('remarks');
			$get_date_received = $this->input->post('get_date_received');

			// user details
			$signing_official = $this->data['user_id_details']['id'];
			$date_signed = date('Y-m-d H:i:s');

			// call the specific table on where to save the appointment
			$db_table = $this->data['db_table'];
			$appointment_status	= 'Signed';

			// count no of days acted
			// get count saturday and sunday
			$start = new DateTime($get_date_received);
			$end = new DateTime($date_signed);
			$days = $start->diff($end, true)->days;
			$sundays = intval($days / 7) + ($start->format('N') + $days % 7 >= 7);
			$saturdays = intval($days / 7) + ($start->format('N') + $days % 6 >= 7);
			$weekends = $sundays + $saturdays;

			// count between days from received to signed
			$date_received = date_create($get_date_received);
			$get_date_signed = date_create($date_signed);
			$diff = date_diff($date_received,$get_date_signed);
			$between_count = $diff->format("%a");
			$date_acted_within = $between_count - $weekends + 1;

			// update appointment row
			$update_appointment_official = $this->AppointmentMdl->update_appointment_official($db_table, $url_key, $action_taken_by_official, $date_signed, $signing_official, $date_acted_within, $remarks, $appointment_status);

			if ($update_appointment_official) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Successfully processed appointment.';
				$url = base_url('appontments-processing-acted');
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Try again. If error occurs again, please contact your system administrator.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function ReleasedAppointment() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$post_remarks = $this->input->post('remarks');

			$date_released = date('Y-m-d');
			$db_table = $this->data['db_table'];

			$remarks = $post_remarks.'<br><br>Date Released: '.$date_released;

			$update_released = $this->AppointmentMdl->update_released($db_table, $url_key, $remarks, $date_released);

			if ($update_released) {
				$title = 'Released!';
				$status = 'success';
				$message = 'Appointment received to HRMO.';
				$url = base_url('appontments-processing-signed-details').'?id='.$url_key;
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Try again. If error occurs again, please contact your system administrator.';
				$url = '';
			}
			
			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function CheckDateReceived() {
		if ($_POST['action'] == 'submit') {
			$starting_date = $this->input->post('starting_date');
			$ending_date = $this->input->post('ending_date');
			$field_officer = $this->input->post('field_officer');
			$search_appointment_status = $this->input->post('appointment_status');

			if ($starting_date >= $ending_date) {
				$title = 'Invalid!';
				$status = 'warning';
				$message = 'Please check your date range.';
				$url = '';
			}

			else {
				$this->session->unset_userdata('starting_date');
				$this->session->unset_userdata('ending_date');
				$this->session->unset_userdata('field_officer');
				$this->session->unset_userdata('search_appointment_status');
				// create session
				$this->session->set_userdata(array('starting_date' => $starting_date));
				$this->session->set_userdata(array('ending_date' => $ending_date));
				$this->session->set_userdata(array('field_officer' => $field_officer));
				$this->session->set_userdata(array('search_appointment_status' => $search_appointment_status));

				$title = 'Redirecting!';
				$status = 'success';
				$message = 'Loading date range data.';
				$url = base_url('appontments-data');
			}
			
			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}
}