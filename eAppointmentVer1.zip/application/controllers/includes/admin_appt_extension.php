<?php
// set internet timezone
date_default_timezone_set('Asia/Manila');
$this->data['current_year'] = date('Y');

// load active year
	$status = "1";
	$fetch_years_status = $this->ActiveYearMdl->fetch_years_status('*', $status);
	foreach ($fetch_years_status as $year) {
		$this->data['activated_year'] = $year->active_year;
	}

// set db table
if (isset($_GET['fo'])) {
	$get_fo = $_GET['fo'];
	$this->data['db_table'] = 'appt_'.$get_fo.'_tbl';

	// count total received
	$this->data['count_received_total'] = $this->AppointmentMdl->count_received_total($this->data['db_table'], 'url_key, unique_id_number, date_received');
	// count appointment receive latest year
	$this->data['count_received_current_year'] = $this->AppointmentMdl->count_received_current_year($this->data['db_table'], 'url_key, unique_id_number, date_received', $this->data['current_year']);
	// count pending 
	$this->data['count_pending'] = $this->AppointmentMdl->count_pending($this->data['db_table'], 'url_key, unique_id_number, date_received');
	// count acted
	$this->data['count_acted'] = $this->AppointmentMdl->count_acted($this->data['db_table'], 'url_key, unique_id_number, date_received');
	// count signed
	$this->data['count_signed'] = $this->AppointmentMdl->count_signed($this->data['db_table'], 'url_key, unique_id_number, date_received');
	// count pending from previous year
	$this->data['count_received_last_year'] = $this->AppointmentMdl->count_received_last_year($this->data['db_table'], 'url_key, unique_id_number, date_received, appointment_status', $this->data['activated_year']);

	// count pending from previous year
	$this->data['count_received_last_year'] = $this->AppointmentMdl->count_received_last_year($this->data['db_table'], 'url_key, unique_id_number, date_received, appointment_status', $this->data['activated_year']);

	// count total received for active year
	$this->data['count_received_total_active_year'] = $this->AppointmentMdl->count_received_total_active_year($this->data['db_table'], 'url_key, unique_id_number, date_received', $this->data['activated_year']);
	// count pending 
	$this->data['count_pending_active_year'] = $this->AppointmentMdl->count_pending_active_year($this->data['db_table'], 'url_key, unique_id_number, date_received', $this->data['activated_year']);
	// count acted
	$this->data['count_acted_active_year'] = $this->AppointmentMdl->count_acted_active_year($this->data['db_table'], 'url_key, unique_id_number, date_received', $this->data['activated_year']);
	// count signed active year
	$this->data['count_signed_active_year'] = $this->AppointmentMdl->count_signed_active_year($this->data['db_table'], 'url_key, unique_id_number, date_received', $this->data['activated_year']);

	// count user per field office
	$this->data['count_user_per_fo'] = $this->AccntMdl->count_user_per_fo('id, field_office', $get_fo);
	// count user per field office as processor
	$this->data['count_processor'] = $this->AccntMdl->count_user_type('id, field_office,user_type', $get_fo, 'Processor');
	// count user per field office as signing officer
	$this->data['count_signing_officer'] = $this->AccntMdl->count_user_type('id, field_office,user_type', $get_fo, 'Signing Officer');


	// count received per month
	$this->data['count_jan_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '1');
	$this->data['count_feb_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '2');
	$this->data['count_mar_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '3');
	$this->data['count_apr_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '4');
	$this->data['count_may_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '5');
	$this->data['count_june_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '6');
	$this->data['count_july_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '7');
	$this->data['count_aug_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '8');
	$this->data['count_sept_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '9');
	$this->data['count_oct_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '10');
	$this->data['count_nov_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '11');
	$this->data['count_dec_received_active_year'] = $this->AppointmentMdl->count_month_received_active_year($this->data['db_table'], 'id, date_received, appointment_status', $this->data['activated_year'], '12');

	// count signed per month active year
	$this->data['count_jan_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '1');
	$this->data['count_feb_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '2');
	$this->data['count_mar_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '3');
	$this->data['count_apr_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '4');
	$this->data['count_may_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '5');
	$this->data['count_june_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '6');
	$this->data['count_july_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '7');
	$this->data['count_aug_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '8');
	$this->data['count_sept_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '9');
	$this->data['count_oct_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '10');
	$this->data['count_nov_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '11');
	$this->data['count_dec_signed_active_year'] = $this->AppointmentMdl->count_month_signed_active_year($this->data['db_table'], 'id, date_signed, appointment_status', $this->data['activated_year'], '12');
}
?>