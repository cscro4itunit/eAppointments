<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Main</span> - Dashboard</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-home2 text-primary"></i> <span>Admin Dashboard</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-home2 position-left"></i> Main</li>
				<li class="active">Dashboard</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-12">
				<!-- Basic accordion -->
				<h6 class="content-group text-semibold no-margin-top">
					<?=$activated_year?> Appointment Summary
					<small class="display-block">Monthly total summary</small>
				</h6>

				<div class="container">
					<?php
						if (is_array($fetch_year)) {
							foreach ($fetch_year as $list) {
								echo '
									<a href="'.base_url('administrator').'?year='.$list->active_year.'" class="btn btn-primary btn-xs">
										<i class="icon icon-download"></i> '.$list->active_year.'
									</a>
								';
							}
						}
					?>
				</div>

				<br>

				<div class="panel-group content-group-lg" id="accordion1">
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a data-toggle="collapse" data-parent="#accordion1" href="#accordion-group1">January <?=$activated_year?></a>
							</h6>
						</div>
						<div id="accordion-group1" class="panel-collapse collapse <?=$load_accordion == '01' ? 'in' : ''?>">
							<div class="panel-body">
								<div class="table-responsive">
									<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center;">
										<thead>
											<tr>
												<th style="text-align: center;">JANUARY</th>
												<th style="text-align: center;">BALANCE</th>
												<th style="text-align: center;">RECEIVED</th>
												<th style="text-align: center; color:pink;">TOTAL</th>
												<th style="text-align: center;">ACTED</th>
												<th style="text-align: center;" rowspan="2">TOTAL PENDING</th>
												<th style="text-align: center;">PERCENTAGE</th>
												<th style="text-align: center;" colspan="4">PROCESSING TIME</th>
											</tr>

											<tr>
												<th style="text-align: center;">FIELD OFFICE</th> <!-- FO -->
												<th style="text-align: center;"><?=$activated_year - 1;?></th> <!-- BALANCE -->
												<th style="text-align: center;"><?=$activated_year;?></th> <!-- RECEIVED -->
												<th style="text-align: center; color:pink;"><?=$activated_year?></th> <!-- TOTAL -->
												<th style="text-align: center;"><?=$activated_year?></th> <!-- ACTED -->
												<th style="text-align: center;">(Acted/Received) * 100</th> <!-- PERCENTAGE -->
												<td style="text-align: center;"><=20 WD</td>
												<td style="text-align: center;">=>20 WD</td>
												<td style="text-align: center;"><=40 WD</td>
												<td style="text-align: center;">=>40 WD</td>
											</tr>
										</thead>

										<tbody>
											<?php
												$total_balance_jan = 0;
												$total_received_jan = 0;
												$total_acted_jan = 0;

												if (is_array($build_array_jan)) {
													foreach ($build_array_jan as $list) {
														$pending_last_year = $list['count_pending_last_year'];
														$jan_pending = $pending_last_year - $list['count_signed_active_year_jan'];

														// balance
														$total_balance_jan += $list['count_pending_last_year'];
														// received
														$total_received_jan += $list['count_received_active_year_jan'];
														// acted
														$total_acted_jan += $list['count_signed_active_year_jan'];
														// total pending + received
														$total_pending_received_jan = $pending_last_year + $list['count_received_active_year_jan'];
														// total pending - acted
														$total_pending_acted_jan = $total_pending_received_jan - $list['count_signed_active_year_jan'];

														if ($pending_last_year == 0) {
															$jan_percentage = "0%";
														}

														else {
															$jan_per = ($list['count_signed_active_year_jan'] / $pending_last_year) * 100;
															$jan_percentage = round($jan_per, 2).'%';
														}

														echo '
															<tr>
																<td style="text-transform: uppercase;">
																	'.$list['field_office']->division_of.' | '.$list['field_office']->field_office.'
																</td>
																<td>'.$list['count_pending_last_year'].'</td>
																<td>'.$list['count_received_active_year_jan'].'</td>
																<td style="color:pink;">'.$total_pending_received_jan.'</td>
																<td>'.$list['count_signed_active_year_jan'].'</td>
																<td>'.$total_pending_acted_jan.'</td>
																<td>'.$jan_percentage.'</td>
																<td>'.$list['count_within_jan'].'</td>
																<td style="color:red;">'.$list['count_duedate_jan'].'</td>
																<td>'.$list['count_within40_jan'].'</td>
																<td style="color:red;">'.$list['count_duedate40_jan'].'</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td>No data</td>
														</tr>
													';
												}
											?>
										</tbody>

										<tfoot>
											<tr>
												<td><b>TOTAL</b></td>
												<td><b><?=$total_balance_jan?></b></td>
												<td><b><?=$total_received_jan?></b></td>
												<td style="color:pink;"><b><?=$sum_total_balance_received_jan = $total_balance_jan + $total_received_jan;?></b></td>
												<td><b><?=$total_acted_jan?></b></td>
												<td><b><?=$total_pending_jan = $sum_total_balance_received_jan - $total_acted_jan;?></b></td>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion1" href="#accordion-group2">February <?=$activated_year?></a>
							</h6>
						</div>
						<div id="accordion-group2" class="panel-collapse collapse <?=$load_accordion == '02' ? 'in' : ''?>">
							<div class="panel-body">
								<div class="table-responsive">
									<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center;">
										<thead>
											<tr>
												<th style="text-align: center;">FEBRUARY</th>
												<th style="text-align: center;" rowspan="2">BALANCE</th>
												<th style="text-align: center;">RECEIVED</th>
												<th style="text-align: center; color:pink;">TOTAL</th>
												<th style="text-align: center;">ACTED</th>
												<th style="text-align: center;" rowspan="2">TOTAL PENDING</th>
												<th style="text-align: center;">PERCENTAGE</th>
												<th style="text-align: center;" colspan="4">PROCESSING TIME</th>
											</tr>

											<tr>
												<th style="text-align: center;">FIELD OFFICE</th> <!-- FO -->
												<th style="text-align: center;"><?=$activated_year;?></th> <!-- RECEIVED -->
												<th style="text-align: center; color:pink;"><?=$activated_year?></th> <!-- TOTAL -->
												<th style="text-align: center;"><?=$activated_year?></th> <!-- ACTED -->
												<th style="text-align: center;">(Acted/Received) * 100</th> <!-- PERCENTAGE -->
												<td style="text-align: center;"><=20 WD</td>
												<td style="text-align: center;">=>20 WD</td>
												<td style="text-align: center;"><=40 WD</td>
												<td style="text-align: center;">=>40 WD</td>
											</tr>
										</thead>

										<tbody>
											<?php
												$total_balance_feb = 0;
												$total_received_feb = 0;
												$total_acted_feb = 0;

												if (is_array($build_array_feb)) {
													foreach ($build_array_feb as $list) {
														// balance
														$total_balance_feb += $list['count_pending_jan'] + $list['count_pending_last_year'];
														$table_pending_jan = $list['count_pending_jan'];
														// received
														$total_received_feb += $list['count_received_active_year_feb'];
														// acted
														$total_acted_feb += $list['count_signed_active_year_feb'];
														// total
														$received_feb = $list['count_received_active_year_feb'] + $table_pending_jan;
														// total pending + received
														$total_pending_received_feb = $table_pending_jan + $list['count_received_active_year_feb'];
														// total pending - acted
														$total_pending_acted_feb = $total_pending_received_feb - $list['count_signed_active_year_feb'];

														if ($received_feb == 0) {
															$feb_percentage = "0%";
														}

														else {
															$feb_per = ($list['count_signed_active_year_feb'] / $received_feb) * 100;
															$feb_percentage = round($feb_per, 2).'%';
														}

														echo '
															<tr>
																<td style="text-transform: uppercase;">
																	'.$list['field_office']->division_of.' | '.$list['field_office']->field_office.'
																</td>
																<td>'.$table_pending_jan.'</td>
																<td>'.$list['count_received_active_year_feb'].'</td>
																<td style="color:pink;">'.$total_pending_received_feb.'</td>
																<td>'.$list['count_signed_active_year_feb'].'</td>
																<td>'.$total_pending_acted_feb.'</td>
																<td>'.$feb_percentage.'</td>
																<td>'.$list['count_within_feb'].'</td>
																<td style="color:red;">'.$list['count_duedate_feb'].'</td>
																<td>'.$list['count_within40_feb'].'</td>
																<td style="color:red;">'.$list['count_duedate40_feb'].'</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td>No data</td>
														</tr>
													';
												}
											?>
										</tbody>

										<tfoot>
											<tr>
												<td><b>TOTAL</b></td>
												<td><b><?=$total_balance_feb?></b></td>
												<td><b><?=$total_received_feb?></b></td>
												<td style="color:pink;"><b><?=$sum_total_balance_received_feb = $total_balance_feb + $total_received_feb;?></b></td>
												<td><b><?=$total_acted_feb?></b></td>
												<td><b><?=$total_pending_feb = $sum_total_balance_received_feb - $total_acted_feb;?></b></td>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion1" href="#accordion-group3">March <?=$activated_year?></a>
							</h6>
						</div>
						<div id="accordion-group3" class="panel-collapse collapse <?=$load_accordion == '03' ? 'in' : ''?>">
							<div class="panel-body">
								<div class="table-responsive">
									<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center;">
										<thead>
											<tr>
												<th style="text-align: center;">MARCH</th>
												<th style="text-align: center;" rowspan="2">BALANCE</th>
												<th style="text-align: center;">RECEIVED</th>
												<th style="text-align: center; color:pink;">TOTAL</th>
												<th style="text-align: center;">ACTED</th>
												<th style="text-align: center;" rowspan="2">TOTAL PENDING</th>
												<th style="text-align: center;">PERCENTAGE</th>
												<th style="text-align: center;" colspan="4">PROCESSING TIME</th>
											</tr>

											<tr>
												<th style="text-align: center;">FIELD OFFICE</th> <!-- FO -->
												<th style="text-align: center;"><?=$activated_year;?></th> <!-- RECEIVED -->
												<th style="text-align: center; color:pink;"><?=$activated_year?></th> <!-- TOTAL -->
												<th style="text-align: center;"><?=$activated_year?></th> <!-- ACTED -->
												<th style="text-align: center;">(Acted/Received) * 100</th> <!-- PERCENTAGE -->
												<td style="text-align: center;"><=20 WD</td>
												<td style="text-align: center;">=>20 WD</td>
												<td style="text-align: center;"><=40 WD</td>
												<td style="text-align: center;">=>40 WD</td>
											</tr>
										</thead>

										<tbody>
											<?php
												$total_balance_mar = 0;
												$total_received_mar = 0;
												$total_acted_mar = 0;

												if (is_array($build_array_mar)) {
													foreach ($build_array_mar as $list) {
														// balance
														$total_balance_mar += $list['count_pending_feb'] + $list['count_pending_last_year'];
														$table_pending_feb = $list['count_pending_feb'] + $list['count_pending_last_year'];
														// received
														$total_received_mar += $list['count_received_active_year_mar'];
														// acted
														$total_acted_mar += $list['count_signed_active_year_mar'];
														// total
														$received_mar = $list['count_received_active_year_mar'] + $table_pending_feb;
														// total pending + received
														$total_pending_received_mar = $table_pending_feb + $list['count_received_active_year_mar'];
														// total pending - acted
														$total_pending_acted_mar = $total_pending_received_mar - $list['count_signed_active_year_mar'];

														if ($received_mar == 0) {
															$feb_percentage = "0%";
														}

														else {
															$feb_per = ($list['count_signed_active_year_mar'] / $received_mar) * 100;
															$feb_percentage = round($feb_per, 2).'%';
														}

														echo '
															<tr>
																<td style="text-transform: uppercase;">
																	'.$list['field_office']->division_of.' | '.$list['field_office']->field_office.'
																</td>
																<td>'.$table_pending_feb.'</td>
																<td>'.$list['count_received_active_year_mar'].'</td>
																<td style="color:pink;">'.$total_pending_received_mar.'</td>
																<td>'.$list['count_signed_active_year_mar'].'</td>
																<td>'.$total_pending_acted_mar.'</td>
																<td>'.$feb_percentage.'</td>
																<td>'.$list['count_within_mar'].'</td>
																<td style="color:red;">'.$list['count_duedate_mar'].'</td>
																<td>'.$list['count_within40_mar'].'</td>
																<td style="color:red;">'.$list['count_duedate40_mar'].'</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td>No data</td>
														</tr>
													';
												}
											?>
										</tbody>

										<tfoot>
											<tr>
												<td><b>TOTAL</b></td>
												<td><b><?=$total_balance_mar?></b></td>
												<td><b><?=$total_received_mar?></b></td>
												<td style="color:pink;"><b><?=$sum_total_balance_received_mar = $total_balance_mar + $total_received_mar;?></b></td>
												<td><b><?=$total_acted_mar?></b></td>
												<td><b><?=$total_pending_feb = $sum_total_balance_received_mar - $total_acted_mar;?></b></td>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion1" href="#accordion-group4">April <?=$activated_year?></a>
							</h6>
						</div>
						<div id="accordion-group4" class="panel-collapse collapse <?=$load_accordion == '04' ? 'in' : ''?>">
							<div class="panel-body">
								<div class="table-responsive">
									<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center;">
										<thead>
											<tr>
												<th style="text-align: center;">APRIL</th>
												<th style="text-align: center;" rowspan="2">BALANCE</th>
												<th style="text-align: center;">RECEIVED</th>
												<th style="text-align: center; color:pink;">TOTAL</th>
												<th style="text-align: center;">ACTED</th>
												<th style="text-align: center;" rowspan="2">TOTAL PENDING</th>
												<th style="text-align: center;">PERCENTAGE</th>
												<th style="text-align: center;" colspan="4">PROCESSING TIME</th>
											</tr>

											<tr>
												<th style="text-align: center;">FIELD OFFICE</th> <!-- FO -->
												<th style="text-align: center;"><?=$activated_year;?></th> <!-- RECEIVED -->
												<th style="text-align: center; color:pink;"><?=$activated_year?></th> <!-- TOTAL -->
												<th style="text-align: center;"><?=$activated_year?></th> <!-- ACTED -->
												<th style="text-align: center;">(Acted/Received) * 100</th> <!-- PERCENTAGE -->
												<td style="text-align: center;"><=20 WD</td>
												<td style="text-align: center;">=>20 WD</td>
												<td style="text-align: center;"><=40 WD</td>
												<td style="text-align: center;">=>40 WD</td>
											</tr>
										</thead>

										<tbody>
											<?php
												$total_balance_apr = 0;
												$total_received_apr = 0;
												$total_acted_apr = 0;

												if (is_array($build_array_apr)) {
													foreach ($build_array_apr as $list) {
														// balance
														$total_balance_apr += $list['count_pending_mar'] + $list['count_pending_last_year'];
														$table_pending_mar = $list['count_pending_mar'] + $list['count_pending_last_year'];
														// received
														$total_received_apr += $list['count_received_active_year_apr'];
														// acted
														$total_acted_apr += $list['count_signed_active_year_apr'];
														// total
														$received_apr = $list['count_received_active_year_apr'] + $table_pending_mar;
														// total pending + received
														$total_pending_received_apr = $table_pending_mar + $list['count_received_active_year_apr'];
														// total pending - acted
														$total_pending_acted_apr = $total_pending_received_apr - $list['count_signed_active_year_apr'];

														if ($received_apr == 0) {
															$mar_percentage = "0%";
														}

														else {
															$mar_per = ($list['count_signed_active_year_apr'] / $received_apr) * 100;
															$mar_percentage = round($mar_per, 2).'%';
														}

														echo '
															<tr>
																<td style="text-transform: uppercase;">
																	'.$list['field_office']->division_of.' | '.$list['field_office']->field_office.'
																</td>
																<td>'.$table_pending_mar.'</td>
																<td>'.$list['count_received_active_year_apr'].'</td>
																<td style="color:pink;">'.$total_pending_received_apr.'</td>
																<td>'.$list['count_signed_active_year_apr'].'</td>
																<td>'.$total_pending_acted_apr.'</td>
																<td>'.$mar_percentage.'</td>
																<td>'.$list['count_within_apr'].'</td>
																<td style="color:red;">'.$list['count_duedate_apr'].'</td>
																<td>'.$list['count_within40_apr'].'</td>
																<td style="color:red;">'.$list['count_duedate40_apr'].'</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td>No data</td>
														</tr>
													';
												}
											?>
										</tbody>

										<tfoot>
											<tr>
												<td><b>TOTAL</b></td>
												<td><b><?=$total_balance_apr?></b></td>
												<td><b><?=$total_received_apr?></b></td>
												<td style="color:pink;"><b><?=$sum_total_balance_received_apr = $total_balance_apr + $total_received_apr;?></b></td>
												<td><b><?=$total_acted_apr?></b></td>
												<td><b><?=$total_pending_mar = $sum_total_balance_received_apr - $total_acted_apr;?></b></td>
											</tr>
										</tfoot>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- /basic accordion -->
			</div>
		</div>

		<div id="modal_processor" class="modal fade">
			<div class="modal-dialog modal-lg">
				<div class="modal-content">
					<div class="modal-header bg-primary">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h5 class="modal-title"><b>Appointment Process</b></h5>
					</div>

					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<div class="table-responsive">
									<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center;">
										<thead>
											<tr>
												<?php
													if (is_array($fo_processed)) {
														foreach ($fo_processed as $fo_user) {
															echo '
																<td>'.$fo_user['count_processor']->ln.'</td>
															';
														}
													}

													else {
														echo 'No data';
													}
												?>
											</tr>
										<thead>

										<tbody>
											<tr>
												<?php
													if (is_array($fo_processed)) {
														foreach ($fo_processed as $count) {
															echo '
																<td>'.$count['count_processed_by_fo_active_year'].'</td>
															';
														}
													}
												?>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->