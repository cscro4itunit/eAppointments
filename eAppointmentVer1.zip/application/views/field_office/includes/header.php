<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$showinfo['title']?></title>
	<link rel="icon" href="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>">

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/icons/icomoon/styles.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/core.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/components.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/colors.css'?>" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- SWEETALERT -->
	<link rel="stylesheet" href="<?=base_url().'assets/sweetalert/sweetalert.css'?>">
	<script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert-dev.js'?>"></script>
	<script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert.min.js'?>"></script>
</head>

<body>
	<!-- Main navbar -->
	<div class="navbar navbar-inverse bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?=BASE_URL('dashboard')?>">
				<b><?=$showinfo['header']?></b>
			</a>

			<ul class="nav navbar-nav visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5" style="color: #000;"></i></a></li>
				<li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3" style="color: #000;"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav">
				<li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3" style="color: #000;"></i></a></li>
			</ul>

			<div class="navbar-right">
				<p class="navbar-text"><b style="text-transform: uppercase;color: #fff;"><?=$user_details['fn'].' '.$user_details['ln']?></b></p>
			</div>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main sidebar -->
			<div class="sidebar sidebar-main sidebar-default">
				<div class="sidebar-content">

					<!-- User menu -->
					<div class="sidebar-user-material">
						<div class="category-content">
							<div class="sidebar-user-material-content">
								<a href="#">
									<img src="<?=base_url().'assets/images/user/'?><?=$user_details['image']?>" class="img-circle img-responsive" alt="" style="width: 80px;height: 80px;">
								</a>
								
								<h6><?=$user_details['fn'].' '.$user_details['ln']?></h6>
								<span class="text-size-small"><?=$user_details['position']?></span>
							</div>
														
							<div class="sidebar-user-material-menu">
								<a href="#user-nav" data-toggle="collapse"><span>My account</span> <i class="caret"></i></a>
							</div>
						</div>
						
						<div class="navigation-wrapper collapse" id="user-nav">
							<ul class="navigation">
								<li class="<?=$nav == 'my_profile' ? 'active' : ''?>">
									<a href="<?=BASE_URL('my-profile');?>">
										<i class="icon-user-plus"></i> <span>My profile</span>
									</a>
								</li>
								
								<li><a href="<?=BASE_URL('user_logout');?>"><i class="icon-switch2"></i> <span>Logout</span></a></li>
							</ul>
						</div>
					</div>
					<!-- /user menu -->

					<!-- Main navigation -->
					<div class="sidebar-category sidebar-category-visible">
						<div class="category-content no-padding">
							<ul class="navigation navigation-main navigation-accordion">
								<!-- Main Page Navigation -->
								<li class="navigation-header"><span>Home</span> <i class="icon-menu" title="Main pages"></i></li>

								<li class="<?=$nav == 'dashboard' ? 'active' : ''?>">
									<a href="<?=BASE_URL('dashboard')?>"><i class="icon-stats-bars2"></i> <span>Data Statistics</span></a>
								</li>

								<li class="navigation-header"><span>Appointment Process</span> <i class="icon-menu" title="Main pages"></i></li>

								<li class="<?=$nav == 'appt' ? 'active' : ''?>">
									<a href="<?=BASE_URL('appontments')?>"><i class="icon icon-database4"></i> <span>Masterlist of Appointment </span></a>
								</li>

								<li class="<?=$nav == 'appt_process' ? 'active' : ''?>">
									<a href="<?=BASE_URL('appontments-processing')?>"><i class="icon icon-database-insert"></i> <span>Add Appointment</span></a>
								</li>

								<li class="<?=$nav == 'appt_process_pending' ? 'active' : ''?>">
									<a href="<?=BASE_URL('appontments-processing-pending')?>">
										<i class="icon icon-database-time2"></i>
										<span>Pending Appointment <span class="label bg-danger"><?=$count_pending?></span></span>
									</a>
								</li>

								<li class="<?=$nav == 'appt_process_acted' ? 'active' : ''?>">
									<a href="<?=BASE_URL('appontments-processing-acted')?>">
										<i class="icon icon-database-check"></i>
										<span>Acted Appointment <span class="label bg-primary"><?=$count_acted?></span></span>
									</a>
								</li>

								<li class="<?=$nav == 'appt_process_signed' ? 'active' : ''?>">
									<a href="<?=BASE_URL('appontments-processing-signed')?>">
										<i class="icon icon-database-edit2"></i>
										<span>Signed Appointment <span class="label bg-success"><?=$count_signed?></span></span>
									</a>
								</li>
								<!-- /Main Page Navigation -->
							</ul>
						</div>
					</div>
					<!-- /main navigation -->

				</div>
			</div>
			<!-- /main sidebar -->