<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Agency</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-city text-primary"></i> <span>Agency</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li class="active">Agency</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-plus-circle2"></i> Add Agency</b><br>
							<small>Within Field office.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<form method="post">
							<div class="form-group has-feedback has-feedback-left">
								<label for="field_office">Field Office</label>
								<select id="field_office" name="field_office" class="form-control input-xs">
									<option value="">- Select Field Office -</option>
									<?php
										if (is_array($field_office)) {
											foreach ($field_office as $list) {
												echo '
													<option value="'.$list->fo_tag.'">'.$list->field_office.'</option>
												';
											}
										}

										else {
											echo '
												No Data
											';
										}
									?>
								</select>

								<div class="form-control-feedback">
									<i class="icon icon-office"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="agency_name">Name of Agency</label>
								<input id="agency_name" name="agency_name" type="text" class="form-control input-xs" placeholder="Agency" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-city"></i> 
								</div>
							</div>

							<button onclick="add_agency()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-plus-circle2 position-left"></i> Add agency
							</button>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> List of Agency</b><br>
							<small>Agency within the jurisdiction of field office/s</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
							<thead>
								<tr>
									<th>Name of Agency</th>
									<th>Field Office</th>
									<th>Created on</th>
								</tr>
							</thead>

							<tbody>
								<?php
									if (is_array($fetch_agency)) {
										foreach ($fetch_agency as $list) {
											echo '
												<tr>
													<td>
														<a href="'.base_url('manage-agency-details').'?agency='.$list->url_key.'">
															'.$list->agency_name.'
														</a>
													</td>
													<td>'.$list->field_office.'</td>
													<td>'.$list->created_on.'</td>
												</tr>
											';
										}
									}

									else {
										echo '
											<tr>
												<td colspan="5">No data</td>
											</tr>
										';
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->