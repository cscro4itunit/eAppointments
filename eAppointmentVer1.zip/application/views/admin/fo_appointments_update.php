<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Main</span> - Update Appointment</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-stack3 text-primary"></i> <span>Appointments</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-office text-primary"></i> <span>Field Office</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-stack3 position-left"></i> Main</li>
				<li>Appointments</li>
				<li><?=$fo_details['field_office']?></li>
				<li class="active">Appointments</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">
					<b><i class="icon-reset"></i> Update Appointment: <?=$appt_details['unique_id_number']?></b><br>
					<small>Please fillout all * field/s . Always write in Capital Letter/s.</small>
				</h6>
				<div class="heading-elements">
					<ul class="icons-list">
                		<li><a data-action="collapse"></a></li>
                	</ul>
            	</div>
			</div>
			
			<div class="panel-body">
				<form method="post">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="date_received">Date Recieved <small>(mm/dd/yyyy)</small> *</label>
								<input id="date_received" name="date_received" type="date" class="form-control input-xs" autocomplete="off" value="<?=$appt_details['date_received']?>">
								<div class="form-control-feedback">
									<i class="icon icon-calendar"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="sector">Sector *</label>
								<select class="form-control input-xs" id="sector" name="sector">
									<option value="<?=$appt_details['sector']?>"><?=$appt_details['sector']?></option>
									<option disabled>--------------------------</option>
									<?php
										if (is_array($fetch_sector)) {
											foreach ($fetch_sector as $list) {
												echo '
													<option value="'.$list->sector.'">'.$list->sector.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="agency_name">Name of Agency *</label>
								<select class="form-control input-xs" id="agency_name" name="agency_name">
									<option value="<?=$appt_details['agency_name']?>"><?=$appt_details['agency_name']?></option>
									<option disabled>--------------------------</option>
									<?php
										if (is_array($fetch_agency)) {
											foreach ($fetch_agency as $list) {
												echo '
													<option value="'.$list->agency_name.'">'.$list->agency_name.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-office"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointee">Name of Appointee *</label>
								<input id="appointee" name="appointee" type="text" class="form-control input-xs" placeholder="Lastname, Firstname, Ext.Name, Middle Name" autocomplete="off" value="<?=$appt_details['appointee']?>">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="position_title">Position Title *</label>
								<input id="position_title" name="position_title" type="text" class="form-control input-xs" placeholder="Position Title" autocomplete="off" value="<?=$appt_details['position_title']?>">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="salary_grade">Salary/Job/Pay Grade *</label>
								<select class="form-control input-xs" id="salary_grade" name="salary_grade">
									<option value="<?=$appt_details['salary_grade']?>">SG <?=$appt_details['salary_grade']?></option>
									<option disabled>--------------------------</option>
									<?php
										for ($i=1; $i < 31 ; $i++) { 
											echo '
												<option value="'.$i.'">SG - '.$i.'</option>
											';	
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="position_level">Position Level *</label>
								<select class="form-control input-xs" id="position_level" name="position_level">
									<option value="<?=$appt_details['position_level']?>"><?=$appt_details['position_level']?></option>
									<option disabled>--------------------------</option>
									<option value="1st">1st</option>
									<option value="2nd">2nd</option>
									<option value="3rd">3rd</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="employment_status">Employment Status *</label>
								<select class="form-control input-xs" id="employment_status" name="employment_status">
									<option value="<?=$appt_details['employment_status']?>"><?=$appt_details['employment_status']?></option>
									<option disabled>--------------------------</option>
									<?php
										if (is_array($fetch_employment_status)) {
											foreach ($fetch_employment_status as $list) {
												echo '
													<option value="'.$list->employment_status.'">'.$list->employment_status.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointment_nature">Nature of Appointment *</label>
								<select class="form-control input-xs" id="appointment_nature" name="appointment_nature">
									<option value="<?=$appt_details['appointment_nature']?>"><?=$appt_details['appointment_nature']?></option>
									<option disabled>--------------------------</option>
									<?php
										if (is_array($fetch_appt_nature)) {
											foreach ($fetch_appt_nature as $list) {
												echo '
													<option value="'.$list->appointment_nature.'">'.$list->appointment_nature.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="inclusive_date_casual_from">Inclusive date of Casual or Contractual Appointment</label>
								<div class="row">
									<div class="col-md-6">
										<input id="inclusive_date_casual_from" name="inclusive_date_casual_from" type="date" class="form-control input-xs" autocomplete="off" value="<?=$appt_details['inclusive_date_casual_from']?>">
										<div class="form-control-feedback">
											<i class="icon icon-calendar5">fr</i>
										</div>
									</div>

									<div class="col-md-6">
										<input id="inclusive_date_casual_to" name="inclusive_date_casual_to" type="date" class="form-control input-xs" autocomplete="off" value="<?=$appt_details['inclusive_date_casual_to']?>">
										<div class="form-control-feedback">
											<i class="icon icon-calendar5">to</i>
										</div>
									</div>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointing_authority">Name of Appointing Authority *</label>
								<input id="appointing_authority" name="appointing_authority" type="text" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off" value="<?=$appt_details['appointing_authority']?>">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="issuance_date">Date of Issuance of Appointment *</label>
								<input id="issuance_date" name="issuance_date" type="date" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off" value="<?=$appt_details['issuance_date']?>">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="birthday">Date of Birth *</label>
								<input id="birthday" name="birthday" type="date" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off" value="<?=$appt_details['birthday']?>">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="sex">Sex *</label>
								<select class="form-control input-xs" id="sex" name="sex">
									<option value="<?=$appt_details['sex']?>"><?=$appt_details['sex']?></option>
									<option disabled>--------------------------</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-man-woman"></i>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="pwd">Person with Disability? *</label>
								<select class="form-control input-xs" id="pwd" name="pwd">
									<option value="<?=$appt_details['pwd']?>"><?=$appt_details['pwd']?></option>
									<option disabled>--------------------------</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="disability">if YES, type of disability</label>
								<select class="form-control input-xs" id="disability" name="disability">
									<?php
										if ($appt_details['disability'] == "") {
											echo '
												<option value="">- Select Type of Disability -</option>
												<option disabled>--------------------------</option>
											';
										}

										else {
											echo '
												<option value="'.$appt_details['disability'].'">'.$appt_details['disability'].'</option>
												<option disabled>--------------------------</option>
											';
										}

										if (is_array($fetch_disability)) {
											foreach ($fetch_disability as $list) {
												echo '
													<option value="'.$list->disability_type.'">'.$list->disability_type.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="member_ip_group">Member of IP Group *</label>
								<select class="form-control input-xs" id="member_ip_group" name="member_ip_group">
									<option value="<?=$appt_details['member_ip_group']?>"><?=$appt_details['member_ip_group']?></option>
									<option disabled>--------------------------</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="ethnicity">Ethnicity</label>
								<select class="form-control input-xs" id="ethnicity" name="ethnicity">
									<?php
										if ($appt_details['ethnicity'] == "") {
											echo '
												<option value="">- Select Type of Ethnicity -</option>
												<option disabled>--------------------------</option>
											';
										}

										else {
											echo '
												<option value="'.$appt_details['ethnicity'].'">'.$appt_details['ethnicity'].'</option>
												<option disabled>--------------------------</option>
											';
										}

										if (is_array($fetch_ethnicity)) {
											foreach ($fetch_ethnicity as $list) {
												echo '
													<option value="'.$list->ethnicity.'">'.$list->ethnicity.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="eligibility_type">Type of Eligibility Used</label>
								<select class="form-control input-xs" id="eligibility_type" name="eligibility_type">
									<option value="<?=$appt_details['eligibility_type']?>"><?=$appt_details['eligibility_type']?></option>
									<option disabled>--------------------------</option>
									<?php
										if (is_array($fetch_eligibility)) {
											foreach ($fetch_eligibility as $list) {
												echo '
													<option value="'.$list->eligibility_type.'">'.$list->eligibility_type.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="eligibility_effective_date">Date of Effectivity of Eligibility</label>
								<input id="eligibility_effective_date" name="eligibility_effective_date" type="date" class="form-control input-xs" placeholder="Ethnicity" autocomplete="off" value="<?=$appt_details['eligibility_effective_date']?>">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="time_used_of_eligibility">First time used of eligibility? *</label>
								<select class="form-control input-xs" id="time_used_of_eligibility" name="time_used_of_eligibility">
									<option value="<?=$appt_details['time_used_of_eligibility']?>"><?=$appt_details['time_used_of_eligibility']?></option>
									<option disabled>--------------------------</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>
						</div>
					</div>

					<button onclick="update_appointment()" type="button" class="btn btn-primary btn-xs pull-right">
						<i class="icon icon-reset"></i> Update Appointment
					</button>
				</form>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->