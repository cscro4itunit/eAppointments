<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class AdminCtrl extends CI_Controller {
	private $data;
	private $data2;

	public function __construct() {
		parent:: __construct();
		// set internet timezone
		date_default_timezone_set('Asia/Manila');

		// including all models
		include 'includes/models.php';
		include 'includes/admin_appt_extension.php';

		// callout session that was set after login
		$this->accnt_id = $this->session->userdata('session_id');

		// select * details of user
		$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

		if (!isset($this->accnt_id)) {
			redirect(base_url(''));
		}

		else {
			$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);
			switch ($this->data['user_id_details']['role']) {
				case '0':
					base_url('administrator');
					break;
				
				case '1':
					redirect(base_url('error-404'));
					break;

				default:
					base_url('cscro4/admin/login');
					break;
			}
		}
	}

	// NAVIGATION
	public function administrator() {
		$current_activated_year = $this->data['activated_year'];

		if (!isset($_GET['year'])) {
			$active_year = $current_activated_year;
		}

		else {
			$get_year = $_GET['year'];
			// check if year existed
			$validate = $this->ActiveYearMdl->fetch_active_year_type('active_year', $get_year);

			if ($validate > 0) {
				$active_year = $get_year;
			}

			else {
				redirect(base_url('error-404'));
			}
		}

		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'admindashboard',
			'jscript' => 'administrator',
			'activated_year' => $active_year,
			// 'load_accordion' => date('m'),
			'load_accordion' => date('m'),
			'field_office' => $this->FoMdl->get_fo('id, fo_tag, field_office, division_of'),
			'fetch_year' => $this->ActiveYearMdl->fetch_active_year('*'),
		);

		// build array per field office
		$build_array = array();
		// limiter
		foreach ($this->data['field_office'] as $row) {
			$field_office_jan[] = array(
				'field_office' => $row,
				// january
				'count_pending_last_year' => $this->AppointmentMdl->admin_count_received_last_year('appt_'.$row->fo_tag.'_tbl', 'url_key, unique_id_number, date_received, appointment_status', $active_year),
				'count_received_active_year_jan' => $this->AppointmentMdl->count_month_received_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_received, appointment_status', $active_year, '1'),
				'count_signed_active_year_jan' => $this->AppointmentMdl->count_month_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, appointment_status', $active_year, '1'),
				'count_within_jan' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '1', '20'),
				'count_within40_jan' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '1', '40'),
				'count_duedate_jan' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '1', '20'),
				'count_duedate40_jan' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '1', '40'),
			);

			$field_office_feb[] = array(
				'field_office' => $row,
				// february
				'count_pending_last_year' => $this->AppointmentMdl->admin_count_received_last_year('appt_'.$row->fo_tag.'_tbl', 'url_key, unique_id_number, date_received, appointment_status', $active_year),
				'count_pending_jan' => $this->AppointmentMdl->admin_count_month_not_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'url_key, date_received, appointment_status', $active_year, '1'),
				'count_received_active_year_feb' => $this->AppointmentMdl->count_month_received_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_received, appointment_status', $active_year, '2'),
				'count_signed_active_year_feb' => $this->AppointmentMdl->count_month_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, appointment_status', $active_year, '2'),
				'count_within_feb' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '2', '20'),
				'count_within40_feb' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '2', '40'),
				'count_duedate_feb' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '2', '20'),
				'count_duedate40_feb' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '2', '40'),
			);

			$field_office_mar[] = array(
				'field_office' => $row,
				// march
				'count_pending_last_year' => $this->AppointmentMdl->admin_count_received_last_year('appt_'.$row->fo_tag.'_tbl', 'url_key, unique_id_number, date_received, appointment_status', $active_year),
				'count_pending_feb' => $this->AppointmentMdl->admin_count_month_not_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'url_key, date_received, appointment_status', $active_year, '2'),
				'count_received_active_year_mar' => $this->AppointmentMdl->count_month_received_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_received, appointment_status', $active_year, '3'),
				'count_signed_active_year_mar' => $this->AppointmentMdl->count_month_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, appointment_status', $active_year, '3'),
				'count_within_mar' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '3', '20'),
				'count_within40_mar' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '3', '40'),
				'count_duedate_mar' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '3', '20'),
				'count_duedate40_mar' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '3', '40'),
			);

			$field_office_apr[] = array(
				'field_office' => $row,
				// aprch
				'count_pending_last_year' => $this->AppointmentMdl->admin_count_received_last_year('appt_'.$row->fo_tag.'_tbl', 'url_key, unique_id_number, date_received, appointment_status', $active_year),
				'count_pending_mar' => $this->AppointmentMdl->admin_count_month_not_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'url_key, date_received, appointment_status', $active_year, '3'),
				'count_received_active_year_apr' => $this->AppointmentMdl->count_month_received_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_received, appointment_status', $active_year, '4'),
				'count_signed_active_year_apr' => $this->AppointmentMdl->count_month_signed_active_year('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, appointment_status', $active_year, '4'),
				'count_within_apr' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '4', '20'),
				'count_within40_apr' => $this->AppointmentMdl->count_within_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '4', '40'),
				'count_duedate_apr' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '4', '20'),
				'count_duedate40_apr' => $this->AppointmentMdl->count_duedate_acted('appt_'.$row->fo_tag.'_tbl', 'id, date_signed, due_date', $active_year, '4', '40'),
			);
		}

		$this->data['build_array_jan'] = $field_office_jan;
		$this->data['build_array_feb'] = $field_office_feb;
		$this->data['build_array_mar'] = $field_office_mar;
		$this->data['build_array_apr'] = $field_office_apr;
		// $this->data['build_array_may'] = $field_office_may;
		// $this->data['build_array_june'] = $field_office_june;
		// $this->data['build_array_july'] = $field_office_july;
		// $this->data['build_array_aug'] = $field_office_aug;
		// $this->data['build_array_sept'] = $field_office_sept;
		// $this->data['build_array_oct'] = $field_office_oct;
		// $this->data['build_array_nov'] = $field_office_nov;
		// $this->data['build_array_dec'] = $field_office_dec;

		// print_r($this->data['build_array_mar']);

		if ($this->session->userdata('session_fo_tag') == NULL) {
			echo '';
		}

		else {
			$session_fo_tag = $this->session->userdata('session_fo_tag');
			$session_load_month = $this->session->userdata('session_load_month');

			$session_db_table = 'appt_'.$session_fo_tag.'_tbl';
			$this->data['get_fo_user'] = $this->AccntMdl->fetch_fo_users('id, fn, ln, field_office', $session_fo_tag);
			$this->data['fetch_fo_signing_officer'] = $this->AccntMdl->fetch_fo_signing_officer('id, fn, ln, field_office', $session_fo_tag, 'Signing Officer');

			$build_array = array();
			if (is_array($this->data['get_fo_user'])) {
				foreach ($this->data['get_fo_user'] as $row) {
					$processed[] = array(
						'count_processor' => $row,
						// count processed appointment by fo
						'count_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($session_db_table, 'id, processor', $active_year, $session_load_month, $row->id),
				        'count_total_processed' => $this->AppointmentMdl->count_total_processed_by_fo_active_year($session_db_table, 'id, processor', $active_year, $row->id),
				        'count_total_processed_by_fo' => $this->AppointmentMdl->count_total_processed_by_fo($session_db_table, 'id, processor', $row->id),
			        );
				}

				$this->data['fo_processed'] = $processed;
			}

			else {
				echo 'No data';
			}
		}

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/dashboard', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function manage_user() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_user',
			'jscript' => 'administrator',
			'field_office' => $this->FoMdl->get_fo('fo_tag, field_office'),
			'position' => $this->PositionMdl->get_position('*'),
			'fetch_user' => $this->AccntMdl->fetch_user_account('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_user', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function user_account_details() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_user',
						'jscript' => 'administrator',
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
						'assigned_fo' => $this->FoMdl->fetch_by_fo_tag('*', $auth_url['field_office']),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/user_account_details', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function user_account_status() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_user',
						'jscript' => 'administrator',
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
						'assigned_fo' => $this->FoMdl->fetch_by_fo_tag('*', $auth_url['field_office']),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/user_account_status', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function user_account_update() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_user',
						'jscript' => 'administrator',
						'field_office' => $this->FoMdl->get_fo('fo_tag, field_office'),
						'position' => $this->PositionMdl->get_position('*'),
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
						'assigned_fo' => $this->FoMdl->fetch_by_fo_tag('*', $auth_url['field_office']),
						'security_questions' => $this->SecurityMdl->get_security_question('*'),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/user_account_update', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function manage_fo() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_fo',
			'jscript' => 'administrator',
			'field_office' => $this->FoMdl->get_fo('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_fo', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function field_office_details() {
		if (!isset($_GET['fo'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$fo_tag = $_GET['fo'];
			$auth_url = $this->FoMdl->url_auth('*', $fo_tag);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_fo',
					'jscript' => 'administrator',
					'fo_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/fo_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function field_office_update() {
		if (!isset($_GET['fo'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$fo_tag = $_GET['fo'];
			$auth_url = $this->FoMdl->url_auth('*', $fo_tag);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_fo',
					'jscript' => 'administrator',
					'fo_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/fo_update', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function manage_system_information() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'setting_system_info',
			'jscript' => 'administrator',
			'position' => $this->PositionMdl->get_position('*'),
			'question' => $this->SecurityMdl->get_security_question('*'),
			'fetch_active_year' => $this->ActiveYearMdl->fetch_active_year('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/setting_system_information', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function position_details() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['id'];
			$auth_url = $this->PositionMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'setting_system_info',
					'jscript' => 'administrator',
					'get_position' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/position_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function question_details() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['id'];
			$auth_url = $this->SecurityMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'setting_system_info',
					'jscript' => 'administrator',
					'get_question' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/question_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function manage_admin() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_admin',
			'jscript' => 'administrator',
			'position' => $this->PositionMdl->get_position('*'),
			'fetch_admin' => $this->AccntMdl->fetch_admin_account('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_admin', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function admin_account_details() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 1) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_admin',
						'jscript' => 'administrator',
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/admin_account_details', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function admin_account_status() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 1) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_admin',
						'jscript' => 'administrator',
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/admin_account_status', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function admin_account_update() {
		if (!isset($_GET['user'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);

			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['user'];
			$auth_url = $this->AccntMdl->url_auth('url_key, field_office, role', $url_key);

			if ($auth_url['role'] == 1) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_403', $this->data);
			}

			else {
				if ($auth_url > 0) {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'manage_user',
						'jscript' => 'administrator',
						'position' => $this->PositionMdl->get_position('*'),
						'user_details' => $this->AccntMdl->url_auth('*', $url_key),
						'assigned_fo' => $this->FoMdl->fetch_by_fo_tag('*', $auth_url['field_office']),
						'security_questions' => $this->SecurityMdl->get_security_question('*'),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/admin_account_update', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}
		}
	}

	public function manage_holidays() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_holidays',
			'jscript' => 'administrator',
			'field_office' => $this->FoMdl->get_fo('*'),
			'fetch_holiday' => $this->HolidayMdl->fetch_holiday('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_holidays', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function manage_holidays_details() {
		if (!isset($_GET['holiday'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['holiday'];
			$auth_url = $this->HolidayMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_holidays',
					'jscript' => 'administrator',
					'holiday_details' => $auth_url,
					'field_office' => $this->FoMdl->get_fo('*'),
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/holiday_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_agency() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_agency',
			'jscript' => 'administrator',
			'field_office' => $this->FoMdl->get_fo('*'),
			'fetch_agency' => $this->AgencyMdl->fetch_agency('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_agency', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function manage_agency_details() {
		if (!isset($_GET['agency'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['agency'];
			$auth_url = $this->AgencyMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_agency',
					'jscript' => 'administrator',
					'agency_details' => $auth_url,
					'field_office' => $this->FoMdl->get_fo('*'),
					'assigned_fo' => $this->FoMdl->fetch_by_fo_tag('*', $auth_url['field_office']),
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/agency_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_appointment_data() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'manage_appt_data',
			'jscript' => 'administrator',
			'get_action' => $this->ActionMdl->get_action('*'),
			'fetch_appt_nature' => $this->ApptNatureMdl->fetch_appt_nature('*'),
			'fetch_disability' => $this->DisabilityMdl->fetch_disability('*'),
			'fetch_eligibility' => $this->EligibilityMdl->fetch_eligibility('*'),
			'fetch_employment_status' => $this->EmpStatusMdl->fetch_employment_status('*'),
			'fetch_ethnicity' => $this->EthnicityMdl->fetch_ethnicity('*'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/manage_appointment_data', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function manage_action_details() {
		if (!isset($_GET['action'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['action'];
			$auth_url = $this->ActionMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'action_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/action_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_nature_details() {
		if (!isset($_GET['nature'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['nature'];
			$auth_url = $this->ApptNatureMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'nature_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/nature_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_disability_details() {
		if (!isset($_GET['disability'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['disability'];
			$auth_url = $this->DisabilityMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'disability_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/disability_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_eligibility_details() {
		if (!isset($_GET['eligibility'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['eligibility'];
			$auth_url = $this->EligibilityMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'eligibility_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/eligibility_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_employment_status_details() {
		if (!isset($_GET['employment'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['employment'];
			$auth_url = $this->EmpStatusMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'employment_status_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/employment_status_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function manage_ethnicity_details() {
		if (!isset($_GET['ethnicity'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['ethnicity'];
			$auth_url = $this->EthnicityMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'ethnicity_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/ethnicity_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
			
		}
	}

	public function year_details() {
		if (!isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['id'];
			$auth_url = $this->ActiveYearMdl->url_auth('*', $url_key);

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'manage_appt_data',
					'jscript' => 'administrator',
					'year_details' => $auth_url,
				);

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/year_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function fo_appointments() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'admin_details' => $this->data['user_id_details'],
			'nav' => 'fo_appointments',
			'jscript' => 'administrator',
			'fo_calabarzon' => $this->FoMdl->fetch_fo_division_of('id, fo_tag, field_office, division_of, director', 'calabarzon'),
			'fo_mimaropa' => $this->FoMdl->fetch_fo_division_of('id, fo_tag, field_office, division_of, director', 'mimaropa'),
			'region' => $this->FoMdl->fetch_fo_division_of('id, fo_tag, field_office, division_of, director', 'region'),
		);

		$this->load->view('admin/includes/header', $this->data);
		$this->load->view('admin/fo_appointments', $this->data);
		$this->load->view('admin/includes/footer', $this->data);
	}

	public function fo_appointment_details() {
		if (!isset($_GET['fo'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth url key
			$url_key = $_GET['fo'];
			$auth_url = $this->FoMdl->url_auth('*', $url_key);

			$db_table = 'appt_'.$url_key.'_tbl';

			if ($auth_url > 0) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
					'nav' => 'fo_appointments',
					'jscript' => 'administrator',
					'fo_details' => $auth_url,
					'appt_list' => $this->AppointmentMdl->fetch_appointment($db_table, 'url_key, unique_id_number, date_received, agency_name, appointee, position_title, due_date, appointment_status'),
					'fetch_fo_users' => $this->AccntMdl->fetch_fo_users('id, fn, ln, field_office', $url_key),
					'fetch_fo_signing_officer' => $this->AccntMdl->fetch_fo_signing_officer('id, fn, ln, field_office', $url_key, 'Signing Officer'),
					'activated_year' => $this->data['activated_year'],
					'get_db_table' => $this->data['db_table'],
					// count
					'count_received_total' => $this->data['count_received_total'],
					'count_pending' => $this->data['count_pending'],
					'count_acted' => $this->data['count_acted'],
					'count_signed' => $this->data['count_signed'],
					// pending from last year
					'count_received_last_year' => $this->data['count_received_last_year'],
					// count active year
					'count_received_total_active_year' => $this->data['count_received_total_active_year'],
					'count_signed_active_year' => $this->data['count_signed_active_year'],
					'count_pending_active_year' => $this->data['count_pending_active_year'],
					'count_acted_active_year' => $this->data['count_acted_active_year'],
					// count official
					'count_user_per_fo' => $this->data['count_user_per_fo'],
					'count_processor' => $this->data['count_processor'],
					'count_signing_officer' => $this->data['count_signing_officer'],
					// count received per month active year
					'count_jan_received_active_year' => $this->data['count_jan_received_active_year'],
					'count_feb_received_active_year' => $this->data['count_feb_received_active_year'],
					'count_mar_received_active_year' => $this->data['count_mar_received_active_year'],
					'count_apr_received_active_year' => $this->data['count_apr_received_active_year'],
					'count_may_received_active_year' => $this->data['count_may_received_active_year'],
					'count_june_received_active_year' => $this->data['count_june_received_active_year'],
					'count_july_received_active_year' => $this->data['count_july_received_active_year'],
					'count_aug_received_active_year' => $this->data['count_aug_received_active_year'],
					'count_sept_received_active_year' => $this->data['count_sept_received_active_year'],
					'count_oct_received_active_year' => $this->data['count_oct_received_active_year'],
					'count_nov_received_active_year' => $this->data['count_nov_received_active_year'],
					'count_dec_received_active_year' => $this->data['count_dec_received_active_year'],
					// count total signed per month active year
					'count_jan_signed_active_year' => $this->data['count_jan_signed_active_year'],
					'count_feb_signed_active_year' => $this->data['count_feb_signed_active_year'],
					'count_mar_signed_active_year' => $this->data['count_mar_signed_active_year'],
					'count_apr_signed_active_year' => $this->data['count_apr_signed_active_year'],
					'count_may_signed_active_year' => $this->data['count_may_signed_active_year'],
					'count_june_signed_active_year' => $this->data['count_june_signed_active_year'],
					'count_july_signed_active_year' => $this->data['count_july_signed_active_year'],
					'count_aug_signed_active_year' => $this->data['count_aug_signed_active_year'],
					'count_sept_signed_active_year' => $this->data['count_sept_signed_active_year'],
					'count_oct_signed_active_year' => $this->data['count_oct_signed_active_year'],
					'count_nov_signed_active_year' => $this->data['count_nov_signed_active_year'],
					'count_dec_signed_active_year' => $this->data['count_dec_signed_active_year'],
					// count within processed appointment
					'count_within_jan' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '20'),
					'count_within40_jan' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '40'),
					'count_duedate_jan' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '20'),
					'count_duedate40_jan' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '40'),
					'count_within_feb' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '20'),
					'count_within40_feb' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '40'),
					'count_duedate_feb' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '20'),
					'count_duedate40_feb' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '40'),
					'count_within_mar' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '20'),
					'count_within40_mar' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '40'),
					'count_duedate_mar' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '20'),
					'count_duedate40_mar' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '40'),
					'count_within_apr' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '20'),
					'count_within40_apr' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '40'),
					'count_duedate_apr' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '20'),
					'count_duedate40_apr' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '40'),
					'count_within_may' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '20'),
					'count_within40_may' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '40'),
					'count_duedate_may' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '20'),
					'count_duedate40_may' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '40'),
					'count_within_june' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '20'),
					'count_within40_june' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '40'),
					'count_duedate_june' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '20'),
					'count_duedate40_june' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '40'),
					'count_within_july' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '20'),
					'count_within40_july' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '40'),
					'count_duedate_july' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '20'),
					'count_duedate40_july' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '40'),
					'count_within_aug' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '20'),
					'count_within40_aug' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '40'),
					'count_duedate_aug' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '20'),
					'count_duedate40_aug' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '40'),
					'count_within_sept' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '20'),
					'count_within40_sept' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '40'),
					'count_duedate_sept' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '20'),
					'count_duedate40_sept' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '40'),
					'count_within_oct' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '20'),
					'count_within40_oct' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '40'),
					'count_duedate_oct' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '20'),
					'count_duedate40_oct' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '40'),
					'count_within_nov' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '20'),
					'count_within40_nov' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '40'),
					'count_duedate_nov' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '20'),
					'count_duedate40_nov' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '40'),
					'count_within_dec' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '20'),
					'count_within40_dec' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '40'),
					'count_duedate_dec' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '20'),
					'count_duedate40_dec' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '40'),
					// count processed per month active year
					'count_acted_active_year_per_month_jan' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '1'),
					'count_acted_active_year_per_month_feb' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '2'),
					'count_acted_active_year_per_month_mar' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '3'),
					'count_acted_active_year_per_month_apr' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '4'),
					'count_acted_active_year_per_month_may' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '5'),
					'count_acted_active_year_per_month_june' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '6'),
					'count_acted_active_year_per_month_july' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '7'),
					'count_acted_active_year_per_month_aug' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '8'),
					'count_acted_active_year_per_month_sept' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '9'),
					'count_acted_active_year_per_month_oct' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '10'),
					'count_acted_active_year_per_month_nov' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '11'),
					'count_acted_active_year_per_month_dec' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '12'),
				);

				// build array for processed appointment
				$build_array = array();
				foreach ($this->data['fetch_fo_users'] as $row) {
					$processed[] = array(
						'count_processor' => $row,
						// count processed appointment by fo
						'count_jan_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '1', $row->id),
						'count_feb_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '2', $row->id),
						'count_mar_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '3', $row->id),
						'count_apr_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '4', $row->id),
				        'count_may_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '5', $row->id),
				        'count_june_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '6', $row->id),
				        'count_july_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '7', $row->id),
				        'count_aug_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '8', $row->id),
				        'count_sept_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '9', $row->id),
				        'count_oct_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '10', $row->id),
				        'count_nov_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '11', $row->id),
				        'count_dec_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '12', $row->id),
				        'count_total_processed' => $this->AppointmentMdl->count_total_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], $row->id),
				        'count_total_processed_by_fo' => $this->AppointmentMdl->count_total_processed_by_fo($this->data['get_db_table'], 'id, processor', $row->id),
			        );
				}

				foreach ($this->data['fetch_fo_signing_officer'] as $row_signed) {
					$signed[] = array(
						'count_signed' => $row_signed,
						// count processed appointment by fo
						'count_jan_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '1', $row_signed->id),
						'count_feb_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '2', $row_signed->id),
						'count_mar_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '3', $row_signed->id),
						'count_apr_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '4', $row_signed->id),
				        'count_may_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '5', $row_signed->id),
				        'count_june_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '6', $row_signed->id),
				        'count_july_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '7', $row_signed->id),
				        'count_aug_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '8', $row_signed->id),
				        'count_sept_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '9', $row_signed->id),
				        'count_oct_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '10', $row_signed->id),
				        'count_nov_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '11', $row_signed->id),
				        'count_dec_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '12', $row_signed->id),
				        'count_total_signed' => $this->AppointmentMdl->count_total_signed_by_fo_active_year($this->data['get_db_table'], 'id, signing_official', $this->data['activated_year'], $row_signed->id),
				        'count_total_signed_by_fo' => $this->AppointmentMdl->count_total_signed_by_fo($this->data['get_db_table'], 'id, signing_official', $row_signed->id),
			        );
				}

				$this->data['build_array'] = $processed;
				$this->data['build_array_signed'] = $signed;

				$this->load->view('admin/includes/header', $this->data);
				$this->load->view('admin/fo_appointments_details', $this->data);
				$this->load->view('admin/includes/footer', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	public function fo_appointment_update() {
		if (!isset($_GET['fo']) OR !isset($_GET['id'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
				'admin_details' => $this->data['user_id_details'],
			);
			
			$this->load->view('admin/error_405', $this->data);
		}

		else {
			// auth fo tag
			$fo_tag = $_GET['fo'];
			$auth_fo = $this->FoMdl->url_auth('*', $fo_tag);

			if ($auth_fo > 0) {
				// auth url key
				$db_table = 'appt_'.$fo_tag.'_tbl';

				$url_key = $_GET['id'];
				$auth_url = $this->AppointmentMdl->url_auth($db_table, '*', $url_key);

				if ($auth_url > 0) {
					// auth url key
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
						'nav' => 'fo_appointments',
						'jscript' => 'appointment',
						'fo_details' => $auth_fo,
						'appt_details' => $auth_url,
						'fetch_sector' => $this->SectorMdl->fetch_sector('*'),
						'fetch_agency' => $this->AgencyMdl->fetch_agency_by_fo('*', $fo_tag),
						'fetch_employment_status' => $this->EmpStatusMdl->fetch_employment_status('*'),
						'fetch_appt_nature' => $this->ApptNatureMdl->fetch_appt_nature('*'),
						'fetch_eligibility' => $this->EligibilityMdl->fetch_eligibility('*'),
						'fetch_disability' => $this->DisabilityMdl->fetch_disability('*'),
						'fetch_ethnicity' => $this->EthnicityMdl->fetch_ethnicity('*'),
					);

					$this->load->view('admin/includes/header', $this->data);
					$this->load->view('admin/fo_appointments_update', $this->data);
					$this->load->view('admin/includes/footer', $this->data);
				}

				else {
					$this->data = array(
						'showinfo' => $this->WebinfoMdl->show_webinfo(),
						'admin_details' => $this->data['user_id_details'],
					);

					$this->load->view('admin/error_405', $this->data);
				}
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'admin_details' => $this->data['user_id_details'],
				);

				$this->load->view('admin/error_405', $this->data);
			}
		}
	}

	// FUNCTION
	public function admin_logout() {
		$this->user_id_details = $this->session->unset_userdata('session_id');
		session_destroy();
		redirect(base_url('cscro4/admin/login'));
	}

	public function imageUpload($path,$filename) {
		$config['upload_path']          = $path;
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['file_name']            = $filename;
	    $this->load->library('upload');
	    return $this->upload->initialize($config);
	}

	public function AddUserAccount() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$field_office = $this->input->post('field_office');
			$position = $this->input->post('position');
			$user_type = $this->input->post('user_type');
			$gender = $this->input->post('gender');
			$fn = $this->input->post('fn');
			$mi = $this->input->post('mi');
			$ln = $this->input->post('ln');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$username = $this->input->post('username');
			// additional fields
			$url_key = md5(uniqid(rand(), true));

			if ($gender == 'Male') {
				$image = 'male.png';
			} else {
				$image = 'female.png';
			}
			
			$pass = '123456';
			$password = password_hash($pass, PASSWORD_DEFAULT);
			$security_code = rand(111111,999999);
			if ($field_office == "psed") {
				$role = 2;
			} else {
				$role = 1;
			}
			
			$active_status = 1;
			
			// save new user account
			// validate username if existence
			$validate = $this->AccntMdl->username_auth('*', $username);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Username already used.';
				$url = '';
			}

			else {
				// save user account
				$save_account = $this->AccntMdl->add_account($url_key, $fn, $mi, $ln, $gender, $contact, $image, $email_add, $field_office, $position, $user_type, $username, $password, $security_code, $role, $active_status);

				if ($save_account) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added user account.';
					$url = base_url('manage-user-account');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AdminUpdateAccountStatus() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$account_request = $this->input->post('account_request');

			if ($account_request == 'activate') {
				$active_status = '1';
			} else {
				$active_status = '0';
			}

			// identify user if logged
			$get_user_data = $this->AccntMdl->url_auth('id, role', $url_key);

			if ($get_user_data['id'] == $this->data['user_id_details']['id']) {
				$title = 'Unable!';
				$status = 'warning';
				$message = 'Active user.';
				$url = '';
			}

			else {
				// udpate account status
				$udpate_account_status = $this->AccntMdl->udpate_active_status_by_url_key($url_key, $active_status);

				if ($udpate_account_status) {
					// get account role
					if ($get_user_data['role'] == 0) {
						$url = base_url('admin-account-details').'?user='.$url_key;
					} else {
						$url = base_url('user-account-details').'?user='.$url_key;
					}

					$title = 'Account Updated!';
					$status = 'success';
					$message = 'Active Status updated.';
				}

				else {
					$title = 'Unabled!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AdminUpdateUsername() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$username = $this->input->post('new_username');

			// validate username if existence
			$validate = $this->AccntMdl->username_auth('*', $username);

			if ($validate > 0) {
				$title = 'Select another username!';
				$status = 'warning';
				$message = 'Username already used.';
				$url = '';
			}

			else {
				// update
				$update_username = $this->AccntMdl->update_user_username($url_key, $username);

				if ($update_username) {
					$get_user_data = $this->AccntMdl->url_auth('id, role', $url_key);
					// identify if logged
					if ($get_user_data['id'] == $this->data['user_id_details']['id']) {
						$title = 'Updated!';
						$status = 'success';
						$message = 'Successfully updated your username. Please login again.';
						$url = base_url('admin_logout');
					}

					else {
						// get account role
						if ($get_user_data['role'] == 0) {
							$url = base_url('admin-account-update').'?user='.$url_key;
						} else {
							$url = base_url('user-account-update').'?user='.$url_key;
						}

						$title = 'Updated!';
						$status = 'success';
						$message = 'Username.';
					}
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AdminUpdatePassword() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$pass = $this->input->post('new_password');

			// hash password
			$password = password_hash($pass, PASSWORD_DEFAULT);

			$update_password = $this->AccntMdl->update_user_password($url_key, $password);

			if ($update_password) {
				$get_user_data = $this->AccntMdl->url_auth('id, role', $url_key);
				// identify if logged
				if ($get_user_data['id'] == $this->data['user_id_details']['id']) {
					$title = 'Updated!';
					$status = 'success';
					$message = 'Successfully updated your password. Please login again.';
					$url = base_url('admin_logout');
				}

				else {
					// get account role
					if ($get_user_data['role'] == 0) {
						$url = base_url('admin-account-update').'?user='.$url_key;
					} else {
						$url = base_url('user-account-update').'?user='.$url_key;
					}

					$title = 'Updated!';
					$status = 'success';
					$message = 'Password.';
				}
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AdminUpdatePersonalInfo() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			$fn = $this->input->post('fn');
			$mi = $this->input->post('mi');
			$ln = $this->input->post('ln');
			$gender = $this->input->post('gender');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$field_office = $this->input->post('field_office');
			$position = $this->input->post('position');
			$user_type = $this->input->post('user_type');
			
			$update_personal_info = $this->AccntMdl->update_user_personal_info($url_key, $fn, $mi, $ln, $gender, $contact, $email_add, $field_office, $position, $user_type);

			if ($update_personal_info) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Personal Information.';
				$url = '';
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AdminUpdateSecurity() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			$security_question = $this->input->post('security_question');
			$security_answer = $this->input->post('security_answer');

			$udpate_security = $this->AccntMdl->update_user_security($url_key, $security_question, $security_answer);

			if ($udpate_security) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Security details.';
				$url = '';
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateUserImage() {
		$url_key = $_GET['user'];

		$path = './assets/images/user';
		$filename = date('ymdhis');
		
		$this->imageUpload($path, $filename);

		if (!$this->upload->do_upload('image')) {
			$title = 'Unabled';
			$status = 'error';
			$message = 'Unable to upload image type.';
			$url = '';
		}

		else {
			$image = $this->upload->data();
			$realname = $filename.$image['file_ext'];

			$result = $this->AccntMdl->update_user_image($url_key, $realname);

			if ($result) {
				$get_user_data = $this->AccntMdl->url_auth('id, role', $url_key);

				// get account role
				if ($get_user_data['role'] == 0) {
					$url = base_url('admin-account-update').'?user='.$url_key;
				} else {
					$url = base_url('user-account-update').'?user='.$url_key;
				}
				
				$title = 'Success';
				$status = 'success';
				$message = 'Updated User Image.';
			}
			
			else {
				$title = 'Unabled';
				$status = 'warning';
				$message = 'Unable to upload user image.';
				$url = '';
			}
		}

		// pass ajax request / please see data thru devtools
		echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
	}

	public function AddFieldOffice() {
		if ($_POST['action'] == 'submit') {
			$fo_tag = $this->input->post('fo_tag');
			$field_office = $this->input->post('field_office');
			$director = $this->input->post('director');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$office_address = $this->input->post('office_address');

			// validate fo tag existence
			$validate = $this->FoMdl->fetch_by_fo_tag('*', $fo_tag);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Select another FO-Tag.';
				$url = '';
			}

			else {
				// save field office
				$add_fo = $this->FoMdl->add_field_office($fo_tag, $field_office, $director, $contact, $email_add, $office_address);

				if ($add_fo) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added field office.';
					$url = base_url('manage-field-office');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateFieldOffice() {
		if ($_POST['action'] == 'submit') {
			$get_url = $this->input->post('get_url');
			$field_office = $this->input->post('field_office');
			$director = $this->input->post('director');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$office_address = $this->input->post('office_address');

			// udpate field office
			$udpate_fo = $this->FoMdl->update_field_office($get_url, $field_office, $director, $contact, $email_add, $office_address);

			if ($udpate_fo) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Field office details.';
				$url = '';
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddPosition() {
		if ($_POST['action'] == 'submit') {
			$position = $this->input->post('position');

			$url_key = md5(uniqid(rand(), true));

			// check position if existed
			$validate = $this->PositionMdl->fetch_by_position('*', $position);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Select another position.';
				$url = '';
			}

			else {
				// save position
				$add_position = $this->PositionMdl->add_position($url_key, $position);

				if ($add_position) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added position.';
					$url = base_url('manage-system-information');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeletePosition() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_position = $this->PositionMdl->delete_position($url_key);

			if ($delete_position) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted position.';
				$url = base_url('manage-system-information');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdatePosition() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$position = $this->input->post('position');

			// update position
			$update_position = $this->PositionMdl->update_position($url_key, $position);

			if ($update_position) {
				$title = 'updated!';
				$status = 'success';
				$message = 'Successfully updated position.';
				$url = base_url('position-details').'?id='.$url_key;
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddQuestion() {
		if ($_POST['action'] == 'submit') {
			$security_question = $this->input->post('security_question');

			$url_key = md5(uniqid(rand(), true));

			// check position if existed
			$validate = $this->SecurityMdl->fetch_by_question('*', $security_question);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Select another question.';
				$url = '';
			}

			else {
				// save position
				$add_position = $this->SecurityMdl->add_question($url_key, $security_question);

				if ($add_position) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added security question.';
					$url = base_url('manage-system-information');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteQuestion() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_question = $this->SecurityMdl->delete_question($url_key);

			if ($delete_question) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted security question.';
				$url = base_url('manage-system-information');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateQuestion() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$security_question = $this->input->post('security_question');

			// update position
			$update_question = $this->SecurityMdl->update_question($url_key, $security_question);

			if ($update_question) {
				$title = 'updated!';
				$status = 'success';
				$message = 'Successfully udpate security question.';
				$url = base_url('question-details').'?id='.$url_key;
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateIcon() {
		$id = '1';

		$path = './assets/images/system';
		$filename = date('ymdhis');
		
		$this->imageUpload($path, $filename);

		if (!$this->upload->do_upload('new_icon')) {
			$title = 'Unabled';
			$status = 'error';
			$message = 'Unable to upload image type.';
			$url = '';
		}

		else {
			$image = $this->upload->data();
			$realname = $filename.$image['file_ext'];

			$result = $this->WebinfoMdl->update_icon($id, $realname);

			if ($result) {
				$title = 'Success';
				$status = 'success';
				$message = 'Updated system icon.';
				$url = base_url('manage-system-information');
			}
			
			else {
				$title = 'Unabled';
				$status = 'warning';
				$message = 'Unable to upload image.';
				$url = '';
			}
		}

		// pass ajax request / please see data thru devtools
		echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
	}

	public function UpdateWebInfo() {
		if ($_POST['action'] == 'submit') {
			$id = '1';
			$title = $this->input->post('title');
			$header = $this->input->post('header');
			$footer = $this->input->post('footer');
			$agency = $this->input->post('agency');
			$tel_num = $this->input->post('tel_num');
			$email_add = $this->input->post('email_add');
			$address = $this->input->post('address');
			$office_hr = $this->input->post('office_hr');

			// update position
			$update_web_info = $this->WebinfoMdl->update_web_info($id, $title, $header, $footer, $agency, $tel_num, $email_add, $address, $office_hr);

			if ($update_web_info) {
				$title = 'updated!';
				$status = 'success';
				$message = 'Successfully updated website information.';
				$url = base_url('manage-system-information');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddAdminAccount() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$field_office = 'region';
			$position = $this->input->post('position');
			$gender = $this->input->post('gender');
			$fn = $this->input->post('fn');
			$mi = $this->input->post('mi');
			$ln = $this->input->post('ln');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$username = $this->input->post('username');
			// additional fields
			$url_key = md5(uniqid(rand(), true));

			if ($gender == 'male') {
				$image = 'male.png';
			} else {
				$image = 'female.png';
			}
			
			$pass = '123456';
			$password = password_hash($pass, PASSWORD_DEFAULT);
			$security_code = rand(111111,999999);
			$role = 0;
			$active_status = 1;
			$user_type = '';
		
			// save new user account
			// validate username if existence
			$validate = $this->AccntMdl->username_auth('*', $username);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Username already used.';
				$url = '';
			}

			else {
				// save user account
				$save_account = $this->AccntMdl->add_account($url_key, $fn, $mi, $ln, $gender, $contact, $image, $email_add, $field_office, $position, $user_type, $username, $password, $security_code, $role, $active_status);

				if ($save_account) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added admin account.';
					$url = base_url('manage-admin-account');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddHoliday() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$particular_date = $this->input->post('particular_date');
			$particular = $this->input->post('particular');
			$field_office = $this->input->post('field_office');
			$date_description = $this->input->post('date_description');

			$url_key = md5(uniqid(rand(), true));

			// check if date is already added
			$validate = $this->HolidayMdl->fetch_holiday_by_date_fo('particular_date, field_office', $particular_date, $field_office);

			if ($validate > 0) {
				$title = 'Aleardy added!';
				$status = 'warning';
				$message = 'Date already assigned as '.$particular.' in the field office.';
				$url = '';
			} 

			else {
				// save
				$save_holiday = $this->HolidayMdl->add_holiday($url_key, $particular_date, $particular, $field_office, $date_description);

				if ($save_holiday) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added holiday.';
					$url = base_url('manage-holidays');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteHoliday() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_holiday = $this->HolidayMdl->delete_holiday($url_key);

			if ($delete_holiday) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted date.';
				$url = base_url('manage-holidays');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateHoliday() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$particular_date = $this->input->post('particular_date');
			$particular = $this->input->post('particular');
			$field_office = $this->input->post('field_office');
			$date_description = $this->input->post('date_description');

				// update position
			$update_holiday = $this->HolidayMdl->update_holiday($url_key, $particular, $field_office, $date_description);

			if ($update_holiday) {
				$title = 'updated!';
				$status = 'success';
				$message = 'Successfully updated holiday info.';
				$url = base_url('manage-holidays-details').'?holiday='.$url_key;
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddAgency() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$field_office = $this->input->post('field_office');
			$agency_name = $this->input->post('agency_name');

			$url_key = md5(uniqid(rand(), true));

			// check if date is already added
			$validate = $this->AgencyMdl->fetch_fo_agency('agency_name, field_office', $agency_name, $field_office);

			if ($validate > 0) {
				$title = 'Aleardy added!';
				$status = 'warning';
				$message = 'Agency name already assigned to field office.';
				$url = '';
			} 

			else {
				// save
				$save_agency = $this->AgencyMdl->add_agency($url_key, $agency_name, $field_office);

				if ($save_agency) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added agency.';
					$url = base_url('manage-agency');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateAgency() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$field_office = $this->input->post('field_office');
			$agency_name = $this->input->post('agency_name');

			// check if the field office has the same date for holiday before updating
			$validate = $this->AgencyMdl->fetch_fo_agency('*', $agency_name, $field_office);

			if ($validate > 0) {
				$title = 'Aleardy used!';
				$status = 'warning';
				$message = 'Agency name already assigned to field office.';
				$url = '';
			}

			else {
				// update position
				$update_agency = $this->AgencyMdl->update_agency($url_key, $field_office, $agency_name);

				if ($update_agency) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated agency information.';
					$url = base_url('manage-agency-details').'?agency='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteAgency() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_agency = $this->AgencyMdl->delete_agency($url_key);

			if ($delete_agency) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted agency.';
				$url = base_url('manage-agency');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddAction() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$action_taken = $this->input->post('action_taken');
			$signing_status = $this->input->post('signing_status');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->ActionMdl->fetch_action('*', $action_taken);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Action already added.';
				$url = '';
			} 

			else {
				// save
				$save_action = $this->ActionMdl->add_action($url_key, $action_taken, $signing_status);

				if ($save_action) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added action.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateAction() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$action_taken = $this->input->post('action_taken');
			$signing_status = $this->input->post('signing_status');

			// update position
			$update_action = $this->ActionMdl->update_action($url_key, $action_taken, $signing_status);

			if ($update_action) {
				$title = 'updated!';
				$status = 'success';
				$message = 'Successfully updated field office action.';
				$url = base_url('manage-action-details').'?action='.$url_key;
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteAction() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_action = $this->ActionMdl->delete_action($url_key);

			if ($delete_action) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted action.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddNature() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$appointment_nature = $this->input->post('appointment_nature');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->ApptNatureMdl->fetch_nature('*', $appointment_nature);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Appointment nature already added.';
				$url = '';
			} 

			else {
				// save
				$save_action = $this->ApptNatureMdl->add_nature($url_key, $appointment_nature);

				if ($save_action) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added nature of appointment.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateNature() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$appointment_nature = $this->input->post('appointment_nature');

			// check if action is already added
			$validate = $this->ApptNatureMdl->fetch_nature('*', $appointment_nature);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Nature of appointment already added.';
				$url = '';
			}

			else {
				// update position
				$update_nature = $this->ApptNatureMdl->update_nature($url_key, $appointment_nature);

				if ($update_nature) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated field office action.';
					$url = base_url('manage-nature-details').'?nature='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteNature() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_nature = $this->ApptNatureMdl->delete_nature($url_key);

			if ($delete_nature) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted nature of appointment.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddDisability() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$disability_type = $this->input->post('disability_type');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->DisabilityMdl->fetch_disability_type('*', $disability_type);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Appointment nature already added.';
				$url = '';
			} 

			else {
				// save
				$save_action = $this->DisabilityMdl->add_disability($url_key, $disability_type);

				if ($save_action) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added disability type.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateDisability() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$disability_type = $this->input->post('disability_type');

			// check if action is already added
			$validate = $this->DisabilityMdl->fetch_disability_type('*', $disability_type);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Disability type already added.';
				$url = '';
			}

			else {
				// update position
				$update_disability = $this->DisabilityMdl->update_disability($url_key, $disability_type);

				if ($update_disability) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated type of disability.';
					$url = base_url('manage-disability-details').'?disability='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteDisability() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete position
			$delete_disability = $this->DisabilityMdl->delete_disability($url_key);

			if ($delete_disability) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted disability type.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddEligibility() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$eligibility_type = $this->input->post('eligibility_type');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->EligibilityMdl->fetch_eligibility_type('*', $eligibility_type);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Type of eligibility already added.';
				$url = '';
			} 

			else {
				// save
				$save_action = $this->EligibilityMdl->add_eligibility($url_key, $eligibility_type);

				if ($save_action) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added eligibility type.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateEligibility() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$eligibility_type = $this->input->post('eligibility_type');

			// check if action is already added
			$validate = $this->EligibilityMdl->fetch_eligibility_type('*', $eligibility_type);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Eligibility type already added.';
				$url = '';
			}

			else {
				// update position
				$update_eligibility = $this->EligibilityMdl->update_eligibility($url_key, $eligibility_type);

				if ($update_eligibility) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated type of eligibility.';
					$url = base_url('manage-eligibility-details').'?eligibility='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteEligibility() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete eligibility
			$delete_eligibility = $this->EligibilityMdl->delete_eligibility($url_key);

			if ($delete_eligibility) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted eligibility type.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddEmploymentStatus() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$employment_status = $this->input->post('employment_status');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->EmpStatusMdl->fetch_status_employment('*', $employment_status);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Emploment status already added.';
				$url = '';
			} 

			else {
				// save
				$add_employment_status = $this->EmpStatusMdl->add_employment_status($url_key, $employment_status);

				if ($add_employment_status) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added employment status.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateEmploymentStatus() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$employment_status = $this->input->post('employment_status');

			// check if action is already added
			$validate = $this->EmpStatusMdl->fetch_status_employment('*', $employment_status);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Emploment status already added.';
				$url = '';
			}

			else {
				// update position
				$update_employment_status = $this->EmpStatusMdl->update_employment_status($url_key, $employment_status);

				if ($update_employment_status) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated emploment status.';
					$url = base_url('manage-employment-status-details').'?employment='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteEmploymentStatus() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete eligibility
			$delete_employment_status = $this->EmpStatusMdl->delete_employment_status($url_key);

			if ($delete_employment_status) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted employment status.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddEthnicity() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$ethnicity = $this->input->post('ethnicity');

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->EthnicityMdl->fetch_ethnicity_type('*', $ethnicity);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Ethnicity already added.';
				$url = '';
			} 

			else {
				// save
				$add_ethnicity = $this->EthnicityMdl->add_ethnicity($url_key, $ethnicity);

				if ($add_ethnicity) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added ethnicity.';
					$url = base_url('manage-appointment-data');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateEthnicity() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$ethnicity = $this->input->post('ethnicity');

			// check if action is already added
			$validate = $this->EthnicityMdl->fetch_ethnicity_type('*', $ethnicity);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Ethnicity already added.';
				$url = '';
			}

			else {
				// update position
				$update_ethnicity = $this->EthnicityMdl->update_ethnicity($url_key, $ethnicity);

				if ($update_ethnicity) {
					$title = 'updated!';
					$status = 'success';
					$message = 'Successfully updated ethnicity.';
					$url = base_url('manage-ethnicity-details').'?ethnicity='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteEthnicity() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete eligibility
			$delete_ethnicity = $this->EthnicityMdl->delete_ethnicity($url_key);

			if ($delete_ethnicity) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted ethnicity.';
				$url = base_url('manage-appointment-data');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function AddActiveYear() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$active_year = $this->input->post('active_year');
			$status = 0;

			$url_key = md5(uniqid(rand(), true));

			// check if action is already added
			$validate = $this->ActiveYearMdl->fetch_active_year_type('*', $active_year);

			if ($validate > 0) {
				$title = 'Existed!';
				$status = 'warning';
				$message = 'Year already added.';
				$url = '';
			} 

			else {
				// save
				$add_active_year = $this->ActiveYearMdl->add_active_year($url_key, $active_year, $status);

				if ($add_active_year) {
					$title = 'Saved!';
					$status = 'success';
					$message = 'Successfully added year.';
					$url = base_url('manage-system-information');
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeleteYear() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');

			// delete eligibility
			$delete_active_year = $this->ActiveYearMdl->delete_active_year($url_key);

			if ($delete_active_year) {
				$title = 'Deleted!';
				$status = 'success';
				$message = 'Successfully deleted year.';
				$url = base_url('manage-system-information');
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function SetActiveYear() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$status = "1";

			// deactivate all data
			$deactivate_year = $this->ActiveYearMdl->deactivate_year();

			if ($deactivate_year) {
				// activate year
				$update_status = $this->ActiveYearMdl->update_status($url_key, $status);

				if ($update_status) {
					$title = 'Updated!';
					$status = 'success';
					$message = 'Successfully updated year status.';
					$url = base_url('year-details').'?id='.$url_key;
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function DeactiveYear() {
		if ($_POST['action'] == 'submit') {
			$url_key = $this->input->post('get_url');
			$year_status = "1";

			$get_year = date('Y');

			// check year if existed
			$check_year = $this->ActiveYearMdl->fetch_active_year_type('*', $get_year);

			if ($check_year > 0) {
				// update active status of current year
				$update_status_year = $this->ActiveYearMdl->update_status_year($year_status, $get_year);

				if ($update_status_year) {
					// deacctivate url key year
					$status = "0";
					$update_status = $this->ActiveYearMdl->update_status($url_key, $status);

					if ($update_status) {
						$title = 'Updated!';
						$status = 'success';
						$message = 'Successfully updated year status.';
						$url = base_url('year-details').'?id='.$url_key;
					}

					else {
						$title = 'Unable!';
						$status = 'error';
						$message = 'Please try again.';
						$url = '';
					}
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			else {
				// deactivate all data
				$deactivate_year = $this->ActiveYearMdl->deactivate_year();

				if ($deactivate_year) {
					// create latest year
					$url_key = md5(uniqid(rand(), true));
					$add_active_year = $this->ActiveYearMdl->add_active_year($url_key, $get_year, $year_status);

					if ($add_active_year) {
						$title = 'Year Updated!';
						$status = 'success';
						$message = 'Successfully added unexisted year and set as active.';
						$url = base_url('manage-system-information');
					}

					else {
						$title = 'Unable!';
						$status = 'error';
						$message = 'Please try again.';
						$url = '';
					}
				}

				else {
					$title = 'Unable!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateAppointment() {
		if ($_POST['action'] == 'submit') {
			// from ajax
			$get_fo = $this->input->post('get_fo');
			$get_id = $this->input->post('get_id');
			$date_received = $this->input->post('date_received');
			$sector = $this->input->post('sector');
			$agency_name = $this->input->post('agency_name');
			$appointee = $this->input->post('appointee');
			$position_title = $this->input->post('position_title');
			$salary_grade = $this->input->post('salary_grade');
			$position_level = $this->input->post('position_level');
			$employment_status = $this->input->post('employment_status');
			$appointment_nature = $this->input->post('appointment_nature');
			$inclusive_date_casual_from = $this->input->post('inclusive_date_casual_from');
			$inclusive_date_casual_to = $this->input->post('inclusive_date_casual_to');
			$appointing_authority = $this->input->post('appointing_authority');
			$issuance_date = $this->input->post('issuance_date');
			$birthday = $this->input->post('birthday');
			$sex = $this->input->post('sex');
			$pwd = $this->input->post('pwd');
			$disability = $this->input->post('disability');
			$member_ip_group = $this->input->post('member_ip_group');
			$ethnicity = $this->input->post('ethnicity');
			$eligibility_type = $this->input->post('eligibility_type');
			$eligibility_effective_date = $this->input->post('eligibility_effective_date');
			$time_used_of_eligibility = $this->input->post('time_used_of_eligibility');

			$db_table = 'appt_'.$get_fo.'_tbl';
			$url_key = $get_id;

			// update
			$update_appt = $this->AppointmentMdl->update_appointment($db_table, $url_key, $date_received, $sector, $agency_name, $appointee, $position_title, $salary_grade, $position_level, $employment_status, $appointment_nature, $inclusive_date_casual_from, $inclusive_date_casual_to, $appointing_authority, $issuance_date, $birthday, $sex, $pwd, $disability, $member_ip_group, $ethnicity, $eligibility_type, $eligibility_effective_date, $time_used_of_eligibility);

			if ($update_appt) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Successfully updated appointment information.';
				$url = base_url('field-office-appointment-update').'?fo='.$get_fo.'&&id='.$get_id;
			}

			else {
				$title = 'Unable!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function loadProcessor() {
		if ($_POST['action'] == 'submit') {
			$fo_tag = $this->input->post('fo_tag');
			$load_month = $this->input->post('load_month');

			$this->session->set_userdata(array('session_fo_tag' => $fo_tag));
			$this->session->set_userdata(array('session_load_month' => $load_month));

			$status = 'success';
			$url = base_url('administrator');

			// pass ajax request / please see data thru devtools
			echo json_encode(array('status' => $status, 'url' => $url));
		}
	}
}