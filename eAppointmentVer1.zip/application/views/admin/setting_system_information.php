<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Manage Settings</span> - System Information</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-user-tie text-primary"></i> <span>Position</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-lock text-primary"></i> <span>Security Question</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-wrench position-left"></i> Settings</li>
				<li class="active">System Information</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<form method="post" id="imgFile" enctype="multipart/form-data">
			<div class="row">
				<div class="col-md-12">
					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-info22"></i> Web information</b><br>
								<small>Manage/Update system details/information.</small>
							</h6>

							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<div class="row">
								<div class="col-md-6">
									<div class="form-group has-feedback has-feedback-left">
										<label for="title">Title</label>
										<input id="title" name="title" type="text" class="form-control input-xs" placeholder="Title" autocomplete="off" value="<?=$showinfo['title']?>">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="header">Header</label>
										<input id="header" name="header" type="text" class="form-control input-xs" placeholder="Header" autocomplete="off" value="<?=$showinfo['header']?>">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="footer">Footer</label>
										<input id="footer" name="footer" type="text" class="form-control input-xs" placeholder="Footer" autocomplete="off" value="<?=$showinfo['footer']?>">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="agency">Agency</label>
										<input id="agency" name="agency" type="text" class="form-control input-xs" placeholder="Agency" autocomplete="off" value="<?=$showinfo['agency']?>">
										<div class="form-control-feedback">
											<i class="icon icon-office"></i>
										</div>
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group has-feedback has-feedback-left">
										<label for="tel_num">Office Number</label>
										<input id="tel_num" name="tel_num" type="text" class="form-control input-xs" placeholder="Office Number" autocomplete="off" value="<?=$showinfo['tel_num']?>">
										<div class="form-control-feedback">
											<i class="icon icon-phone2"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="email_add">Email Address</label>
										<input id="email_add" name="email_add" type="email" class="form-control input-xs" placeholder="email_add" autocomplete="off" value="<?=$showinfo['email_add']?>">
										<div class="form-control-feedback">
											<i class="icon icon-envelop"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="address">Address</label>
										<input id="address" name="address" type="text" class="form-control input-xs" placeholder="Address" autocomplete="off" value="<?=$showinfo['address']?>">
										<div class="form-control-feedback">
											<i class="icon icon-location4"></i>
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="office_hr">Office Hr</label>
										<input id="office_hr" name="office_hr" type="text" class="form-control input-xs" placeholder="Office Hr" autocomplete="off" value="<?=$showinfo['office_hr']?>">
										<div class="form-control-feedback">
											<i class="icon icon-alarm"></i>
										</div>
									</div>
								</div>

								<button onclick="update_web_info()" type="button" class="btn btn-primary btn-xs pull-right" >
									<i class="icon-reset position-left"></i> Update Info
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-md-4">
					<div class="thumbnail">
						<div class="thumb">
							<img src="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>" alt="" style="width: 50%;padding-top: 20px;padding-bottom: 20px;" class="img-responsive">

							<div class="caption-overflow">
								<span>
									<button type="button" class="btn btn-link btn-icon text-white" data-toggle="modal" data-target="#change_system_logo">
										<i class="icon-circle-right2 icon-2x"></i>
									</button>
								</span>
							</div>
						</div>

						<div class="caption">
							Change system logo.
						</div>
					</div>

					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-calendar2"></i> Add Active Year</b><br>
								<small>Please fillout all the field/s.</small>
							</h6>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<div class="form-group has-feedback has-feedback-left">
								<select class="form-control input-xs" id="active_year" name="active_year">
									<option value="">- Select Year -</option>
									<option disabled>--------------------------</option>
									<?php
										for ($year=2015; $year < date('Y') + 5; $year++) { 
											echo '
												<option value = "'.$year.'">'.$year.'</option>
											';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-calendar2"></i>
								</div>
							</div>

							<button onclick="add_year()" type="button" class="btn btn-primary btn-xs pull-right" >
								<i class="icon-plus-circle2 position-left"></i> Add Year
							</button>

							<br><br><br>

							<h6 class="panel-title">
								<b><i class="icon-list-unordered"></i> List of Year/s</b><br>
								<small>Manage Year.</small>
							</h6>

							<table class="table datatable-button-print-columns">
								<thead>
									<tr>
										<th>Annual Year</th>
										<th>Status</th>
										<th>Created On</th>
									</tr>
								</thead>

								<tbody>
									<?php
										$num = 1;
										if (is_array($fetch_active_year)) {
											foreach ($fetch_active_year as $list) {
												if ($list->status == "0") {
													$year_status = "Deactive";
												} else {
													$year_status = "Active";
												}
												
												echo '
													<tr>
														<td>
															<a href="'.base_url('year-details').'?id='.$list->url_key.'">
																'.$list->active_year.'
															</a>
														</td>
														<td>'.$year_status.'</td>
														<td>'.$list->created_on.'</td>
													</tr>
												';
											}
										}

										else {
											echo '
												<tr>
													<td colspan="5">No data</td>
												</tr>
											';
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
				</div>

				<div class="col-md-4">
					<!-- manage question -->
					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-question4"></i> Add Question</b><br>
								<small>Please fillout all the field/s.</small>
							</h6>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<div class="form-group has-feedback has-feedback-left">
								<input id="security_question" name="security_question" type="text" class="form-control input-xs" placeholder="Security Question" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>

							<button onclick="add_question()" type="button" class="btn btn-primary btn-xs pull-right" >
								<i class="icon-plus-circle2 position-left"></i> Add Question
							</button>

							<br><br><br>

							<h6 class="panel-title">
								<b><i class="icon-list-unordered"></i> List of all question/s</b><br>
								<small>Manage question/s.</small>
							</h6>

							<table class="table datatable-button-print-columns">
								<thead>
									<tr>
										<th>#</th>
										<th>Security Question</th>
										<th>Created On</th>
									</tr>
								</thead>

								<tbody>
									<?php
										$num = 1;
										if (is_array($question)) {
											foreach ($question as $list) {
												echo '
													<tr>
														<td>'.$num++.'</td>
														<td>
															<a href="'.base_url('question-details').'?id='.$list->url_key.'">
																'.$list->security_question.'
															</a>
														</td>
														<td>'.$list->created_on.'</td>
													</tr>
												';
											}
										}

										else {
											echo '
												<tr>
													<td colspan="5">No data</td>
												</tr>
											';
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
					<!-- manage question -->
				</div>

				<div class="col-md-4">
					<!-- manage position -->
					<div class="panel panel-default">
						<div class="panel-heading">
							<h6 class="panel-title">
								<b><i class="icon-plus-circle2"></i> Add Position</b><br>
								<small>Please fillout all the field/s.</small>
							</h6>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                	</ul>
		                	</div>
						</div>
						
						<div class="panel-body">
							<div class="form-group has-feedback has-feedback-left">
								<input id="position" name="position" type="text" class="form-control input-xs" placeholder="Position" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user-tie"></i>
								</div>
							</div>

							<button onclick="add_position()" type="button" class="btn btn-primary btn-xs pull-right" >
								<i class="icon-plus-circle2 position-left"></i> Add Position
							</button>

							<br><br><br>

							<h6 class="panel-title">
								<b><i class="icon-list-unordered"></i> List of all position/s</b><br>
								<small>Manage position/s.</small>
							</h6>

							<table class="table datatable-button-print-columns">
								<thead>
									<tr>
										<th>#</th>
										<th>Position</th>
										<th>Created On</th>
									</tr>
								</thead>

								<tbody>
									<?php
										$num = 1;
										if (is_array($position)) {
											foreach ($position as $list) {
												echo '
													<tr>
														<td>'.$num++.'</td>
														<td>
															<a href="'.base_url('position-details').'?id='.$list->url_key.'">
																'.$list->position.'
															</a>
														</td>
														<td>'.$list->created_on.'</td>
													</tr>
												';
											}
										}

										else {
											echo '
												<tr>
													<td colspan="3">No data</td>
												</tr>
											';
										}
									?>
								</tbody>
							</table>
						</div>
					</div>
					<!-- manage position -->
				</div>
			</div>

			<!-- modals -->
			<div id="change_system_logo" class="modal fade">
				<div class="modal-dialog modal-sm">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h5 class="modal-title">Change System Logo</h5>
						</div>

						<div class="modal-body">
							<div class="form-group has-feedback has-feedback-left">
								<label for="new_icon">Upload Image</label>
								<input id="new_icon" name="new_icon" type="file" class="form-control input-xs" placeholder="Position" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-image2"></i>
								</div>
							</div>
						</div>

						<div class="modal-footer">
							<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
							<button onclick="update_icon()" type="button" class="btn btn-primary btn-xs">
								<i class="icon icon-reset"></i> Update
							</button>
						</div>
					</div>
				</div>
			</div>
			<!-- modals -->
		</form>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->