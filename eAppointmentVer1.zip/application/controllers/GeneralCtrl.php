<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class GeneralCtrl extends CI_Controller {
	private $data;
	private $data2;

	public function __construct() {
		parent:: __construct();
		// set internet timezone
		date_default_timezone_set('Asia/Manila');
		
		// including all models
		include 'includes/models.php';
	}

	public function error_404() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
		);

		$this->load->view('error_404', $this->data);
	}	
}
?>