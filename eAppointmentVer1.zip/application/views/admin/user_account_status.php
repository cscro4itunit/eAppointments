<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - User Account Status</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-users4 text-primary"></i> <span>User Account</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li>User Account</li>
				<li>Account details</li>
				<li class="active">Status</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">
				<!-- User Details -->
				<div class="panel panel-default">
					<div class="panel-heading" style="background-color: #d7dafa;">
						<h6 class="panel-title">
							<b><i class="icon-users"></i> Account Information</b>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<b>Name</b>: <?=$user_details['fn']?>&nbsp;<?=$user_details['mi']?>&nbsp;<?=$user_details['ln']?><br>
						<b>Field Office</b>: 
							<?php
								foreach ($assigned_fo as $key) {
									echo $key->field_office;
								}
							?><br>
						<b>Position</b>: <?=$user_details['position']?><br><br>

						<?php
							$active_status = $user_details['active_status'];

							if ($active_status == 0) {
								echo '
									<button onclick="activate_account()" type="button" class="btn btn-success btn-xs pull-right">
										<i class="icon-user-check position-left"></i> ACTIVATE ACCOUNT
									</button>
								';
							}

							else {
								echo '
									<button onclick="deactivate_account()" type="button" class="btn btn-danger btn-xs pull-right">
										<i class="icon-user-block position-left"></i> DEACTIVATE ACCOUNT
									</button>
								';
							}
						?>
					</div>
				</div>
				<!-- User Details -->
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->