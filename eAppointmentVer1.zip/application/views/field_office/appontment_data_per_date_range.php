<input type="hidden" id="base_url" value="<?=base_url()?>">
<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Appointment</span></h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar5 text-primary"></i> <span>Data</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><a href="#"><i class="icon-database2 position-left"></i> Appointment</a></li>
				<li>Master List</li>
				<li class="active">Date Range From: <?=$get_date_from?> To: <?=$get_date_to?></li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('dashboard')?>"><?=$showinfo['header']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-3">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-search4"></i> Search Date Range</b><br>
							<small>Filter details by date</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
		            	</div>
					</div>
					
					<div class="panel-body">
						<form method="post">
							<div class="form-group">
								<label>Starting Date</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="icon-calendar22"></i></span>
									<input id="starting_date" name="starting_date" type="date" class="form-control" value="<?=$get_date_from?>"> 
								</div>
							</div>

							<div class="form-group">
								<label>Ending Date</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="icon-calendar22"></i></span>
									<input id="ending_date" name="ending_date" type="date" class="form-control" value="<?=$get_date_to?>"> 
								</div>
							</div>

							<div class="form-group">
								<label>Field Officer</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="icon-user"></i></span>
									<select class="form-control" id="field_officer" name="field_officer">
										<option value="">- Select Field Officer -</option>
										<?php
											if (is_array($fetch_fo_users)) {
												foreach ($fetch_fo_users as $list) {
													echo '
														<option value="'.$list->id.'">'.$list->fn.' '.$list->ln.'</option>
													';
												}
											}
										?>
									</select>
								</div>
							</div>

							<div class="form-group">
								<label>Appointment Status</label>
								<div class="input-group">
									<span class="input-group-addon"><i class="icon-price-tags"></i></span>
									<select class="form-control" id="appointment_status" name="appointment_status" onchange="triggered_officer()">
										<option value="">- Select Status -</option>
										<option value="Received">Received</option>
										<option value="Acted">Acted</option>
										<option value="Signed">Signed</option>
									</select>
								</div>
							</div>

							<button onclick="search_date_received()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
								<i class="icon icon-search4"></i> Search
							</button>
						</form>
					</div>
				</div>
			</div>

			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> Appointments Recieved From <i style="color: red;"><?=$get_date_from?></i> To <i style="color: red;"><?=$get_date_to?></i></b><br>
							<small>Note: Fetched data may varied thru selected date range.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
		            	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
					<thead>
						<th>ID</th>
						<th>Date Received</th>
						<th>Agency Name</th>
						<th>Appointee</th>
						<th>Position Title</th>
						<th>Due Date</th>
						<th>Appointment Status</th>
					</thead>

					<tbody>
						<?php
							if (is_array($fetch_appt_between_date_range)) {
								foreach ($fetch_appt_between_date_range as $list) {
									echo '
										<tr>
											<td>'.$list->unique_id_number.'</td>
											<td>'.$list->date_received.'</td>
											<td>'.$list->agency_name.'</td>
											<td>'.$list->appointee.'</td>
											<td>'.$list->position_title.'</td>
											<td>'.$list->due_date.'</td>
											<td>'.$list->appointment_status.'</td>
										</tr>
									';
								}
							}

							else {
								echo 'No data found!';
							}
						?>
					</tbody>
				</table>
					</div>
				</div>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>