<?php
class ApptNatureMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'appointment_nature_tbl';
	}

	// crud
	public function add_nature($url_key, $appointment_nature) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, appointment_nature)
			VALUES("'.$url_key.'", "'.$appointment_nature.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_nature($url_key, $appointment_nature) {
		$sql = 'UPDATE '.$this->table.' SET appointment_nature = "'.$appointment_nature.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_nature($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function fetch_appt_nature($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY appointment_nature ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_nature($field, $appointment_nature) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE appointment_nature = "'.$appointment_nature.'" ORDER BY appointment_nature ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>