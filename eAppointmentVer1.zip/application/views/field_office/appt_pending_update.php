<input type="hidden" id="base_url" value="<?=base_url()?>">
<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Appointment Process</span> - Pending Update</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar5 text-primary"></i> <span>Data</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><a href="#"><i class="icon-stack3 position-left"></i> Appointment Process</a></li>
				<li>Pending Appointments</li>
				<li class="active">For action</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('dashboard')?>"><?=$showinfo['header']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">
					<b><i class="icon-vcard"></i> <?=$fetch_appt_details['appointee']?></b><br>
					<small>Encoded by: <?=$encoded_by['fn']?>&nbsp;<?=$encoded_by['ln']?>.</small>
				</h6>
				<div class="heading-elements">
					<ul class="icons-list">
                		<li><a data-action="collapse"></a></li>
                	</ul>
            	</div>
			</div>
			
			<div class="panel-body">
				<div class="row">
					<div class="col-md-4">
						<p>
							<b>Unique ID Number</b>: <?=$fetch_appt_details['unique_id_number']?><br>
							<b>Date Received</b>: <?=$fetch_appt_details['date_received']?><br>
							<b>Sector</b>: <?=$fetch_appt_details['sector']?><br>
							<b>Name of Agency</b>: <?=$fetch_appt_details['agency_name']?><br>
							<b>Position Title</b>: <?=$fetch_appt_details['position_title']?><br>
							<b>Salary/Job/Pay Grade</b>: <?=$fetch_appt_details['salary_grade']?><br>
							<b>Position Level</b>: <?=$fetch_appt_details['position_level']?><br>
							<b>Employment Status</b>: <?=$fetch_appt_details['employment_status']?><br>
							<b>Nature of Appointment</b>: <?=$fetch_appt_details['appointment_nature']?><br>
							<b>Inclusive Date of Casual or Contructual Appointment</b><br>
								&emsp;from: <?=$fetch_appt_details['inclusive_date_casual_from'] != "" ? $fetch_appt_details['inclusive_date_casual_from'] : 'n/a'?><br>
								&emsp;to: <?=$fetch_appt_details['inclusive_date_casual_to'] != "" ? $fetch_appt_details['inclusive_date_casual_to'] : 'n/a'?><br>

							<b>Name of Appointing Authority</b>: <?=$fetch_appt_details['appointing_authority']?><br>
							<b>Date of Issuance of Appointment</b>: <?=$fetch_appt_details['issuance_date']?><br>
						</p>
					</div>

					<div class="col-md-4">
						<p>
							<b>Date of Birth</b>: <?=$fetch_appt_details['birthday']?><br>
							<b>Sex</b>: <?=$fetch_appt_details['sex']?><br>
							<b>PWD</b>: <?=$fetch_appt_details['pwd']?><br>
								&emsp;if yes, Type of Disability: <?=$fetch_appt_details['disability'] != "" ? $fetch_appt_details['disability'] : 'n/a'?><br>
							<b>Member of IP Group</b>: <?=$fetch_appt_details['member_ip_group']?><br>
							<b>Ethnicity</b>: <?=$fetch_appt_details['ethnicity'] != "" ? $fetch_appt_details['ethnicity'] : 'n/a'?><br>
							<b>Type of Eligibility Used</b>: <?=$fetch_appt_details['eligibility_type'] != "" ? $fetch_appt_details['eligibility_type'] : 'n/a'?><br>
							<b>Date if Effectivity of Eligibility</b>: <?=$fetch_appt_details['eligibility_effective_date'] != "" ? $fetch_appt_details['eligibility_effective_date'] : 'n/a'?><br>
							<b>First Time Used of Eligibility</b>: <?=$fetch_appt_details['time_used_of_eligibility']?><br>
						</p>

						<hr>

						<p>
							<b>Target Processing Days</b>: <?=$fetch_appt_details['target_processing_days']?> Days<br>
							<b>Due Date</b>: <?=$fetch_appt_details['due_date']?><br>
						</p>
					</div>

					<div class="col-md-4">
						<div class="form-group has-feedback has-feedback-left">
							<label for="action_taken">Action Taken by FO</label>
							<select class="form-control input-xs" id="action_taken" name="action_taken">
								<option value="">- Select Action -</option>
								<?php
									if (is_array($get_action)) {
										foreach ($get_action as $list) {
											echo '
												<option value="'.$list->action_taken.'">'.$list->action_taken.'</option>
											';
										}
									}

									else {
										echo 'No data found!';
									}
								?>
							</select>
							<div class="form-control-feedback">
								<i class="icon icon-forward"></i>
							</div>
						</div>

						<div class="form-group has-feedback has-feedback-left">
							<label for="remarks">Remarks</label>
							<textarea rows="6" class="form-control input-xs" id="remarks" name="remarks" style="resize: none;"><?=$fetch_appt_details['remarks']?></textarea>
							<div class="form-control-feedback">
								<i class="icon icon-pencil5"></i>
							</div>
						</div>
					</div>
				</div>

				<br>

				<button id="btn_add_dataEntry" type="button" class="btn btn-primary btn-xs pull-right" onclick="appointment_action()">
					<i class="icon-forward position-left"></i> Action
				</button>
				<br><br>
				<p class="pull-right">Action Date: <i>Today | <?php echo date('Y-m-d') ?></i></p>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>