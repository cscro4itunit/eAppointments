<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Manage Settings</span> - Question Details</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-question4 text-primary"></i> <span>Security Question</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-wrench position-left"></i> Settings</li>
				<li>Security Question</li>
				<li class="active">Details</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-question4"></i> Security Question</b><br>
							<small>Manage details.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<p>
							<b>Position</b>: <?=$get_question['security_question']?><br>
							<b>Created On</b>: <?=$get_question['created_on']?>
						</p>

						<button type="button" class="btn btn-success btn-xs pull-left" data-toggle="modal" data-target="#<?=$get_question['url_key']?>">
							<i class="icon-pencil5 position-left"></i> Edit Question
						</button>

						<button onclick="delete_question()" type="button" class="btn btn-danger btn-xs pull-right" >
							<i class="icon-trash position-left"></i> Delete Question
						</button>
					</div>
				</div>
			</div>
		</div>

		<!-- modals -->
		<div id="<?=$get_question['url_key']?>" class="modal fade">
			<div class="modal-dialog modal-sm">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h5 class="modal-title">Edit Security Question</h5>
					</div>

					<div class="modal-body">
						<div class="form-group has-feedback has-feedback-left">
							<label for="security_question">Security Question</label>
							<input id="security_question" name="security_question" type="text" class="form-control input-xs" placeholder="Security Question" autocomplete="off" value="<?=$get_question['security_question']?>">
							<div class="form-control-feedback">
								<i class="icon icon-user-tie"></i>
							</div>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
						<button onclick="update_question()" type="button" class="btn btn-primary btn-xs pull-right">
							<i class="icon-reset position-left"></i> Update Question
						</button>
					</div>
				</div>
			</div>
		</div>
		<!-- modals -->
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->