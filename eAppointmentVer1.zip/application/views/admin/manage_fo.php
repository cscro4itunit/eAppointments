<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Field Office</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-office text-primary"></i> <span>Field Office</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-wrench position-left"></i> Settings</li>
				<li class="active">Field Office</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<!-- <div class="col-md-3">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-plus-circle2"></i> Add Field Office</b><br>
							<small>Review all the details before submit.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<form method="post">
							<div class="form-group has-feedback has-feedback-left">
								<input id="fo_tag" name="fo_tag" type="text" class="form-control input-xs" placeholder="FO - Tag (No spacing)" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="field_office" name="field_office" type="text" class="form-control input-xs" placeholder="Field Office" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="director" name="director" type="text" class="form-control input-xs" placeholder="Director" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="contact" name="contact" type="text" class="form-control input-xs" placeholder="Office Number" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-phone2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="email_add" name="email_add" type="email" class="form-control input-xs" placeholder="Email Address" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-envelop"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<textarea id="office_address" name="office_address" class="form-control input-xs" rows="4" placeholder="Office Addres" style="width: 100%; resize: none;"></textarea>
								<div class="form-control-feedback">
									<i class="icon icon-home"></i>
								</div>
							</div>

							<p><b>Note:</b> Please review all the details before submit. It will not be undone/delete once submitted, but your can update some necessary information using the link provided from this page</p>

							<button onclick="add_field_office()" type="button" class="btn btn-primary btn-xs pull-right">
								<i class="icon-plus-circle2 position-left"></i> Save Field Office
							</button>
						</form>
					</div>
				</div>
			</div> -->

			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> Field Office list</b><br>
							<small>Manage field office information.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
							<thead>
								<tr>
									<th>Field Office</th>
									<th>Director</th>
									<th>Office Number</th>
									<th>Email Address</th>
									<th>Assigned Unique Key</th>
									<th>Created on</th>
								</tr>
							</thead>

							<tbody>
								<?php
									if (is_array($field_office)) {
										foreach ($field_office as $list) {
											echo '
												<tr>
													<td>
														<a href="'.base_url('field-office-details').'?fo='.$list->fo_tag.'">
															'.$list->field_office.'
														</a>
													</td>
													<td>'.$list->director.'</td>
													<td>'.$list->contact.'</td>
													<td>'.$list->email_add.'</td>
													<td>'.$list->unique_key_starter.'</td>
													<td>'.$list->created_on.'</td>
												</tr>
											';
										}
									}

									else {
										echo '
											<tr>
												<td colspan="5">No data</td>
											</tr>
										';
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->