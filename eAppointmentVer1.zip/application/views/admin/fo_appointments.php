<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Main</span> - Appointments</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-stack3 text-primary"></i> <span>Appointments</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-stack3 position-left"></i> Main</li>
				<li class="active">Appointments</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">
				<h6 class="panel-title">
					<b><i class="icon-office"></i> CALABARZON - Field Offices</b><br>
					<small>Calamba, Laguna, Batangas, Rizal, Quezon</small>
				</h6>

				<br>

				<center>
					<?php
						if (is_array($fo_calabarzon)) {
							foreach ($fo_calabarzon as $list) {
								echo '	
										<a href="'.base_url("field-office-appointment-details").'?fo='.$list->fo_tag.'" class="btn btn-primary btn-lg" style="width:100%;">
											'.$list->field_office.'<br>
											<small style="font-size:11px;color:#000;">'.$list->director.'</small>
										</a><br><br>
								';
							}
						}

						else {
							echo '
								No Field Office Found
							';
						}
					?>
				</center>
			</div>

			<div class="col-md-4">
				<h6 class="panel-title">
					<b><i class="icon-office"></i> MIMAROPA - Field Offices</b><br>
					<small>Occidental/Oriental Mindoro, Marinduque, Romblon, Palawan</small>
				</h6>

				<br>
				
				<center>
					<?php
						if (is_array($fo_mimaropa)) {
							foreach ($fo_mimaropa as $list) {
								echo '	
										<a href="'.base_url("field-office-appointment-details").'?fo='.$list->fo_tag.'" class="btn btn-danger btn-lg" style="width:100%;">
											'.$list->field_office.'<br>
											<small style="font-size:11px;color:#000;">'.$list->director.'</small>
										</a><br><br>
								';
							}
						}

						else {
							echo '
								No Field Office Found
							';
						}
					?>
				</center>
			</div>

			<div class="col-md-4">
				<h6 class="panel-title">
					<b><i class="icon-city"></i> Regional Office</b><br>
					<small>CSC Regional Office IV</small>
				</h6>

				<br>
				
				<center>
					<?php
						if (is_array($region)) {
							foreach ($region as $list) {
								echo '	
										<a href="'.base_url("field-office-appointment-details").'?fo='.$list->fo_tag.'" class="btn btn-success btn-lg" style="width:100%;">
											'.$list->field_office.'<br>
											<small style="font-size:11px;color:#000;">'.$list->director.'</small>
										</a><br><br>
								';
							}
						}

						else {
							echo '
								No Field Office Found
							';
						}
					?>
				</center>
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->