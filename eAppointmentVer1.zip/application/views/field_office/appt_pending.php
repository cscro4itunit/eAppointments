<input type="hidden" id="base_url" value="<?=base_url()?>">
<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Appointment Process</span> - Pending</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar5 text-primary"></i> <span>Data</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><a href="#"><i class="icon-stack3 position-left"></i> Appointment Process</a></li>
				<li class="active">Pending Appointments</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('dashboard')?>"><?=$showinfo['header']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<?php
			include 'includes/appointment_count.php'
		?>
		
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">
					<b><i class="icon-list-unordered"></i> List of pending appointment</b><br>
					<small>For action.</small>
				</h6>
				<div class="heading-elements">
					<ul class="icons-list">
                		<li><a data-action="collapse"></a></li>
                	</ul>
            	</div>
			</div>
			
			<div class="panel-body">
				<table class="table datatable-button-print-columns">
					<thead>
						<th>ID</th>
						<th>Date Received</th>
						<th>Agency Name</th>
						<th>Appointee</th>
						<th>Position Title</th>
						<th>Target WD</th>
						<th>Acted WD</th>
						<th>Target Status</th>
						<th>Status</th>
					</thead>

					<tbody>
						<?php
							if (is_array($fetch_pending)) {
								foreach ($build_array as $list) {
									$date_now = date('Y-m-d');

									// get count of weekends
									$start = new DateTime($list['appointment_data']->date_received);
									$end = new DateTime($date_now);
									$days = $start->diff($end, true)->days;
									$sundays = intval($days / 7) + ($start->format('N') + $days % 7 >= 7);
									$saturdays = intval($days / 7) + ($start->format('N') + $days % 6 >= 7);
									$weekends = $sundays + $saturdays;

									// acted working days
									$date_received = date_create($list['appointment_data']->date_received);
									$get_date_signed = date_create($date_now);
									$diff = date_diff($date_received,$get_date_signed);
									$between_count = $diff->format("%a");

									// count holiday
									$acted_wd = $between_count - ($weekends + $list['count_between_holiday'] + $list['count_between_assigned_holiday']);
									
								    // 	$list['appointment_data']->due_date
									if ($list['appointment_data']->target_processing_days <= $acted_wd) {
										$text_color = 'red';
										$due_remarks = 'Overdue';
									} else {
										$text_color = '';
										$due_remarks = 'Within';
									}
									
									echo '
										<tr>
											<td>
												<abbr title="For action" style="text-decoration:none;">
													<a href="'.base_url('appontments-processing-pending-update').'?id='.$list['appointment_data']->url_key.'" style="text-decoration:none;">
														'.$list['appointment_data']->unique_id_number.'
													</a>
												</abbr>
												
											</td>
											<td>'.$list['appointment_data']->date_received.'</td>
											<td>'.$list['appointment_data']->agency_name.'</td>
											<td>'.$list['appointment_data']->appointee.'</td>
											<td>'.$list['appointment_data']->position_title.'</td>
											<td>'.$list['appointment_data']->target_processing_days.' Days</td>
											<td style="color:'.$text_color.';">'.$acted_wd.' Days</td>
											<td style="color:'.$text_color.';">'.$due_remarks.'</td>
											<td>'.$list['appointment_data']->appointment_status.'</td>
										</tr>
									';
								}
							}

							else {
								echo 'No data found!';
							}
						?>
					</tbody>
				</table>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>