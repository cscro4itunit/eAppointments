<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class GuestCtrl extends CI_Controller {
	private $data;

	public function __construct() {
		parent:: __construct();
		// including all models
		include 'includes/models.php';

		// set internet timezone
		date_default_timezone_set('Asia/Manila');
		$this->data['current_year'] = date('Y');

		// callout session that was set after login
		$this->accnt_id = $this->session->userdata('session_id');

		// select * details of user
		$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

		if ($this->accnt_id != "") {
			switch ($this->data['user_id_details']['role']) {
				case 0:
					redirect(base_url('administrator'));
					break;

				case 1:
					redirect(base_url('dashboard'));
					break;
				
				default:
					base_url('error_404');
					break;
			}
		}
	}

	// navigati0n
	public function index() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'field_office' => $this->FoMdl->get_fo('*'),
			'jscript' => 'appt_tracker',
		);

		$this->load->view('hrmo', $this->data);
	}

	public function track_my_appointment() {
		if (!isset($_GET['appt'])) {
			$this->data = array(
				'showinfo' => $this->WebinfoMdl->show_webinfo(),
			);
			
			$this->load->view('error_405', $this->data);
		}

		else {
			$get_url = $_GET['appt'];
			$unique_id_number = $this->session->userdata('appt_code');
			$db_table = $this->session->userdata('db_table');
			$field_office = $this->session->userdata('field_office');

			if (password_verify($unique_id_number, $get_url)) {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
					'jscript' => 'appt_tracker',
					'fetch_by_fo_tag' => $this->FoMdl->fetch_by_fo_tag('*', $field_office),
					'appointment_data' => $this->AppointmentMdl->auth_unique_key($db_table, '*', $unique_id_number),
				);

				$this->load->view('track_my_appointment', $this->data);
			}

			else {
				$this->data = array(
					'showinfo' => $this->WebinfoMdl->show_webinfo(),
				);
				
				$this->load->view('error_403', $this->data);
			}
			
		}
	}

	// function
	public function CheckCode() {
		if ($_POST['action'] == 'submit') {
			// from ajax request
			$field_office = $this->input->post('field_office');
			$unique_id_number = $this->input->post('unique_id_number');
			// hash id
			$appt_id = password_hash($unique_id_number, PASSWORD_DEFAULT);

			$db_table = 'appt_'.$field_office.'_tbl';

			// check if id is exsisted
			$validate = $this->AppointmentMdl->auth_unique_key($db_table, 'unique_id_number', $unique_id_number);

			if ($validate > 0) {
				$this->session->set_userdata(array('appt_code' => $unique_id_number));
				$this->session->set_userdata(array('db_table' => $db_table));
				$this->session->set_userdata(array('field_office' => $field_office));

				$title = 'Found!';
				$status = 'success';
				$message = 'Please wait while redirecting...';
				$url = 'track-my-appointment?appt='.$appt_id;
			}

			else {
				$title = 'No Data Found!';
				$status = 'warning';
				$message = 'Please check your appointment code and try again.';
				$url = '';
			}

			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}
}
?>