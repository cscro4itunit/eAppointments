<?php
class PositionMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'position_tbl';
	}

	// CRUD
	public function add_position ($url_key, $position) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, position) VALUES("'.$url_key.'", "'.$position.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function delete_position($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_position($url_key, $position) {
		$sql = 'UPDATE '.$this->table.' SET position = "'.$position.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// FETCHING ADMIN ACCOUNT DETAILS
	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function get_position($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY position ASC ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_by_position ($field, $position) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE position = "'.$position.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}
}
?>