<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Appointment Data</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-forward text-primary"></i> <span>Action</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-price-tag2 text-primary"></i> <span>Appointment Nature</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-pencil5 text-primary"></i> <span>Disability</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-price-tag2 text-primary"></i> <span>Eligibility</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-price-tag2 text-primary"></i> <span>Employment Status</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-pencil5 text-primary"></i> <span>Ethnicity</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-wrench position-left"></i> Settings</li>
				<li class="active">Appointment Data</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<!-- Accordion with right control button -->
		<div class="panel-group panel-group-control panel-group-control-right content-group-lg" id="accordion-control-right">
			<div class="row">
				<div class="col-md-4">
					<!-- field office action -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group1">Field Office Action</a>
							</h6>
						</div>
						<div id="accordion-control-right-group1" class="panel-collapse collapse out">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="action_taken">Add Action</label>
										<input id="action_taken" name="action_taken" type="text" class="form-control input-xs" placeholder="Action Taken" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-forward"></i> 
										</div>
									</div>

									<div class="form-group has-feedback has-feedback-left">
										<label for="action_taken">Signing View </label>
										<select id="signing_status" name="signing_status" class="form-control input-xs">
											<option value="0">0 - Off viewing</option>
											<option value="1">1 - Available for viewing</option>
										</select>
										<div class="form-control-feedback">
											<i class="icon icon-eye"></i> 
										</div>
										<br>
										<small>(Status: <b>1</b> - for available for viewing at signing stage)</small>
										<br><br>
									</div>

									<button onclick="add_action()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add FO Action
									</button>

									<hr>

									<p style="text-align: center;"><b>List of Action Taken</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Action Type</th>
												<th style="text-align: center;">Signing Status</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_action = 1;
												if (is_array($get_action)) {
													foreach ($get_action as $list) {
														echo '
															<tr>
																<td>'.$num_action++.'</td>

																<td>
																	<a href="'.base_url('manage-action-details').'?action='.$list->url_key.'">
																		'.$list->action_taken.'
																	</a>
																</td>

																<td>'.$list->signing_status.'</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>

					<!-- type of eligibility -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group4">Type of Eligibility</a>
							</h6>
						</div>
						<div id="accordion-control-right-group4" class="panel-collapse collapse out">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="eligibility_type">Add Eligibility</label>
										<input id="eligibility_type" name="eligibility_type" type="text" class="form-control input-xs" placeholder="Type of Eligibility" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-forward"></i> 
										</div>
									</div>

									<button onclick="add_eligibility()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add Eligibility
									</button>

									<hr>

									<p style="text-align: center;"><b>Type of Eligibility List</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Eligibility Type</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_action = 1;
												if (is_array($fetch_eligibility)) {
													foreach ($fetch_eligibility as $list) {
														echo '
															<tr>
																<td>'.$num_action++.'</td>

																<td>
																	<a href="'.base_url('manage-eligibility-details').'?eligibility='.$list->url_key.'">
																		'.$list->eligibility_type.'
																	</a>
																</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-4">
					<!-- nature of appointment -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group2">Nature of Appointment</a>
							</h6>
						</div>
						<div id="accordion-control-right-group2" class="panel-collapse collapse">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="appointment_nature">Add Nature</label>
										<input id="appointment_nature" name="appointment_nature" type="text" class="form-control input-xs" placeholder="Nature of Appointment" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-price-tag2"></i> 
										</div>
									</div>

									<button onclick="add_nature()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add Nature
									</button>

									<hr>

									<p style="text-align: center;"><b>Nature of Appointment List</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Appointment Nature</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_nature = 1;
												if (is_array($fetch_appt_nature)) {
													foreach ($fetch_appt_nature as $list) {
														echo '
															<tr>
																<td>'.$num_nature++.'</td>

																<td>
																	<a href="'.base_url('manage-nature-details').'?nature='.$list->url_key.'">
																		'.$list->appointment_nature.'
																	</a>
																</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>

					<!-- employment status -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group5">Employment Status</a>
							</h6>
						</div>
						<div id="accordion-control-right-group5" class="panel-collapse collapse out">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="employment_status">Add Employment Status</label>
										<input id="employment_status" name="employment_status" type="text" class="form-control input-xs" placeholder="Type of Employment Status" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-forward"></i> 
										</div>
									</div>

									<button onclick="add_employment_status()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add Employment Status
									</button>

									<hr>

									<p style="text-align: center;"><b>List of Employment Status</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Employment Status</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_action = 1;
												if (is_array($fetch_employment_status)) {
													foreach ($fetch_employment_status as $list) {
														echo '
															<tr>
																<td>'.$num_action++.'</td>

																<td>
																	<a href="'.base_url('manage-employment-status-details').'?employment='.$list->url_key.'">
																		'.$list->employment_status.'
																	</a>
																</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>

				<div class="col-md-4">
					<!-- type of disability -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group3">Type of Disability</a>
							</h6>
						</div>
						<div id="accordion-control-right-group3" class="panel-collapse collapse">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="disability_type">Add Type of Disability</label>
										<input id="disability_type" name="disability_type" type="text" class="form-control input-xs" placeholder="Type of Disability" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i> 
										</div>
									</div>

									<button onclick="add_disability()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add Disability
									</button>

									<hr>

									<p style="text-align: center;"><b>Type of Disability List</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Disability Type</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_nature = 1;
												if (is_array($fetch_disability)) {
													foreach ($fetch_disability as $list) {
														echo '
															<tr>
																<td>'.$num_nature++.'</td>

																<td>
																	<a href="'.base_url('manage-disability-details').'?disability='.$list->url_key.'">
																		'.$list->disability_type.'
																	</a>
																</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>

					<!-- ethnicity -->
					<div class="panel panel-white">
						<div class="panel-heading">
							<h6 class="panel-title">
								<a class="collapsed" data-toggle="collapse" data-parent="#accordion-control-right" href="#accordion-control-right-group6">Etnicity</a>
							</h6>
						</div>
						<div id="accordion-control-right-group6" class="panel-collapse collapse">
							<div class="panel-body">
								<form method="post">
									<div class="form-group has-feedback has-feedback-left">
										<label for="ethnicity">Add Ethnicity</label>
										<input id="ethnicity" name="ethnicity" type="text" class="form-control input-xs" placeholder="Ethnicity" autocomplete="off">
										<div class="form-control-feedback">
											<i class="icon icon-pencil5"></i> 
										</div>
									</div>

									<button onclick="add_etnicity()" type="button" class="btn btn-primary btn-xs" style="width: 100%;">
										<i class="icon-plus-circle2 position-left"></i> Add Etnicity
									</button>

									<hr>

									<p style="text-align: center;"><b>List of Etnicity</b></p>
									<table class="table table-responsive">
										<thead>
											<tr>
												<th style="text-align: center;">#</th>
												<th style="text-align: center;">Etnicity</th>
											</tr>
										</thead>

										<tbody>
											<?php
												$num_ethnicity = 1;
												if (is_array($fetch_ethnicity)) {
													foreach ($fetch_ethnicity as $list) {
														echo '
															<tr>
																<td>'.$num_ethnicity++.'</td>

																<td>
																	<a href="'.base_url('manage-ethnicity-details').'?ethnicity='.$list->url_key.'">
																		'.$list->ethnicity.'
																	</a>
																</td>
															</tr>
														';
													}
												}

												else {
													echo '
														<tr>
															<td colspan="2">No data</td>
														</tr>
													';
												}
											?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /accordion with right control button -->
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->