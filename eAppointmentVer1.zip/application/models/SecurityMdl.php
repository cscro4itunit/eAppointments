<?php
class SecurityMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'security_tbl';
	}

	// CRUD
	public function add_question ($url_key, $security_question) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, security_question) VALUES("'.$url_key.'", "'.$security_question.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function delete_question($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_question($url_key, $security_question) {
		$sql = 'UPDATE '.$this->table.' SET security_question = "'.$security_question.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// FETCHING ADMIN ACCOUNT DETAILS
	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function get_security_question($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_by_question ($field, $security_question) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE security_question = "'.$security_question.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}
}
?>