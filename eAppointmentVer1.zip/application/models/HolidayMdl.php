<?php
class HolidayMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'holiday_tbl';
	}

	// crud
	public function add_holiday($url_key, $particular_date, $particular, $field_office, $date_description) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, particular_date, particular, field_office, date_description)
			VALUES("'.$url_key.'", "'.$particular_date.'", "'.$particular.'", "'.$field_office.'", "'.$date_description.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function delete_holiday($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_holiday($url_key, $particular, $field_office, $date_description) {
		$sql = 'UPDATE '.$this->table.' SET particular = "'.$particular.'", field_office = "'.$field_office.'", date_description = "'.$date_description.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching data
	public function fetch_holiday($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY particular_date ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_holiday_by_date_fo($field, $particular_date, $field_office) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE particular_date = "'.$particular_date.'" AND field_office = "'.$field_office.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	// counting
	public function count_between_assigned_holiday($field_office, $date_received, $temp_due_date) {
		$sql = 'SELECT * FROM '.$this->table.' WHERE particular_date BETWEEN "'.$date_received.'" AND "'.$temp_due_date.'" AND field_office = "'.$field_office.'" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	public function count_between_holiday($field_office, $date_received, $temp_due_date) {
		$sql = 'SELECT * FROM '.$this->table.' WHERE particular_date BETWEEN "'.$date_received.'" AND "'.$temp_due_date.'" AND field_office = "National" ';
		$query = $this->db->query($sql);
        return $query->num_rows();
	}

	
}
?>