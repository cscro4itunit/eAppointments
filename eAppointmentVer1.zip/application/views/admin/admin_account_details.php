<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Admin Account Details</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-user text-primary"></i> <span>Admin Account</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li>Admin Account</li>
				<li class="active">Account details</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">&nbsp;</div>

			<div class="col-md-4">
				<!-- User Details -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-vcard"></i> Admin Account details</b><br>
							<small>Update or activate/deactivate account.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<center><p><b>Account Information</b></p></center>

						<p>
							<center>
								<img src="<?=base_url().'assets/images/user/'?><?=$user_details['image']?>" class="img img-responsive img-circle" style="border:1px solid #000;width: 150px; height: 150px;">
							</center>
							<br>
							<b>Name</b>: <?=$user_details['fn']?>&nbsp;<?=$user_details['mi']?>&nbsp;<?=$user_details['ln']?><br>
							<b>Position</b>: <?=$user_details['position']?><br>
							<b>Gender</b>: <?=$user_details['gender']?><br>
							<b>Contact#</b>: <?=$user_details['contact']?><br>
							<b>Email Address</b>: <?=$user_details['email_add']?><br>
							<b>Created on</b>: <?=$user_details['created_on']?>
						</p>

						<br>

						<a href="<?=base_url('admin-account-update').'?user='.$user_details['url_key']?>" class="btn btn-success btn-xs pull-left">
							<i class="icon-pencil5 position-left"></i> EDIT ACCOUNT
						</a>

						<?php
							$active_status = $user_details['active_status'];

							if ($active_status == 0) {
								echo '
									<a href="'.base_url('admin-account-status').'?user='.$user_details['url_key'].'" class="btn btn-success btn-xs pull-right">
										<i class="icon-user-check position-left"></i> ACTIVATE ACCOUNT
									</a>
								';
							}

							else {
								echo '
									<a href="'.base_url('admin-account-status').'?user='.$user_details['url_key'].'" class="btn btn-danger btn-xs pull-right">
										<i class="icon-user-block position-left"></i> DEACTIVATE ACCOUNT
									</a>
								';
							}
						?>
					</div>
				</div>
				<!-- User Details -->
			</div>

			<div class="col-md-4">&nbsp;</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->