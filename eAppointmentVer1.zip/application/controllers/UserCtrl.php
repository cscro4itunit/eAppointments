<?php
defined('BASEPATH') OR exit('No direct script access allowed');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

class UserCtrl extends CI_Controller {
	private $data;

	public function __construct() {
		parent:: __construct();
		// set internet timezone
		date_default_timezone_set('Asia/Manila');
		
		// including all models
		include 'includes/models.php';

		// callout session that was set after login
		$this->accnt_id = $this->session->userdata('session_id');

		// select * details of user
		$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

		if ($this->data['user_id_details'] > 0) {
			include 'includes/appt_extension.php';

			if (!isset($this->accnt_id)) {
				redirect(base_url(''));
			}

			else {
				$this->data['user_id_details'] = $this->AccntMdl->user_id_details('*', $this->accnt_id);

				switch ($this->data['user_id_details']['role']) {
					case '0':
						redirect(base_url('error-404'));
						break;
					
					case '1':
						base_url('dashboard');
						break;

					default:
						redirect(base_url('cscro4/user/login'));
						break;
				}
			}
		}

		else {
			redirect(base_url(''));
		}
	}

	// NAVIGATION
	public function dashboard() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'dashboard',
			'jscript' => 'user',
			'fetch_fo_users' => $this->AccntMdl->fetch_fo_users('id, fn, ln, field_office', $this->data['user_id_details']['field_office']),
			'fetch_fo_signing_officer' => $this->AccntMdl->fetch_fo_signing_officer('id, fn, ln, field_office', $this->data['user_id_details']['field_office'], 'Signing Officer'),
			'get_db_table' => $this->data['db_table'],
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
			'activated_year' => $this->data['activated_year'],
			// pending from last year
			'count_received_last_year' => $this->data['count_received_last_year'],
			// count active year
			'count_received_total_active_year' => $this->data['count_received_total_active_year'],
			'count_signed_active_year' => $this->data['count_signed_active_year'],
			'count_pending_active_year' => $this->data['count_pending_active_year'],
			'count_acted_active_year' => $this->data['count_acted_active_year'],
			// count official
			'count_user_per_fo' => $this->data['count_user_per_fo'],
			'count_processor' => $this->data['count_processor'],
			'count_signing_officer' => $this->data['count_signing_officer'],
			// count received per month active year
			'count_jan_received_active_year' => $this->data['count_jan_received_active_year'],
			'count_feb_received_active_year' => $this->data['count_feb_received_active_year'],
			'count_mar_received_active_year' => $this->data['count_mar_received_active_year'],
			'count_apr_received_active_year' => $this->data['count_apr_received_active_year'],
			'count_may_received_active_year' => $this->data['count_may_received_active_year'],
			'count_june_received_active_year' => $this->data['count_june_received_active_year'],
			'count_july_received_active_year' => $this->data['count_july_received_active_year'],
			'count_aug_received_active_year' => $this->data['count_aug_received_active_year'],
			'count_sept_received_active_year' => $this->data['count_sept_received_active_year'],
			'count_oct_received_active_year' => $this->data['count_oct_received_active_year'],
			'count_nov_received_active_year' => $this->data['count_nov_received_active_year'],
			'count_dec_received_active_year' => $this->data['count_dec_received_active_year'],
			// count total signed per month active year
			'count_jan_signed_active_year' => $this->data['count_jan_signed_active_year'],
			'count_feb_signed_active_year' => $this->data['count_feb_signed_active_year'],
			'count_mar_signed_active_year' => $this->data['count_mar_signed_active_year'],
			'count_apr_signed_active_year' => $this->data['count_apr_signed_active_year'],
			'count_may_signed_active_year' => $this->data['count_may_signed_active_year'],
			'count_june_signed_active_year' => $this->data['count_june_signed_active_year'],
			'count_july_signed_active_year' => $this->data['count_july_signed_active_year'],
			'count_aug_signed_active_year' => $this->data['count_aug_signed_active_year'],
			'count_sept_signed_active_year' => $this->data['count_sept_signed_active_year'],
			'count_oct_signed_active_year' => $this->data['count_oct_signed_active_year'],
			'count_nov_signed_active_year' => $this->data['count_nov_signed_active_year'],
			'count_dec_signed_active_year' => $this->data['count_dec_signed_active_year'],
			// count within processed appointment
			'count_within_jan' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '20'),
			'count_within40_jan' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '40'),
			'count_duedate_jan' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '20'),
			'count_duedate40_jan' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '1', '40'),
			'count_within_feb' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '20'),
			'count_within40_feb' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '40'),
			'count_duedate_feb' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '20'),
			'count_duedate40_feb' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '2', '40'),
			'count_within_mar' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '20'),
			'count_within40_mar' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '40'),
			'count_duedate_mar' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '20'),
			'count_duedate40_mar' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '3', '40'),
			'count_within_apr' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '20'),
			'count_within40_apr' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '40'),
			'count_duedate_apr' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '20'),
			'count_duedate40_apr' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '4', '40'),
			'count_within_may' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '20'),
			'count_within40_may' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '40'),
			'count_duedate_may' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '20'),
			'count_duedate40_may' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '5', '40'),
			'count_within_june' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '20'),
			'count_within40_june' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '40'),
			'count_duedate_june' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '20'),
			'count_duedate40_june' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '6', '40'),
			'count_within_july' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '20'),
			'count_within40_july' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '40'),
			'count_duedate_july' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '20'),
			'count_duedate40_july' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '7', '40'),
			'count_within_aug' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '20'),
			'count_within40_aug' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '40'),
			'count_duedate_aug' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '20'),
			'count_duedate40_aug' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '8', '40'),
			'count_within_sept' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '20'),
			'count_within40_sept' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '40'),
			'count_duedate_sept' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '20'),
			'count_duedate40_sept' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '9', '40'),
			'count_within_oct' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '20'),
			'count_within40_oct' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '40'),
			'count_duedate_oct' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '20'),
			'count_duedate40_oct' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '10', '40'),
			'count_within_nov' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '20'),
			'count_within40_nov' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '40'),
			'count_duedate_nov' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '20'),
			'count_duedate40_nov' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '11', '40'),
			'count_within_dec' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '20'),
			'count_within40_dec' => $this->AppointmentMdl->count_within_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '40'),
			'count_duedate_dec' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '20'),
			'count_duedate40_dec' => $this->AppointmentMdl->count_duedate_acted($this->data['db_table'], 'id, date_signed, due_date', $this->data['activated_year'], '12', '40'),
			// count processed per month active year
			'count_acted_active_year_per_month_jan' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '1'),
			'count_acted_active_year_per_month_feb' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '2'),
			'count_acted_active_year_per_month_mar' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '3'),
			'count_acted_active_year_per_month_apr' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '4'),
			'count_acted_active_year_per_month_may' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '5'),
			'count_acted_active_year_per_month_june' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '6'),
			'count_acted_active_year_per_month_july' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '7'),
			'count_acted_active_year_per_month_aug' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '8'),
			'count_acted_active_year_per_month_sept' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '9'),
			'count_acted_active_year_per_month_oct' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '10'),
			'count_acted_active_year_per_month_nov' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '11'),
			'count_acted_active_year_per_month_dec' => $this->AppointmentMdl->count_acted_active_year_per_month($this->data['db_table'], 'id, date_received, date_acted, appointment_status', $this->data['activated_year'], '12'),
		);

		// build array for processed appointment
		$build_array = array();
		foreach ($this->data['fetch_fo_users'] as $row) {
			$processed[] = array(
				'count_processor' => $row,
				// count processed appointment by fo
				'count_jan_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '1', $row->id),
				'count_feb_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '2', $row->id),
				'count_mar_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '3', $row->id),
				'count_apr_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '4', $row->id),
		        'count_may_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '5', $row->id),
		        'count_june_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '6', $row->id),
		        'count_july_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '7', $row->id),
		        'count_aug_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '8', $row->id),
		        'count_sept_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '9', $row->id),
		        'count_oct_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '10', $row->id),
		        'count_nov_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '11', $row->id),
		        'count_dec_processed_by_fo_active_year' => $this->AppointmentMdl->count_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '12', $row->id),
		        'count_total_processed' => $this->AppointmentMdl->count_total_processed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], $row->id),
		        'count_total_processed_by_fo' => $this->AppointmentMdl->count_total_processed_by_fo($this->data['get_db_table'], 'id, processor', $row->id),
	        );
		}

		foreach ($this->data['fetch_fo_signing_officer'] as $row_signed) {
			$signed[] = array(
				'count_signed' => $row_signed,
				// count processed appointment by fo
				'count_jan_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '1', $row_signed->id),
				'count_feb_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '2', $row_signed->id),
				'count_mar_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '3', $row_signed->id),
				'count_apr_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '4', $row_signed->id),
		        'count_may_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '5', $row_signed->id),
		        'count_june_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '6', $row_signed->id),
		        'count_july_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '7', $row_signed->id),
		        'count_aug_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '8', $row_signed->id),
		        'count_sept_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '9', $row_signed->id),
		        'count_oct_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '10', $row_signed->id),
		        'count_nov_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '11', $row_signed->id),
		        'count_dec_signed_by_fo_active_year' => $this->AppointmentMdl->count_signed_by_fo_active_year($this->data['get_db_table'], 'id, processor', $this->data['activated_year'], '12', $row_signed->id),
		        'count_total_signed' => $this->AppointmentMdl->count_total_signed_by_fo_active_year($this->data['get_db_table'], 'id, signing_official', $this->data['activated_year'], $row_signed->id),
		        'count_total_signed_by_fo' => $this->AppointmentMdl->count_total_signed_by_fo($this->data['get_db_table'], 'id, signing_official', $row_signed->id),
	        );
		}

		$this->data['build_array'] = $processed;
		$this->data['build_array_signed'] = $signed;

		// print_r($this->data['build_array']);

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/dashboard', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	public function my_profile() {
		$this->data = array(
			'showinfo' => $this->WebinfoMdl->show_webinfo(),
			'user_details' => $this->data['user_id_details'],
			'nav' => 'my_profile',
			'jscript' => 'user',
			'position' => $this->PositionMdl->get_position('*'),
			'security_questions' => $this->SecurityMdl->get_security_question('*'),
			// count
			'count_received_total' => $this->data['count_received_total'],
			'count_pending' => $this->data['count_pending'],
			'count_acted' => $this->data['count_acted'],
			'count_signed' => $this->data['count_signed'],
			'activated_year' => $this->data['activated_year'],
		);

		$this->load->view('field_office/includes/header', $this->data);
		$this->load->view('field_office/user_account', $this->data);
		$this->load->view('field_office/includes/footer', $this->data);
	}

	// FUNCTION
	public function user_logout() {
		$this->user_id_details = $this->session->unset_userdata('session_id');
		session_destroy();
		redirect(base_url('cscro4/user/login'));
	}

	public function imageUpload($path,$filename) {
		$config['upload_path']          = $path;
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['file_name']            = $filename;
	    $this->load->library('upload');
	    return $this->upload->initialize($config);
	}

	public function UpdateUserAccount() {
		if ($_POST['action'] == 'submit') {
			$fn = $this->input->post('fn');
			$mi = $this->input->post('mi');
			$ln = $this->input->post('ln');
			$gender = $this->input->post('gender');
			$contact = $this->input->post('contact');
			$email_add = $this->input->post('email_add');
			$position = $this->input->post('position');

			$user_id = $this->data['user_id_details']['id'];

			// update personal info
			$update_fo_personal_info = $this->AccntMdl->update_fo_personal_info($user_id, $fn, $mi, $ln, $gender, $contact, $email_add, $position);

			if ($update_fo_personal_info) {
				$title = 'Account Updated!';
				$status = 'success';
				$message = 'Active Status updated.';
				$url = '';
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}
			
			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateSecurity() {
		if ($_POST['action'] == 'submit') {
			$security_question = $this->input->post('security_question');
			$security_answer = $this->input->post('security_answer');

			$user_id = $this->data['user_id_details']['id'];

			// update user security
			$update_fo_security = $this->AccntMdl->update_fo_security($user_id, $security_question, $security_answer);

			if ($update_fo_security) {
				$title = 'Security Updated!';
				$status = 'success';
				$message = 'Please remember this credential.';
				$url = '';
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}
			
			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateUsername() {
		if ($_POST['action'] == 'submit') {
			$username = $this->input->post('new_username');

			$user_id = $this->data['user_id_details']['id'];

			// check username is existed
			$validate = $this->AccntMdl->username_auth('*', $username);

			if ($validate) {
				$title = 'Select another username!';
				$status = 'warning';
				$message = 'Username already used.';
				$url = '';
			}

			else {
				// update username
				$update_fo_username = $this->AccntMdl->update_fo_username($user_id, $username);

				if ($update_fo_username) {
					$title = 'Updated!';
					$status = 'success';
					$message = 'Successfully updated your username. Please login again.';
					$url = base_url('user_logout');
				}

				else {
					$title = 'Unabled!';
					$status = 'error';
					$message = 'Please try again.';
					$url = '';
				}
			}
			
			// pass ajax request / please see data thru devtools
				echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdatePassword() {
		if ($_POST['action'] == 'submit') {
			$password = $this->input->post('new_password');
			$hash_pass = password_hash($password, PASSWORD_DEFAULT);

			$user_id = $this->data['user_id_details']['id'];

			// update user security
			$update_fo_password = $this->AccntMdl->update_fo_password($user_id, $hash_pass);

			if ($update_fo_password) {
				$title = 'Updated!';
				$status = 'success';
				$message = 'Successfully updated your password. Please login again.';
					$url = base_url('user_logout');
			}

			else {
				$title = 'Unabled!';
				$status = 'error';
				$message = 'Please try again.';
				$url = '';
			}
			
			// pass ajax request / please see data thru devtools
			echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
		}
	}

	public function UpdateProfileImage() {
		$user_id = $this->data['user_id_details']['id'];

		$path = './assets/images/user';
		$filename = date('ymdhis');
		
		$this->imageUpload($path, $filename);

		if (!$this->upload->do_upload('image')) {
			$title = 'Unabled';
			$status = 'error';
			$message = 'Unable to upload image type.';
			$url = '';
		}

		else {
			$image = $this->upload->data();
			$realname = $filename.$image['file_ext'];

			$result = $this->AccntMdl->update_fo_image($user_id, $realname);

			if ($result) {
				$title = 'Success';
				$status = 'success';
				$message = 'Updated User Image.';
				$url = '';
			}
			
			else {
				$title = 'Unabled';
				$status = 'warning';
				$message = 'Unable to upload user image.';
				$url = '';
			}
		}

		// pass ajax request / please see data thru devtools
		echo json_encode(array('title' => $title, 'status' => $status, 'url' => $url, 'message' => $message));
	}
}