<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Admin Account</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-user text-primary"></i> <span>Admin Account</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li class="active">Admin Account</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-3">
				<!-- Create Admin -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-user-plus"></i> Create Admin Account</b><br>
							<small>Please fillout all the field/s.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<form method="post">
							<div class="form-group has-feedback has-feedback-left">
								<select class="form-control input-xs" id="position" name="position">
									<option value="">- Select Position -</option>
									<?php
										if (is_array($position)) {
											foreach ($position as $list) {
												echo '
													<option value="'.$list->position.'">'.$list->position.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-user-tie"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<select class="form-control input-xs" id="gender" name="gender">
									<option value="">- Select Gender -</option>
									<option value="male">Male</option>
									<option value="female">Female</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-man-woman"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="fn" name="fn" type="text" class="form-control input-xs" placeholder="Firstname" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="mi" name="mi" type="text" class="form-control input-xs" placeholder="Middle Initial (Optional)" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="ln" name="ln" type="text" class="form-control input-xs" placeholder="Lastname" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="contact" name="contact" type="text" class="form-control input-xs" placeholder="Cel/Tel#" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-phone2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="email_add" name="email_add" type="email" class="form-control input-xs" placeholder="Email (gmail/yahoo)" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-envelop"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<input id="username" name="username" type="text" class="form-control input-xs" placeholder="Username" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user-check"></i>
								</div>
							</div>

							<small><p>
								<b>NOTE:</b><br>
								<b>*</b> User default password is <i>123456</i>.<br>
								<b>*</b> Please update user security after this transaction.
							</p></small>

							<button id="btn_add_dataEntry" type="button" class="btn btn-primary btn-xs pull-right" onclick="create_admin_account()">
								<i class="icon-plus-circle2 position-left"></i> CREATE ACCOUNT
							</button>
						</form>
					</div>
				</div>
				<!-- Create User -->
			</div>

			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> Admin account list</b><br>
							<small>Manage admin account information.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
							<thead>
								<tr>
									<th>User</th>
									<th>Fullname</th>
									<th>Email Address</th>
									<th>Contact #</th>
									<th>Status</th>
									<th>Created on</th>
								</tr>
							</thead>

							<tbody>
								<?php
									if (is_array($fetch_admin)) {
										foreach ($fetch_admin as $list) {
											if ($list->active_status == 1) {
												$active_status = '<span class="label label-success">Active</span>';
											} else {
												$active_status = '<span class="label label-danger">Deactivated</span>';
											}

											echo '
												<tr>
													<td>
														<a href="'.base_url('admin-account-details').'?user='.$list->url_key.'">
															'.$list->username.'
														</a>
													</td>

													<td valign="center">
														<img src="'.base_url().'assets/images/user/'.$list->image.' " alt="" class="img img-responsive img-circle pull-left" style="width:50px;height:50px">
														<b style="padding-left:10px;">'.$list->fn.' '.$list->ln.'</b>
														<br><small style="padding-left:10px;">'.$list->position.'</small>
													</td>

													<td>'.$list->email_add.'</td>
													<td>'.$list->contact.'</td>
													<td>'.$active_status.'</td>
													<td>'.$list->created_on.'</td>
												</tr>
											';
										}
									}

									else {
										echo '
											<tr>
												<td colspan="5">No data</td>
											</tr>
										';
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->