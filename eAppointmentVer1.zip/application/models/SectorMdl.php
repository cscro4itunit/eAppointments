<?php
class SectorMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'sector_tbl';
	}

	// crud

	// modify
	public function fetch_sector($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY sector ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}
}
?>