<div class="row">
	<div class="col-md-4">
		<div class="panel panel-body bg-danger-400 has-bg-image">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin"><?=$count_pending?></h3>
					<span class="text-uppercase text-size-mini">total pending</span>
				</div>

				<div class="media-right media-middle">
					<i class="icon-database-time2 icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-4">
		<div class="panel panel-body bg-primary-400 has-bg-image">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin"><?=$count_acted?></h3>
					<span class="text-uppercase text-size-mini">total acted</span>
				</div>

				<div class="media-right media-middle">
					<i class="icon-database-check icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>

	<div class="col-md-4">
		<div class="panel panel-body bg-success-400 has-bg-image">
			<div class="media no-margin">
				<div class="media-body">
					<h3 class="no-margin"><?=$count_signed?></h3>
					<span class="text-uppercase text-size-mini">total signed</span>
				</div>

				<div class="media-right media-middle">
					<i class="icon-database-edit2 icon-3x opacity-75"></i>
				</div>
			</div>
		</div>
	</div>
</div>
