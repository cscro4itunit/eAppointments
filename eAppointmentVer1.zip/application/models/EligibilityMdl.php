<?php
class EligibilityMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'eligibility_tbl';
	}

	// crud
	public function add_eligibility($url_key, $eligibility_type) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, eligibility_type)
			VALUES("'.$url_key.'", "'.$eligibility_type.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_eligibility($url_key, $eligibility_type) {
		$sql = 'UPDATE '.$this->table.' SET eligibility_type = "'.$eligibility_type.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_eligibility($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function fetch_eligibility($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY eligibility_type ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_eligibility_type($field, $eligibility_type) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE eligibility_type = "'.$eligibility_type.'" ORDER BY eligibility_type ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>