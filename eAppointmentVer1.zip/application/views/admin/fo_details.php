<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Field Office Details</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-office text-primary"></i> <span>Field Office</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li>Field Office</li>
				<li class="active">FO Details</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-4">&nbsp;</div>

			<div class="col-md-4">
				<!-- User Details -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-pencil5"></i> Field office details</b><br>
							<small>Update information.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<center><p><b>Field Office Information</b></p></center>

						<p>
							<b>Field Office</b>: <?=$fo_details['field_office']?><br>
							<b>Director</b>: <?=$fo_details['director']?><br>
							<b>Contact</b>: <?=$fo_details['contact']?><br>
							<b>Email Address</b>: <?=$fo_details['email_add']?><br>
							<b>Office Address</b>: <?=$fo_details['office_address']?><br>
							<b>Created On</b>: <?=$fo_details['created_on']?>
						</p>

						<br>

						<a href="<?=base_url('field-office-update').'?fo='.$fo_details['fo_tag']?>" class="btn btn-success btn-xs pull-right">
							<i class="icon-pencil5 position-left"></i> Edit Field Office
						</a>
					</div>
				</div>
				<!-- User Details -->
			</div>

			<div class="col-md-4">&nbsp;</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->