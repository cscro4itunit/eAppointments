<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// ADMINISTRATOR
$route['administrator'] = 'AdminCtrl/fo_appointments';
$route['admin_logout'] = 'AdminCtrl/admin_logout';
$route['manage-user-account'] = 'AdminCtrl/manage_user';
$route['AddUserAccount'] = 'AdminCtrl/AddUserAccount';
$route['user-account-details'] = 'AdminCtrl/user_account_details';
$route['user-account-status'] = 'AdminCtrl/user_account_status';
$route['AdminUpdateAccountStatus'] = 'AdminCtrl/AdminUpdateAccountStatus';
$route['user-account-update'] = 'AdminCtrl/user_account_update';
$route['AdminUpdateUsername'] = 'AdminCtrl/AdminUpdateUsername';
$route['AdminUpdatePassword'] = 'AdminCtrl/AdminUpdatePassword';
$route['AdminUpdatePersonalInfo'] = 'AdminCtrl/AdminUpdatePersonalInfo';
$route['AdminUpdateSecurity'] = 'AdminCtrl/AdminUpdateSecurity';
$route['UpdateUserImage'] = 'AdminCtrl/UpdateUserImage';
$route['manage-field-office'] = 'AdminCtrl/manage_fo';
$route['AddFieldOffice'] = 'AdminCtrl/AddFieldOffice';
$route['field-office-details'] = 'AdminCtrl/field_office_details';
$route['field-office-update'] = 'AdminCtrl/field_office_update';
$route['UpdateFieldOffice'] = 'AdminCtrl/UpdateFieldOffice';
$route['manage-system-information'] = 'AdminCtrl/manage_system_information';
$route['AddPosition'] = 'AdminCtrl/AddPosition';
$route['position-details'] = 'AdminCtrl/position_details';
$route['DeletePosition'] = 'AdminCtrl/DeletePosition';
$route['UpdatePosition'] = 'AdminCtrl/UpdatePosition';
$route['question-details'] = 'AdminCtrl/question_details';
$route['AddQuestion'] = 'AdminCtrl/AddQuestion';
$route['DeleteQuestion'] = 'AdminCtrl/DeleteQuestion';
$route['UpdateQuestion'] = 'AdminCtrl/UpdateQuestion';
$route['UpdateIcon'] = 'AdminCtrl/UpdateIcon';
$route['UpdateWebInfo'] = 'AdminCtrl/UpdateWebInfo';
$route['manage-admin-account'] = 'AdminCtrl/manage_admin';
$route['AddAdminAccount'] = 'AdminCtrl/AddAdminAccount';
$route['admin-account-details'] = 'AdminCtrl/admin_account_details';
$route['admin-account-status'] = 'AdminCtrl/admin_account_status';
$route['admin-account-update'] = 'AdminCtrl/admin_account_update';
$route['manage-holidays'] = 'AdminCtrl/manage_holidays';
$route['manage-holidays-details'] = 'AdminCtrl/manage_holidays_details';
$route['AddHoliday'] = 'AdminCtrl/AddHoliday';
$route['manage-holidays-details'] = 'AdminCtrl/manage_holidays_details';
$route['DeleteHoliday'] = 'AdminCtrl/DeleteHoliday';
$route['UpdateHoliday'] = 'AdminCtrl/UpdateHoliday';
$route['manage-agency'] = 'AdminCtrl/manage_agency';
$route['AddAgency'] = 'AdminCtrl/AddAgency';
$route['manage-agency-details'] = 'AdminCtrl/manage_agency_details';
$route['UpdateAgency'] = 'AdminCtrl/UpdateAgency';
$route['DeleteAgency'] = 'AdminCtrl/DeleteAgency';
$route['manage-appointment-data'] = 'AdminCtrl/manage_appointment_data';
$route['AddAction'] = 'AdminCtrl/AddAction';
$route['manage-action-details'] = 'AdminCtrl/manage_action_details';
$route['UpdateAction'] = 'AdminCtrl/UpdateAction';
$route['DeleteAction'] = 'AdminCtrl/DeleteAction';
$route['AddNature'] = 'AdminCtrl/AddNature';
$route['manage-nature-details'] = 'AdminCtrl/manage_nature_details';
$route['UpdateNature'] = 'AdminCtrl/UpdateNature';
$route['DeleteNature'] = 'AdminCtrl/DeleteNature';
$route['AddDisability'] = 'AdminCtrl/AddDisability';
$route['manage-disability-details'] = 'AdminCtrl/manage_disability_details';
$route['UpdateDisability'] = 'AdminCtrl/UpdateDisability';
$route['DeleteDisability'] = 'AdminCtrl/DeleteDisability';
$route['AddEligibility'] = 'AdminCtrl/AddEligibility';
$route['manage-eligibility-details'] = 'AdminCtrl/manage_eligibility_details';
$route['UpdateEligibility'] = 'AdminCtrl/UpdateEligibility';
$route['DeleteEligibility'] = 'AdminCtrl/DeleteEligibility';
$route['AddEmploymentStatus'] = 'AdminCtrl/AddEmploymentStatus';
$route['manage-employment-status-details'] = 'AdminCtrl/manage_employment_status_details';
$route['UpdateEmploymentStatus'] = 'AdminCtrl/UpdateEmploymentStatus';
$route['DeleteEmploymentStatus'] = 'AdminCtrl/DeleteEmploymentStatus';
$route['AddEthnicity'] = 'AdminCtrl/AddEthnicity';
$route['manage-ethnicity-details'] = 'AdminCtrl/manage_ethnicity_details';
$route['UpdateEthnicity'] = 'AdminCtrl/UpdateEthnicity';
$route['DeleteEthnicity'] = 'AdminCtrl/DeleteEthnicity';
$route['AddActiveYear'] = 'AdminCtrl/AddActiveYear';
$route['year-details'] = 'AdminCtrl/year_details';
$route['DeleteYear'] = 'AdminCtrl/DeleteYear';
$route['SetActiveYear'] = 'AdminCtrl/SetActiveYear';
$route['DeactiveYear'] = 'AdminCtrl/DeactiveYear';
// $route['field-office-appointments'] = 'AdminCtrl/fo_appointments';
$route['field-office-appointment-details'] = 'AdminCtrl/fo_appointment_details';
$route['field-office-appointment-update'] = 'AdminCtrl/fo_appointment_update';
$route['UpdateAppointment'] = 'AdminCtrl/UpdateAppointment';
$route['LoadAdminProcessor'] = 'AdminCtrl/loadProcessor';

// USER/FIELD OFFICE
$route['dashboard'] = 'UserCtrl/dashboard';
$route['user_logout'] = 'UserCtrl/user_logout';
$route['my-profile'] = 'UserCtrl/my_profile';
$route['UpdateUserAccount'] = 'UserCtrl/UpdateUserAccount';
$route['UpdateSecurity'] = 'UserCtrl/UpdateSecurity';
$route['UpdateUsername'] = 'UserCtrl/UpdateUsername';
$route['UpdatePassword'] = 'UserCtrl/UpdatePassword';
$route['UpdateProfileImage'] = 'UserCtrl/UpdateProfileImage';



// appintments processing
$route['appontments'] = 'ApptProcessCtrl/appointment';
$route['appontments-processing'] = 'ApptProcessCtrl/appointment_process';
$route['AddAppointment'] = 'ApptProcessCtrl/AddAppointment';
$route['appontments-processing-pending'] = 'ApptProcessCtrl/appontments_processing_pending';
$route['appontments-processing-pending-update'] = 'ApptProcessCtrl/appontments_processing_pending_update';
$route['ActionTaken'] = 'ApptProcessCtrl/ActionTaken';
$route['appontments-processing-acted'] = 'ApptProcessCtrl/appontments_processing_acted';
$route['appontments-processing-acted-update'] = 'ApptProcessCtrl/appontments_processing_acted_update';
$route['ActionTakenOfficial'] = 'ApptProcessCtrl/ActionTakenOfficial';
$route['appontments-processing-signed'] = 'ApptProcessCtrl/appontments_processing_signed';
$route['appontments-processing-signed-details'] = 'ApptProcessCtrl/appontments_processing_signed_details';
$route['CheckDateReceived'] = 'ApptProcessCtrl/CheckDateReceived';
$route['appontments-data'] = 'ApptProcessCtrl/appontments_data';
$route['ReleasedAppointment'] = 'ApptProcessCtrl/ReleasedAppointment';


// Tracking
$route['CheckCode'] = 'GuestCtrl/CheckCode';
$route['track-my-appointment'] = 'GuestCtrl/track_my_appointment';

// LOGIN
$route['cscro4/admin/login'] = 'LoginCtrl/admin_login';
$route['AdminAuth'] = 'LoginCtrl/AdminAuth';
$route['cscro4/user/login'] = 'LoginCtrl/user_login';
$route['UserAuth'] = 'LoginCtrl/UserAuth';

// LANDING PAGE
$route['error-404'] = 'GeneralCtrl/error_404';
$route['default_controller'] = 'GuestCtrl';
$route['404_override'] = 'GeneralCtrl/error_404';
$route['translate_uri_dashes'] = FALSE;