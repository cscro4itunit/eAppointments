<?php
class FoMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'fo_tbl';
	}

	// CRUD
	public function add_field_office ($fo_tag, $field_office, $director, $contact, $email_add, $office_address) {
		$sql = 'INSERT INTO '.$this->table.'(fo_tag, field_office, director, contact, email_add, office_address)
			VALUES("'.$fo_tag.'", "'.$field_office.'", "'.$director.'", "'.$contact.'", "'.$email_add.'", "'.$office_address.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_field_office ($get_url, $field_office, $director, $contact, $email_add, $office_address) {
		$sql = 'UPDATE '.$this->table.' SET field_office = "'.$field_office.'", director = "'.$director.'", contact = "'.$contact.'", email_add = "'.$email_add.'", office_address = "'.$office_address.'" WHERE fo_tag = "'.$get_url.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	// FETCHING ADMIN ACCOUNT DETAILS
	public function get_fo($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY division_of ASC ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_by_fo_tag ($field, $fo_tag) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE fo_tag = "'.$fo_tag.'" ';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $fo_tag) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE fo_tag = "'.$fo_tag.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function fetch_fo_division_of($field, $division_of) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE division_of = "'.$division_of.'" ';
		$query = $this->db->query($sql);
	 	return $query->num_rows() > 0 ? $query->result() : '';
	}
}
?>