<?php
class EthnicityMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'ethnicity_tbl';
	}

	// crud
	public function add_ethnicity($url_key, $ethnicity) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, ethnicity)
			VALUES("'.$url_key.'", "'.$ethnicity.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_ethnicity($url_key, $ethnicity) {
		$sql = 'UPDATE '.$this->table.' SET ethnicity = "'.$ethnicity.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_ethnicity($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function fetch_ethnicity($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY ethnicity ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_ethnicity_type($field, $ethnicity) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE ethnicity = "'.$ethnicity.'" ORDER BY ethnicity ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>