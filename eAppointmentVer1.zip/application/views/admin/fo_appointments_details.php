<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Main</span> - Appointments Details</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-stack3 text-primary"></i> <span>Appointments</span>
					</a>

					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-office text-primary"></i> <span>Field Office</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-stack3 position-left"></i> Main</li>
				<li>Appointments</li>
				<li class="active">Field Office</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-3">
				<h6 class="panel-title">
					<b><i class="icon-office"></i> <?=$fo_details['field_office']?></b><br>
					<small>Information and Details</small>
				</h6>

				<br>

				<!-- Tickets stats colored -->
			<div class="panel text-center bg-primary-400 has-bg-image">
					<div class="panel-body">
						<h6 class="text-semibold no-margin-bottom mt-5">Statistics Percentage</h6>
						<div class="opacity-75 content-group">Acted over Received</div>
						<div class="svg-center position-relative mb-5" id="progress_percentage_three"></div>
					</div>

					<div class="panel-body panel-body-accent pb-15">
						<div class="row">
							<div class="col-xs-4">
								<div class="text-uppercase text-size-mini text-muted">RECEIVED</div>
								<h5 class="text-semibold no-margin"><?=$count_received_total?></h5>
							</div>

							<div class="col-xs-4">
								<div class="text-uppercase text-size-mini text-muted">ACTED</div>
								<h5 class="text-semibold no-margin"><?=$count_signed?></h5>
							</div>

							<div class="col-xs-4">
								<div class="text-uppercase text-size-mini text-muted">PENDING</div>
								<h5 class="text-semibold no-margin"><?=$fo_total_pending = $count_received_total - $count_signed?></h5>
							</div>
						</div>
					</div>
				</div>
				<!-- /tickets stats colored -->

				<button type="button" class="btn btn-danger btn-lg" data-toggle="modal" data-target="#<?=$fo_details['fo_tag']?>-statistics" style="width:100%;">
					<i class="icon-stats-bars2"></i> Statistics<br>
					<small style="font-size:11px;color:#000;">Appointment Process</small>
				</button>
			</div>

			<div class="col-md-9">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-list-unordered"></i> List of Received Appointments</b><br>
							<small>Received - Acted - Signed</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<table class="table datatable-button-print-columns">
							<thead>
								<tr>
									<th>ID</th>
									<th>Date Received</th>
									<th>Agency Name</th>
									<th>Appointee</th>
									<th>Position Title</th>
									<th>Due Date</th>
									<th>Status</th>
								</tr>
							</thead>

							<tbody>
								<?php
									if (is_array($appt_list)) {
										foreach ($appt_list as $list) {
											echo '
												<tr>
													<td>
														<a href="'.base_url('field-office-appointment-update').'?fo='.$fo_details['fo_tag'].'&&id='.$list->url_key.' ">
															'.$list->unique_id_number.'
														</a>
													</td>
													<td>'.$list->date_received.'</td>
													<td>'.$list->agency_name.'</td>
													<td>'.$list->appointee.'</td>
													<td>'.$list->position_title.'</td>
													<td>'.$list->due_date.'</td>
													<td>'.$list->appointment_status.'</td>
												</tr>
											';
										}
									}
								?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<!-- modal -->
		<div id="<?=$fo_details['fo_tag']?>-statistics" class="modal fade">
			<div class="modal-dialog modal-full">
				<div class="modal-content">
					<div class="modal-header bg-danger">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h5 class="modal-title"><i class="icon-office"></i> <?=$fo_details['field_office']?></h5>
						<small>Appointment Summary A.Y <?=$activated_year?></small>
					</div>

					<div class="modal-body">
						<div class="row">
							<div class="col-md-3">
								<!-- Tickets stats colored -->
								<div class="panel text-center bg-danger-400 has-bg-image">
									<div class="panel-body">
										<h6 class="text-semibold no-margin-bottom mt-5"><?=$activated_year?> Statistics Percentage</h6>
										<div class="opacity-75 content-group">Acted over Received</div>
										<div class="svg-center position-relative mb-5" id="progress_percentage_four"></div>
									</div>

									<div class="panel-body panel-body-accent pb-15">
										<div class="row">
											<div class="col-xs-4">
												<div class="text-uppercase text-size-mini text-muted">RECEIVED</div>
												<h5 class="text-semibold no-margin"><?=$count_received_total_active_year?></h5>
											</div>

											<div class="col-xs-4">
												<div class="text-uppercase text-size-mini text-muted">ACTED</div>
												<h5 class="text-semibold no-margin"><?=$count_signed_active_year?></h5>
											</div>

											<div class="col-xs-4">
												<div class="text-uppercase text-size-mini text-muted">PENDING</div>
												<h5 class="text-semibold no-margin"><?=$fo_total_pending_active_yr = $count_received_total_active_year - $count_signed_active_year?></h5>
											</div>
										</div>
									</div>
								</div>
								<!-- /tickets stats colored -->
							</div>

							<div class="col-md-9">
								<div class="row">
									<?php
										if (is_array($build_array)) {
											foreach ($build_array as $list) {
												echo '
													<div class="col-sm-6 col-md-3">
														<div class="panel panel-body bg-indigo-400 has-bg-image">
															<div class="media no-margin">
																<div class="media-left media-middle">
																	<i class="icon-enter6 icon-3x opacity-75"></i>
																</div>

																<div class="media-body text-right">
																	<b class="no-margin">'.$list['count_processor']->ln.'</b>
																	<h4 class="no-margin">'.$list['count_total_processed'].'</h4>
																	<span class="text-uppercase text-size-mini">Total Processed</span>
																</div>
															</div>
														</div>
													</div>
												';
											}
										}

										else {
											echo 'No data found';
										}
									?>

									<?php
										if (is_array($build_array_signed)) {
											foreach ($build_array_signed as $list) {
												echo '
													<div class="col-sm-6 col-md-3">
														<div class="panel panel-body bg-success has-bg-image">
															<div class="media no-margin">
																<div class="media-left media-middle">
																	<i class="icon-checkmark-circle2 icon-3x opacity-75"></i>
																</div>

																<div class="media-body text-right">
																	<b class="no-margin">'.$list['count_signed']->ln.'</b>
																	<h4 class="no-margin">'.$list['count_total_signed'].'</h4>
																	<span class="text-uppercase text-size-mini">Total Signed</span>
																</div>
															</div>
														</div>
													</div>
												';
											}
										}

										else {
											echo 'No data found';
										}
									?>
								</div>
							</div>
						</div>

						<div class="table-responsive">
							<table class="table table-responsive table-bordered table-xs text-size-mini" style="text-align: center; width: 90%">
								<thead>
									<tr>
										<th style="text-align: center;">MONTH</th>
										<th style="text-align: center;">BALANCE</th>
										<th style="text-align: center;">RECEIVED</th>
										<th style="text-align: center;display: none;">TOTAL</th>
										<th style="text-align: center;">ACTED</th>
										<th style="text-align: center;">PENDING</th>
										<th style="text-align: center;">PERCENTAGE</th>
										<th style="text-align: center;" colspan="4">PROCESSING TIME</th>
										<th style="text-align: center;" colspan="<?=$count_user_per_fo?>"><?=$count_user_per_fo?> - PROCESSOR/S</th>
										<th style="text-align: center;" colspan="<?=$count_signing_officer?>"><?=$count_signing_officer?> - SIGNING OFFICIAL/S</th>
									</tr>
								</thead>

								<tbody>
									<tr>
										<td>&nbsp;</td>
										<td style="">&nbsp;</td>
										<td>&nbsp;</td>
										<td style="display: none;">&nbsp;</td>
										<td>&nbsp;</td>
										<td><?=$count_received_last_year?></td>
										<td>(Acted/Received) * 100</td>
										<td style="display: none;">(Acted/Received) * 100</td>
										<!-- processing time -->
										<td><=20 WD</td>
										<td>=>20 WD</td>
										<td><=40 WD</td>
										<td>=>40 WD</td>

										<!-- fetch fo user -->
										<?php
											if (is_array($fetch_fo_users)) {
												foreach ($fetch_fo_users as $list) {
													echo '
														<td>'.$list->ln.'</td>
													';
												}
											}

											else {
												echo '
													<td colspan="'.$count_user_per_fo.'">No data found</td>
												';
											}
										?>
										<!-- fetch signing officer -->

										<?php
											if (is_array($fetch_fo_signing_officer)) {
												foreach ($fetch_fo_signing_officer as $list) {
													echo '
														<td>'.$list->ln.'</td>
													';
												}
											}

											else {
												echo '
													<td colspan="'.$count_user_per_fo.'">No data found</td>
												';
											}
										?>
									</tr>

									<tr style=" display: ;">
										<td>Jan</td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_received_last_year?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_jan_received_active_year?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $jan_total = $count_received_last_year + $count_jan_received_active_year ?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_jan_signed_active_year?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $jan_pending = $jan_total - $count_jan_signed_active_year ?></td>
										<td>
											<?php  
												if ($jan_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_jan = ($count_jan_signed_active_year / $jan_total) * 100;
													echo(round($percentage_signed_received_jan,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($jan_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_jan = ($count_acted_active_year_per_month_jan / $jan_total) * 100;
													echo(round($percentage_acted_received_jan,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_jan?></td>
										<td style="color: red;"><?=$count_duedate_jan?></td>
										<td><?=$count_within40_jan?></td>
										<td style="color: red;"><?=$count_duedate40_jan?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_jan_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_jan_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Feb</td>
										<td style="color: <?=$count_feb_received_active_year == '0' ? '#fff' : ''?>;"><?=$jan_pending?></td>
										<td style="color: <?=$count_feb_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_feb_received_active_year?></td>
										<td style="color: <?=$count_feb_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $feb_total = $jan_pending + $count_feb_received_active_year ?></td>
										<td style="color: <?=$count_feb_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_feb_signed_active_year?></td>
										<td style="color: <?=$count_feb_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $feb_pending = $feb_total - $count_feb_signed_active_year ?></td>
										<td>
											<?php  
												if ($feb_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_feb = ($count_feb_signed_active_year / $feb_total) * 100;
													echo(round($percentage_signed_received_feb,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($feb_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_feb = ($count_acted_active_year_per_month_feb / $feb_total) * 100;
													echo(round($percentage_acted_received_feb,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_feb?></td>
										<td style="color: red;"><?=$count_duedate_feb?></td>
										<td><?=$count_within40_feb?></td>
										<td style="color: red;"><?=$count_duedate40_feb?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_feb_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_feb_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Mar</td>
										<td style="color: <?=$count_mar_received_active_year == '0' ? '#fff' : ''?>;"><?=$feb_pending?></td>
										<td style="color: <?=$count_mar_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_mar_received_active_year?></td>
										<td style="color: <?=$count_mar_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $mar_total = $feb_pending + $count_mar_received_active_year ?></td>
										<td style="color: <?=$count_mar_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_mar_signed_active_year?></td>
										<td style="color: <?=$count_mar_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $mar_pending = $mar_total - $count_mar_signed_active_year ?></td>
										<td>
											<?php  
												if ($mar_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_mar = ($count_mar_signed_active_year / $mar_total) * 100;
													echo(round($percentage_signed_received_mar,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($mar_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_mar = ($count_acted_active_year_per_month_mar / $mar_total) * 100;
													echo(round($percentage_acted_received_mar,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_mar?></td>
										<td style="color: red;"><?=$count_duedate_mar?></td>
										<td><?=$count_within40_mar?></td>
										<td style="color: red;"><?=$count_duedate40_mar?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_mar_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_mar_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Apr</td>
										<td style="color: <?=$count_apr_received_active_year == '0' ? '#fff' : ''?>;"><?=$mar_pending?></td>
										<td style="color: <?=$count_apr_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_apr_received_active_year?></td>
										<td style="color: <?=$count_apr_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $apr_total = $mar_pending + $count_apr_received_active_year ?></td>
										<td style="color: <?=$count_apr_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_apr_signed_active_year?></td>
										<td style="color: <?=$count_apr_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $apr_pending = $apr_total - $count_apr_signed_active_year ?></td>
										<td>
											<?php  
												if ($apr_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_apr = ($count_apr_signed_active_year / $apr_total) * 100;
													echo(round($percentage_signed_received_apr,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($apr_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_apr = ($count_acted_active_year_per_month_apr / $apr_total) * 100;
													echo(round($percentage_acted_received_apr,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_apr?></td>
										<td style="color: red;"><?=$count_duedate_apr?></td>
										<td><?=$count_within40_apr?></td>
										<td style="color: red;"><?=$count_duedate40_apr?></td>
										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_apr_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_apr_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>May</td>
										<td style="color: <?=$count_may_received_active_year == '0' ? '#fff' : ''?>;"><?=$apr_pending?></td>
										<td style="color: <?=$count_may_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_may_received_active_year?></td>
										<td style="color: <?=$count_may_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $may_total = $apr_pending + $count_may_received_active_year ?></td>
										<td style="color: <?=$count_may_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_may_signed_active_year?></td>
										<td style="color: <?=$count_may_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $may_pending = $may_total - $count_may_signed_active_year ?></td>
										<td>
											<?php  
												if ($may_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_may = ($count_may_signed_active_year / $may_total) * 100;
													echo(round($percentage_signed_received_may,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($may_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_may = ($count_acted_active_year_per_month_may / $may_total) * 100;
													echo(round($percentage_acted_received_may,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_may?></td>
										<td style="color: red;"><?=$count_duedate_may?></td>
										<td><?=$count_within40_may?></td>
										<td style="color: red;"><?=$count_duedate40_may?></td>
										
										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_may_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_may_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>June</td>
										<td style="color: <?=$count_june_received_active_year == '0' ? '#fff' : ''?>;"><?=$may_pending?></td>
										<td style="color: <?=$count_june_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_june_received_active_year?></td>
										<td style="color: <?=$count_june_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $june_total = $may_pending + $count_june_received_active_year ?></td>
										<td style="color: <?=$count_june_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_june_signed_active_year?></td>
										<td style="color: <?=$count_june_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $june_pending = $june_total - $count_june_signed_active_year ?></td>
										<td>
											<?php  
												if ($june_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_june = ($count_june_signed_active_year / $june_total) * 100;
													echo(round($percentage_signed_received_june,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($june_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_june = ($count_acted_active_year_per_month_june / $june_total) * 100;
													echo(round($percentage_acted_received_june,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_june?></td>
										<td style="color: red;"><?=$count_duedate_june?></td>
										<td><?=$count_within40_june?></td>
										<td style="color: red;"><?=$count_duedate40_june?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_june_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_june_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>July</td>
										<td style="color: <?=$count_july_received_active_year == '0' ? '#fff' : ''?>;"><?=$june_pending?></td>
										<td style="color: <?=$count_july_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_july_received_active_year?></td>
										<td style="color: <?=$count_july_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $july_total = $june_pending + $count_july_received_active_year ?></td>
										<td style="color: <?=$count_july_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_july_signed_active_year?></td>
										<td style="color: <?=$count_july_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $july_pending = $july_total - $count_july_signed_active_year ?></td>
										<td>
											<?php  
												if ($july_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_july = ($count_july_signed_active_year / $july_total) * 100;
													echo(round($percentage_signed_received_july,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($july_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_july = ($count_acted_active_year_per_month_july / $july_total) * 100;
													echo(round($percentage_acted_received_july,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_july?></td>
										<td style="color: red;"><?=$count_duedate_july?></td>
										<td><?=$count_within40_july?></td>
										<td style="color: red;"><?=$count_duedate40_july?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_july_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_july_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Aug</td>
										<td style="color: <?=$count_aug_received_active_year == '0' ? '#fff' : ''?>;"><?=$july_pending?></td>
										<td style="color: <?=$count_aug_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_aug_received_active_year?></td>
										<td style="color: <?=$count_aug_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $aug_total = $july_pending + $count_aug_received_active_year ?></td>
										<td style="color: <?=$count_aug_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_aug_signed_active_year?></td>
										<td style="color: <?=$count_aug_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $aug_pending = $aug_total - $count_aug_signed_active_year ?></td>
										<td>
											<?php  
												if ($aug_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_aug = ($count_aug_signed_active_year / $aug_total) * 100;
													echo(round($percentage_signed_received_aug,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($aug_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_aug = ($count_acted_active_year_per_month_aug / $aug_total) * 100;
													echo(round($percentage_acted_received_aug,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_aug?></td>
										<td style="color: red;"><?=$count_duedate_aug?></td>
										<td><?=$count_within40_aug?></td>
										<td style="color: red;"><?=$count_duedate40_aug?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_aug_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_aug_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Sept</td>
										<td style="color: <?=$count_sept_received_active_year == '0' ? '#fff' : ''?>;"><?=$aug_pending?></td>
										<td style="color: <?=$count_sept_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_sept_received_active_year?></td>
										<td style="color: <?=$count_sept_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $sept_total = $aug_pending + $count_sept_received_active_year ?></td>
										<td style="color: <?=$count_sept_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_sept_signed_active_year?></td>
										<td style="color: <?=$count_sept_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $sept_pending = $sept_total - $count_sept_signed_active_year ?></td>
										<td>
											<?php  
												if ($sept_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_sept = ($count_sept_signed_active_year / $sept_total) * 100;
													echo(round($percentage_signed_received_sept,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($sept_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_sept = ($count_acted_active_year_per_month_sept / $sept_total) * 100;
													echo(round($percentage_acted_received_sept,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_sept?></td>
										<td style="color: red;"><?=$count_duedate_sept?></td>
										<td><?=$count_within40_sept?></td>
										<td style="color: red;"><?=$count_duedate40_sept?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_sept_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_sept_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Oct</td>
										<td style="color: <?=$count_oct_received_active_year == '0' ? '#fff' : ''?>;"><?=$sept_pending?></td>
										<td style="color: <?=$count_oct_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_oct_received_active_year?></td>
										<td style="color: <?=$count_oct_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $oct_total = $sept_pending + $count_oct_received_active_year ?></td>
										<td style="color: <?=$count_oct_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_oct_signed_active_year?></td>
										<td style="color: <?=$count_oct_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $oct_pending = $oct_total - $count_oct_signed_active_year ?></td>
										<td>
											<?php  
												if ($oct_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_oct = ($count_oct_signed_active_year / $oct_total) * 100;
													echo(round($percentage_signed_received_oct,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($oct_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_oct = ($count_acted_active_year_per_month_oct / $oct_total) * 100;
													echo(round($percentage_acted_received_oct,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_oct?></td>
										<td style="color: red;"><?=$count_duedate_oct?></td>
										<td><?=$count_within40_oct?></td>
										<td style="color: red;"><?=$count_duedate40_oct?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_oct_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_oct_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr>
										<td>Nov</td>
										<td style="color: <?=$count_nov_received_active_year == '0' ? '#fff' : ''?>;"><?=$oct_pending?></td>
										<td style="color: <?=$count_nov_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_nov_received_active_year?></td>
										<td style="color: <?=$count_nov_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $nov_total = $oct_pending + $count_nov_received_active_year ?></td>
										<td style="color: <?=$count_nov_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_nov_signed_active_year?></td>
										<td style="color: <?=$count_nov_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $nov_pending = $nov_total - $count_nov_signed_active_year ?></td>
										<td>
											<?php  
												if ($nov_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_nov = ($count_nov_signed_active_year / $nov_total) * 100;
													echo(round($percentage_signed_received_nov,2).'%');
												}
											?>
										</td>

										<td style="display: none;">
											<?php
												if ($nov_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_nov = ($count_acted_active_year_per_month_nov / $nov_total) * 100;
													echo(round($percentage_acted_received_nov,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_nov?></td>
										<td style="color: red;"><?=$count_duedate_nov?></td>
										<td><?=$count_within40_nov?></td>
										<td style="color: red;"><?=$count_duedate40_nov?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_nov_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_nov_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>

									<tr style="display: none;">
										<td>Dec</td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$nov_pending?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_dec_received_active_year?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;display: none;"><?php echo $dec_total = $nov_pending + $count_dec_received_active_year ?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?=$count_dec_signed_active_year?></td>
										<td style="color: <?=$count_jan_received_active_year == '0' ? '#fff' : ''?>;"><?php echo $dec_pending = $dec_total - $count_dec_signed_active_year ?></td>
										<td>
											<?php  
												if ($dec_total == "0") {
													echo "0%";
												}

												else {
													$percentage_signed_received_dec = ($count_dec_signed_active_year / $dec_total) * 100;
													echo(round($percentage_signed_received_dec,2).'%');
												}
											?>
										</td>

										<td>
											<?php
												if ($dec_total == "0") {
													echo "0%";
												}

												else {
													$percentage_acted_received_dec = ($count_acted_active_year_per_month_dec / $dec_total) * 100;
													echo(round($percentage_acted_received_dec,2).'%');
												}
												
											?>
										</td>
										<!-- processing time -->
										<td><?=$count_within_dec?></td>
										<td style="color: red;"><?=$count_duedate_dec?></td>
										<td><?=$count_within40_dec?></td>
										<td style="color: red;"><?=$count_duedate40_dec?></td>

										<?php
											foreach ($build_array as $count) {
												echo '
													<td>'.$count['count_dec_processed_by_fo_active_year'].'</td>
												';
											}

											foreach ($build_array_signed as $count) {
												echo '
													<td>'.$count['count_dec_signed_by_fo_active_year'].'</td>
												';
											}
										?>
									</tr>
								</tbody>
							</table>
						</div>
					</div>

					<div class="modal-footer">
						<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
					</div>
				</div>
			</div>
		</div>
		<!-- /modal -->

		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->

<?php
	// percentage of total received and signed
	if ($count_received_total > 0) {
		$total_percentage = ($count_signed / $count_received_total);

		echo '
			<input type="hidden" id="total_percentage" name="total_percentage" value="'.$total_percentage.'">
		';
	}

	else {
		$total_percentage = 0;
	}
	
	
	// percentage of total received and signed in active year
	if ($count_received_total_active_year > 0) {
		$total_percentage_active_year = ($count_signed_active_year / $count_received_total_active_year);
		echo '
			<input type="hidden" id="total_percentage_active_year" name="total_percentage_active_year" value="'.$total_percentage_active_year.'">
		';
	}

	else {
		$total_percentage_active_year = 0;
	}
?>