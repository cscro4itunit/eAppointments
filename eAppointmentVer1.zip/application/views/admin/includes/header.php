<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?=$showinfo['title']?></title>
	<link rel="icon" href="<?=base_url().'assets/images/system/'?><?=$showinfo['icon']?>">

	<!-- Global stylesheets -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/icons/icomoon/styles.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/bootstrap.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/core.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/components.css'?>" rel="stylesheet" type="text/css">
	<link href="<?=base_url().'assets/css/colors.css'?>" rel="stylesheet" type="text/css">
	<!-- /global stylesheets -->

	<!-- SWEETALERT -->
    <link rel="stylesheet" href="<?=base_url().'assets/sweetalert/sweetalert.css'?>">
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert-dev.js'?>"></script>
    <script type="text/javascript" src="<?=base_url().'assets/sweetalert/sweetalert.min.js'?>"></script>
</head>

<body class="navbar-top">
	<!-- Main navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top bg-indigo">
		<div class="navbar-header">
			<a class="navbar-brand" href="index.html">
				<b><?=$showinfo['header']?></b>
			</a>

			<ul class="nav navbar-nav visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
				<li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav">
				<li><a class="sidebar-control sidebar-main-toggle hidden-xs">
					<i class="icon-paragraph-justify3"></i>
				</a></li>
			</ul>

			<div class="navbar-right">
				<p class="navbar-text"><b style="text-transform: uppercase;color: #fff;"><?=$admin_details['fn'].' '.$admin_details['ln']?></b></p>
			</div>
		</div>
	</div>
	<!-- /main navbar -->

	<!-- Page container -->
	<div class="page-container">
		<!-- Page content -->
		<div class="page-content">
			<!-- Main sidebar -->
			<div class="sidebar sidebar-main sidebar-default sidebar-fixed">
				<div class="sidebar-content">
					<!-- User menu -->
					<div class="sidebar-user-material">
						<div class="category-content">
							<div class="sidebar-user-material-content">
								<a href="#"><img src="<?=base_url().'assets/images/user/'?><?=$admin_details['image']?>" class="img-circle img-responsive" alt="" style="width: 80px;height: 80px;"></a>

								<h6><?=$admin_details['fn'].' '.$admin_details['ln']?></h6>

								<span class="text-size-small"><?=$admin_details['position']?></span>
							</div>
														
							<div class="sidebar-user-material-menu">
								<a href="#user-nav" data-toggle="collapse"><span>My account</span> <i class="caret"></i></a>
							</div>
						</div>
						
						<div class="navigation-wrapper collapse" id="user-nav">
							<ul class="navigation">
								<li><a href="<?=base_url('admin-account-update')?>?user=<?=$admin_details['url_key']?>"><i class="icon-user-plus"></i> <span>My profile</span></a></li>

								<li><a href="<?=BASE_URL('admin_logout');?>">
									<i class="icon-switch2"></i> <span>Logout</span>
								</a></li>
							</ul>
						</div>
					</div>
					<!-- /user menu -->

					<!-- Main navigation -->
					<div class="sidebar-category sidebar-category-visible">
						<div class="category-content no-padding">
							<ul class="navigation navigation-main navigation-accordion">
								<!-- Main -->
								<li class="navigation-header"><span>Main</span> <i class="icon-menu" title="Main pages"></i></li>
								
								<!--<li class="<?=$nav == 'admindashboard' ? 'active' : ''?>">-->
								<!--	<a href="<?=BASE_URL('administrator')?>">-->
								<!--		<i class="icon-home2"></i> <span>Dashboard</span>-->
								<!--	</a>-->
								<!--</li>-->

								<li class="<?=$nav == 'fo_appointments' ? 'active' : ''?>">
									<a href="<?=BASE_URL('administrator')?>">
										<i class="icon-stack3"></i> <span>Appointments</span>
									</a>
								</li>

								<li class="navigation-header"><span>Management</span> <i class="icon-menu" title="Main pages"></i></li>

								<li class="<?=$nav == 'manage_admin' ? 'active' : ''?>">
									<a href="<?=BASE_URL('manage-admin-account')?>">
										<i class="icon-users2"></i> <span>Admin Account</span>
									</a>
								</li>

								<li class="<?=$nav == 'manage_user' ? 'active' : ''?>">
									<a href="<?=BASE_URL('manage-user-account')?>">
										<i class="icon-users4"></i> <span>User Account</span>
									</a>
								</li>

								<li class="<?=$nav == 'manage_agency' ? 'active' : ''?>">
									<a href="<?=BASE_URL('manage-agency')?>">
										<i class="icon-city"></i> <span>Agency</span>
									</a>
								</li>

								<li class="<?=$nav == 'manage_holidays' ? 'active' : ''?>">
									<a href="<?=BASE_URL('manage-holidays')?>">
										<i class="icon-calendar"></i> <span>Non-Working Days</span>
									</a>
								</li>

								<li>
									<a href="#"><i class="icon-wrench"></i> <span>Settings</span></a>
									<ul>
										<li class="<?=$nav == 'setting_system_info' ? 'active' : ''?>">
											<a href="<?=BASE_URL('manage-system-information')?>">
												System Information
											</a>
										</li>

										<li class="<?=$nav == 'manage_fo' ? 'active' : ''?>">
											<a href="<?=BASE_URL('manage-field-office')?>">
												Field Office
											</a>
										</li>

										<li class="<?=$nav == 'manage_appt_data' ? 'active' : ''?>">
											<a href="<?=BASE_URL('manage-appointment-data')?>">
												Appointment Data
											</a>
										</li>
									</ul>
								</li>
								<!-- /page kits -->
							</ul>
						</div>
					</div>
					<!-- /main navigation -->
				</div>
			</div>
			<!-- /main sidebar -->