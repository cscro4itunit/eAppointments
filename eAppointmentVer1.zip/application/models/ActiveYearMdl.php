<?php
class ActiveYearMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'active_year_tbl';
	}

	// crud
	public function add_active_year($url_key, $active_year, $status) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, active_year, status)
			VALUES("'.$url_key.'", "'.$active_year.'", "'.$status.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_active_year($url_key, $active_year) {
		$sql = 'UPDATE '.$this->table.' SET active_year = "'.$active_year.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_status($url_key, $status) {
		$sql = 'UPDATE '.$this->table.' SET status = "'.$status.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function deactivate_year() {
		$sql = 'UPDATE '.$this->table.' SET status = "0" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function update_status_year($year_status, $get_year) {
		$sql = 'UPDATE '.$this->table.' SET status = "'.$year_status.'" WHERE active_year = "'.$get_year.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_active_year($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function fetch_years_status($field, $status) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE status = "'.$status.'" ';
        $query = $this->db->query($sql);
       return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_active_year($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY active_year ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_active_year_type($field, $active_year) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE active_year = "'.$active_year.'" ORDER BY active_year ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>