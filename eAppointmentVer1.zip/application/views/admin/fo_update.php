<input type="hidden" id="base_url" value="<?=base_url()?>">

<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Management</span> - Field Office Update</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-office text-primary"></i> <span>Field Office</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><i class="icon-gear position-left"></i> Management</li>
				<li>Field Office</li>
				<li>FO Details</li>
				<li class="active">Update</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('administrator')?>"><?=$showinfo['agency']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h6 class="panel-title">
							<b><i class="icon-pencil5"></i> Field office</b><br>
							<small>Update information. You may use basic html tag/s for text modification.</small>
						</h6>
						<div class="heading-elements">
							<ul class="icons-list">
		                		<li><a data-action="collapse"></a></li>
		                	</ul>
	                	</div>
					</div>
					
					<div class="panel-body">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group has-feedback has-feedback-left">
									<label for="field_office">Field office</label>
									<input id="field_office" name="field_office" type="text" class="form-control input-xs" placeholder="Field Office" autocomplete="off" value="<?=$fo_details['field_office']?>">
									<div class="form-control-feedback">
										<i class="icon icon-pencil5"></i>
									</div>
								</div>

								<div class="form-group has-feedback has-feedback-left">
									<label for="director">Director</label>
									<input id="director" name="director" type="text" class="form-control input-xs" placeholder="Director" autocomplete="off" value="<?=$fo_details['director']?>">
									<div class="form-control-feedback">
										<i class="icon icon-user"></i>
									</div>
								</div>

								<div class="form-group has-feedback has-feedback-left">
									<label for="contact">Office Number</label>
									<input id="contact" name="contact" type="text" class="form-control input-xs" placeholder=">Office Number" autocomplete="off" value="<?=$fo_details['contact']?>">
									<div class="form-control-feedback">
										<i class="icon icon-phone2"></i>
									</div>
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group has-feedback has-feedback-left">
									<label for="email_add">Email Address</label>
									<input id="email_add" name="email_add" type="text" class="form-control input-xs" placeholder=">Email Address" autocomplete="off" value="<?=$fo_details['email_add']?>">
									<div class="form-control-feedback">
										<i class="icon icon-phone2"></i>
									</div>
								</div>

								<div class="form-group has-feedback has-feedback-left">
									<label for="office_address">Office Address</label>
									<textarea id="office_address" name="office_address" class="form-control input-xs" rows="5" style="width: 100%; resize: none;"><?=$fo_details['email_add']?></textarea>
									<div class="form-control-feedback">
										<i class="icon icon-home"></i>
									</div>
								</div>

								<button onclick="udpate_fo()" type="button" class="btn btn-primary btn-xs pull-right">
									<i class="icon-reset"></i> Update FO Details
								</button>
							</div>
						</div>
						
					</div>
				</div>
			</div>
		</div>
		
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->