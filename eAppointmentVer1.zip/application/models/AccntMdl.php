<?php
class AccntMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'user_accnt_tbl';
	}

	// CRUD
	public function add_account ($url_key, $fn, $mi, $ln, $gender, $contact, $image, $email_add, $field_office, $position, $user_type, $username, $password, $security_code, $role, $active_status) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, fn, mi, ln, gender, contact, image, email_add, field_office, position, user_type, username, password, security_code, role, active_status)
			VALUES("'.$url_key.'", "'.$fn.'", "'.$mi.'", "'.$ln.'", "'.$gender.'", "'.$contact.'", "'.$image.'", "'.$email_add.'", "'.$field_office.'", "'.$position.'", "'.$user_type.'", "'.$username.'", "'.$password.'", "'.$security_code.'", "'.$role.'", "'.$active_status.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function udpate_active_status_by_url_key($url_key, $active_status) {
		$sql = 'UPDATE '.$this->table.' SET active_status = "'.$active_status.'" WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_user_username ($url_key, $username) {
		$sql = 'UPDATE '.$this->table.' SET username = "'.$username.'" WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_user_password ($url_key, $password) {
		$sql = 'UPDATE '.$this->table.' SET password = "'.$password.'" WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_user_personal_info($url_key, $fn, $mi, $ln, $gender, $contact, $email_add, $field_office, $position, $user_type) {
		$sql = 'UPDATE '.$this->table.' SET fn = "'.$fn.'", mi = "'.$mi.'", ln = "'.$ln.'", gender = "'.$gender.'", contact = "'.$contact.'", email_add = "'.$email_add.'", field_office = "'.$field_office.'", position = "'.$position.'", user_type = "'.$user_type.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
        return $query;
	}

	public function update_user_security($url_key, $security_question, $security_answer) {
		$sql = 'UPDATE '.$this->table.' SET security_question = "'.$security_question.'", security_answer = "'.$security_answer.'" WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_user_image ($url_key, $realname) {
		$sql = 'UPDATE '.$this->table.' SET image = "'.$realname.'" WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_fo_personal_info($user_id, $fn, $mi, $ln, $gender, $contact, $email_add, $position) {
		$sql = 'UPDATE '.$this->table.' SET fn = "'.$fn.'", mi = "'.$mi.'", ln = "'.$ln.'", gender = "'.$gender.'", contact = "'.$contact.'", email_add = "'.$email_add.'", position = "'.$position.'" WHERE id = "'.$user_id.'" ';
		$query = $this->db->query($sql);
        return $query;
	}

	public function update_fo_security($user_id, $security_question, $security_answer) {
		$sql = 'UPDATE '.$this->table.' SET security_question = "'.$security_question.'", security_answer = "'.$security_answer.'" WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_fo_username ($user_id, $username) {
		$sql = 'UPDATE '.$this->table.' SET username = "'.$username.'" WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_fo_password ($user_id, $password) {
		$sql = 'UPDATE '.$this->table.' SET password = "'.$password.'" WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	public function update_fo_image ($user_id, $realname) {
		$sql = 'UPDATE '.$this->table.' SET image = "'.$realname.'" WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query;
	}

	// FETCHING ADMIN ACCOUNT DETAILS
	public function username_auth($field, $username) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE username = "'.$username.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ORDER BY username ASC';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}

	public function user_id_details($field, $user_id) {
        $sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
    }

    public function fetch_by_id($field, $user_id) {
        $sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE id = "'.$user_id.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
    }

    public function fetch_user_account($field) {
    	$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE role = 1 ORDER BY username ASC';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->result() : '';
    }

    public function fetch_admin_account($field) {
    	$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE role = 0 ORDER BY username ASC';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->result() : '';
    }

    public function fetch_fo_users($field, $field_office) {
    	$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE field_office = "'.$field_office.'" ORDER BY id ASC';
    	$query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->result() : '';
    }

    public function fetch_fo_signing_officer($field, $field_office, $user_type) {
    	$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE field_office = "'.$field_office.'" AND user_type = "'.$user_type.'" ORDER BY id ASC';
    	$query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->result() : '';
    }

    // Count number of employee per field office
    public function count_user_per_fo($field, $field_office) {
    	$sql = 'SELECT * FROM '.$this->table.' WHERE field_office = "'.$field_office.'" ';
		$query = $this->db->query($sql);
         return $query->num_rows();
    }

     public function count_user_type($field, $field_office, $user_type) {
    	$sql = 'SELECT * FROM '.$this->table.' WHERE field_office = "'.$field_office.'" AND user_type = "'.$user_type.'" ';
		$query = $this->db->query($sql);
         return $query->num_rows();
    }
}
?>