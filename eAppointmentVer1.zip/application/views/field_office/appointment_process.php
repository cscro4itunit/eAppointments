<input type="hidden" id="base_url" value="<?=base_url()?>">
<!-- Main content -->
<div class="content-wrapper">
	<!-- Page header -->
	<div class="page-header page-header-default">
		<div class="page-header-content">
			<div class="page-title">
				<h4><i class="icon-arrow-left52 position-left"></i> <span class="text-semibold">Appointment Process</span> - Add</h4>
			</div>

			<div class="heading-elements">
				<div class="heading-btn-group">
					<a href="#" class="btn btn-link btn-float text-size-small has-text">
						<i class="icon-calendar5 text-primary"></i> <span>Data</span>
					</a>
				</div>
			</div>
		</div>

		<div class="breadcrumb-line">
			<ul class="breadcrumb">
				<li><a href="#"><i class="icon-database position-left"></i> Appointment Process</a></li>
				<li class="active">Add Appointment</li>
			</ul>

			<ul class="breadcrumb-elements">
				<li><a href="<?=BASE_URL('dashboard')?>"><?=$showinfo['header']?></a></li>
			</ul>
		</div>
	</div>
	<!-- /page header -->

	<!-- Content area -->
	<div class="content">
		<!-- START OF MAIN CONTENT -->
		<?php
			include 'includes/appointment_count.php'
		?>
		<div class="panel panel-default">
			<div class="panel-heading">
				<h6 class="panel-title">
					<b><i class="icon-folder-plus"></i> Add appointment</b><br>
					<small>Please fillout all * field/s . Always write in Capital Letter/s.</small>
				</h6>
				<div class="heading-elements">
					<ul class="icons-list">
                		<li><a data-action="collapse"></a></li>
                	</ul>
            	</div>
			</div>
			
			<div class="panel-body">
				<form method="post">
					<div class="row">
						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="date_received">Date Recieved <small>(mm/dd/yyyy)</small> *</label>
								<input id="date_received" name="date_received" type="date" class="form-control input-xs" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-calendar"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="sector">Sector *</label>
								<select class="form-control input-xs" id="sector" name="sector">
									<option value="">- Select Sector -</option>
									<?php
										if (is_array($fetch_sector)) {
											foreach ($fetch_sector as $list) {
												echo '
													<option value="'.$list->sector.'">'.$list->sector.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="agency_name">Name of Agency *</label>
								<select class="form-control input-xs" id="agency_name" name="agency_name">
									<option value="">- Select Agency -</option>
									<?php
										if (is_array($fetch_agency)) {
											foreach ($fetch_agency as $list) {
												echo '
													<option value="'.$list->agency_name.'">'.$list->agency_name.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-office"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointee">Name of Appointee *</label>
								<input id="appointee" name="appointee" type="text" class="form-control input-xs" placeholder="Lastname, Firstname, Ext.Name, Middle Name" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-user"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="position_title">Position Title *</label>
								<input id="position_title" name="position_title" type="text" class="form-control input-xs" placeholder="Position Title" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="salary_grade">Salary/Job/Pay Grade *</label>
								<select class="form-control input-xs" id="salary_grade" name="salary_grade">
									<option value="">- Select Salary Grade -</option>
									<?php
										if ($user_details['field_office'] == "psed") {
											for ($i=26; $i < 31 ; $i++) { 
												echo '
													<option value="'.$i.'">SG - '.$i.'</option>
												';	
											}
										}

										else {
											for ($i=1; $i < 26 ; $i++) { 
												echo '
													<option value="'.$i.'">SG - '.$i.'</option>
												';	
											}	
										}
										
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="position_level">Position Level *</label>
								<select class="form-control input-xs" id="position_level" name="position_level">
									<option value="">- Select Level -</option>
									<option value="1st">1st</option>
									<option value="2nd">2nd</option>
									<option value="3rd">3rd</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="employment_status">Employment Status *</label>
								<select class="form-control input-xs" id="employment_status" name="employment_status" onchange="select_emp_status()">
									<option value="">- Select Status -</option>
									<?php
										if (is_array($fetch_employment_status)) {
											foreach ($fetch_employment_status as $list) {
												echo '
													<option value="'.$list->employment_status.'">'.$list->employment_status.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointment_nature">Nature of Appointment *</label>
								<select class="form-control input-xs" id="appointment_nature" name="appointment_nature">
									<option value="">- Select Nature -</option>
									<?php
										if (is_array($fetch_appt_nature)) {
											foreach ($fetch_appt_nature as $list) {
												echo '
													<option value="'.$list->appointment_nature.'">'.$list->appointment_nature.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="inclusive_date_casual_from">Inclusive date of Casual or Contractual Appointment</label>
								<div class="row">
									<div class="col-md-6">
										<input id="inclusive_date_casual_from" name="inclusive_date_casual_from" type="date" class="form-control input-xs" autocomplete="off" disabled>
										<div class="form-control-feedback">
											<i class="icon icon-calendar5">fr</i>
										</div>
									</div>

									<div class="col-md-6">
										<input id="inclusive_date_casual_to" name="inclusive_date_casual_to" type="date" class="form-control input-xs" autocomplete="off" disabled>
										<div class="form-control-feedback">
											<i class="icon icon-calendar5">to</i>
										</div>
									</div>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="appointing_authority">Name of Appointing Authority *</label>
								<input id="appointing_authority" name="appointing_authority" type="text" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="issuance_date">Date of Issuance of Appointment *</label>
								<input id="issuance_date" name="issuance_date" type="date" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="birthday">Date of Birth *</label>
								<input id="birthday" name="birthday" type="date" class="form-control input-xs" placeholder="Appointing Authority" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="sex">Sex *</label>
								<select class="form-control input-xs" id="sex" name="sex">
									<option value="">- Select Gender -</option>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-man-woman"></i>
								</div>
							</div>
						</div>

						<div class="col-md-4">
							<div class="form-group has-feedback has-feedback-left">
								<label for="pwd">Person with Disability? *</label>
								<select class="form-control input-xs" id="pwd" name="pwd" onchange="select_disability()">
									<option value="">- Select -</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="disability">if YES, type of disability</label>
								<select class="form-control input-xs" id="disability" name="disability" disabled>
									<option value="">- Select Type of Disability -</option>
									<?php
										if (is_array($fetch_disability)) {
											foreach ($fetch_disability as $list) {
												echo '
													<option value="'.$list->disability_type.'">'.$list->disability_type.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="member_ip_group">Member of IP Group *</label>
								<select class="form-control input-xs" id="member_ip_group" name="member_ip_group" onchange="select_ip()">
									<option value="">- Select -</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="ethnicity">Ethnicity</label>
								<select class="form-control input-xs" id="ethnicity" name="ethnicity" disabled>
									<option value="">- Select Type of Ethnicity -</option>
									<?php
										if (is_array($fetch_ethnicity)) {
											foreach ($fetch_ethnicity as $list) {
												echo '
													<option value="'.$list->ethnicity.'">'.$list->ethnicity.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="eligibility_type">Type of Eligibility Used</label>
								<select class="form-control input-xs" id="eligibility_type" name="eligibility_type">
									<option value="">- Select Eligibility -</option>
									<?php
										if (is_array($fetch_eligibility)) {
											foreach ($fetch_eligibility as $list) {
												echo '
													<option value="'.$list->eligibility_type.'">'.$list->eligibility_type.'</option>
												';
											}
										}

										else {
											echo 'No data found!';
										}
									?>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-price-tag2"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="eligibility_effective_date">Date of Effectivity of Eligibility</label>
								<input id="eligibility_effective_date" name="eligibility_effective_date" type="date" class="form-control input-xs" placeholder="Ethnicity" autocomplete="off">
								<div class="form-control-feedback">
									<i class="icon icon-pencil5"></i>
								</div>
							</div>

							<div class="form-group has-feedback has-feedback-left">
								<label for="time_used_of_eligibility">First time used of eligibility? *</label>
								<select class="form-control input-xs" id="time_used_of_eligibility" name="time_used_of_eligibility">
									<option value="">- Select -</option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="form-control-feedback">
									<i class="icon icon-question4"></i>
								</div>
							</div>
						</div>
					</div>

					<button onclick="review_appointment()" type="button" class="btn btn-primary btn-xs pull-right">
						<i class="icon icon-plus-circle2"></i> Add Appointment
					</button>

					<!-- MODAL -->
					<div id="appointment_review" class="modal fade">
						<div class="modal-dialog modal-full">
							<div class="modal-content">
								<div class="modal-header bg-primary">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h5 class="modal-title"><b>Review Appointment</b></h5>
								</div>

								<div class="modal-body">
									<div class="row">
										<div class="col-md-4">
											<h6>Date Received</h6>
											<h3 id="get_date_received" class="text-bold"></h3>

											<h6>Sector</h6>
											<h4 id="get_sector" class="text-bold"></h4>

											<h6>Name of Agency</h6>
											<h4 id="get_agency_name" class="text-bold"></h4>

											<h6>Name of Appointee</h6>
											<h4 id="get_appointee" class="text-bold"></h4>

											<h6>Position Title</h6>
											<h4 id="get_position_title" class="text-bold"></h4>

											<h6>Salary/Job/Pay Grade</h6>
											<h4 id="get_salary_grade" class="text-bold"></h4>

											<h6>Position Level</h6>
											<h4 id="get_position_level" class="text-bold"></h4>
										</div>

										<div class="col-md-4">
											<h6>Employment Status</h6>
											<h4 id="get_employment_status" class="text-bold"></h4>

											<h6>Nature of Appointment</h6>
											<h4 id="get_appointment_nature" class="text-bold"></h4>

											<h6>Inclusive date of Casual or Contractual Appointment</h6>
											<div class="row">
												<div class="col-md-6">
													<h4 id="get_inclusive_date_casual_from" class="text-bold"></h4>
												</div>
												
												<div class="col-md-6">
													<h4 id="get_inclusive_date_casual_to" class="text-bold"></h4>
												</div>
											</div>

											<h6>Name of Appointing Authority</h6>
											<h4 id="get_appointing_authority" class="text-bold"></h4>

											<h6>Date of Issuance of Appointment</h6>
											<h4 id="get_issuance_date" class="text-bold"></h4>

											<h6>Date of Birth</h6>
											<h4 id="get_birthday" class="text-bold"></h4>

											<h6>Sex</h6>
											<h4 id="get_sex" class="text-bold"></h4>
										</div>

										<div class="col-md-4">
											<h6>Person with Disability?</h6>
											<h4 id="get_pwd" class="text-bold"></h4>

											<h6>if YES, type of disability?</h6>
											<h4 id="get_disability" class="text-bold"></h4>

											<h6>Member of IP Group</h6>
											<h4 id="get_member_ip_group" class="text-bold"></h4>

											<h6>Ethnicity</h6>
											<h4 id="get_ethnicity" class="text-bold"></h4>

											<h6>Type of Eligibility Used</h6>
											<h4 id="get_eligibility_type" class="text-bold"></h4>

											<h6>Date of Effectivity of Eligibility</h6>
											<h4 id="get_eligibility_effective_date" class="text-bold"></h4>

											<h6>First time used of eligibility?</h6>
											<h4 id="get_time_used_of_eligibility" class="text-bold"></h4>
										</div>
									</div>
								</div>

								<div class="modal-footer">
									<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
									<button onclick="add_appointment()" type="button" class="btn btn-primary btn-xs">
										<i class="icon icon-database-add"></i> Save Appointment
									</button>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- /START OF MAIN CONTENT -->
		
		<!-- Footer -->
		<div class="footer text-muted">
			<?=$showinfo['footer']?>
		</div>
		<!-- /footer -->
	</div>
	<!-- /content area -->
</div>
<!-- /main content -->

<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>