<?php
class AgencyMdl extends CI_MODEL {
	private $table;
	
	public function __construct() {
		parent:: __construct();
		$this->load->database();
		$this->table = 'agency_tbl';
	}

	// crud
	public function add_agency($url_key, $agency_name, $field_office) {
		$sql = 'INSERT INTO '.$this->table.'(url_key, agency_name, field_office)
			VALUES("'.$url_key.'", "'.$agency_name.'", "'.$field_office.'")';
        $query = $this->db->query($sql);
       	return $query;
	}

	public function update_agency($url_key, $field_office, $agency_name) {
		$sql = 'UPDATE '.$this->table.' SET agency_name = "'.$agency_name.'", field_office = "'.$field_office.'" WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	public function delete_agency($url_key) {
		$sql = 'DELETE FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
		$query = $this->db->query($sql);
       	return $query;
	}

	// fetching
	public function fetch_agency_by_fo($field, $field_office) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE field_office = "'.$field_office.'" ORDER BY agency_name ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_fo_agency($field, $agency_name, $field_office) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE field_office = "'.$field_office.'" AND agency_name = "'.$agency_name.'" ORDER BY agency_name ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function fetch_agency($field) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' ORDER BY agency_name ASC';
		$query = $this->db->query($sql);
		return $query->num_rows() > 0 ?  $query->result() : '';
	}

	public function url_auth($field, $url_key) {
		$sql = 'SELECT '.$field.' FROM '.$this->table.' WHERE url_key = "'.$url_key.'" ';
        $query = $this->db->query($sql);
        return $query->num_rows() > 0 ? $query->row_array() : false;
	}
}
?>